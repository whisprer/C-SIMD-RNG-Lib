#include <iostream>
#include <vector>
#include <string>

// Simple CPU feature detection without using the library
void detect_cpu_features() {
    std::vector<std::string> features;
    
    #if defined(__AVX512F__) && defined(__AVX512DQ__)
        features.push_back("AVX-512");
    #endif
    
    #if defined(__AVX2__)
        features.push_back("AVX2");
    #endif
    
    #if defined(__AVX__)
        features.push_back("AVX");
    #endif
    
    #if defined(__SSE2__)
        features.push_back("SSE2");
    #endif
    
    #if defined(__ARM_NEON) || defined(__ARM_NEON__)
        features.push_back("NEON");
    #endif
    
    std::cout << "Detected CPU features:\n";
    if (features.empty()) {
        std::cout << "  None of the supported SIMD features detected\n";
    } else {
        for (const auto& feature : features) {
            std::cout << "  " << feature << "\n";
        }
    }
}

int main() {
    std::cout << "Universal RNG Environment Check\n";
    std::cout << "============================\n\n";
    
    // Check CPU features
    detect_cpu_features();
    
    // Check build configuration
    std::cout << "\nBuild configuration:\n";
    
    #ifdef USE_AVX512
        std::cout << "  USE_AVX512 defined\n";
    #else
        std::cout << "  USE_AVX512 not defined\n";
    #endif
    
    #ifdef USE_AVX2
        std::cout << "  USE_AVX2 defined\n";
    #else
        std::cout << "  USE_AVX2 not defined\n";
    #endif
    
    #ifdef USE_SSE2
        std::cout << "  USE_SSE2 defined\n";
    #else
        std::cout << "  USE_SSE2 not defined\n";
    #endif
    
    #ifdef USE_AVX
        std::cout << "  USE_AVX defined\n";
    #else
        std::cout << "  USE_AVX not defined\n";
    #endif
    
    #ifdef USE_NEON
        std::cout << "  USE_NEON defined\n";
    #else
        std::cout << "  USE_NEON not defined\n";
    #endif
    
    std::cout << "\nCompiler information:\n";
    
    #ifdef __GNUC__
        std::cout << "  GCC version: " << __GNUC__ << "." << __GNUC_MINOR__ << "." << __GNUC_PATCHLEVEL__ << "\n";
    #endif
    
    #ifdef _MSC_VER
        std::cout << "  MSVC version: " << _MSC_VER << "\n";
    #endif
    
    std::cout << "\nEnvironment check completed successfully.\n";
    return 0;
}