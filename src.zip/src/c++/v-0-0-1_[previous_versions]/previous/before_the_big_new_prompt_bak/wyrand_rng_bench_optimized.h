#ifndef WYRAND_RNG_BENCH_OPTIMIZED_H
#define WYRAND_RNG_BENCH_OPTIMIZED_H

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <string.h>

// Include the new streamlined WyRand file
// originally "simd-wyrand-optimized.h", now "wyrand_simd_main_optimized.h"
#include "wyrand_simd_main_optimized.h"

// Original xoroshiro128+ for comparison
typedef struct {
    uint64_t s[2];
} xoroshiro128plus_state;

// Basic rotl
static inline uint64_t rotl(const uint64_t x, int k) {
    return (x << k) | (x >> (64 - k));
}

// The "plus" version for a baseline
static inline uint64_t xoroshiro128plus_next(xoroshiro128plus_state *state) {
    const uint64_t s0 = state->s[0];
    uint64_t s1 = state->s[1];
    const uint64_t result = s0 + s1;
    s1 ^= s0;
    state->s[0] = rotl(s0, 24) ^ s1 ^ (s1 << 16);
    state->s[1] = rotl(s1, 37);
    return result;
}

static inline void xoroshiro128plus_seed(xoroshiro128plus_state *state, uint64_t seed) {
    // SplitMix64
    uint64_t z = (seed + 0x9e3779b97f4a7c15ULL);
    z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
    z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
    state->s[0] = z ^ (z >> 31);

    z = (state->s[0] + 0x9e3779b97f4a7c15ULL);
    z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
    z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
    state->s[1] = z ^ (z >> 31);
}

// Benchmark original xoroshiro128+
static double benchmark_original(uint64_t iters) {
    xoroshiro128plus_state st;
    xoroshiro128plus_seed(&st, 42);

    clock_t start = clock();
    uint64_t sum=0;
    for(uint64_t i=0;i<iters;i++){
        sum ^= xoroshiro128plus_next(&st);
    }
    clock_t end = clock();
    double secs = (double)(end - start)/CLOCKS_PER_SEC;

    // anti-opt
    if(sum==1) printf("Won't happen: %llu\n",(unsigned long long)sum);
    return secs;
}

// Benchmark the new WyRand approach
static double benchmark_simd(uint64_t iters) {
    wyrand_simd_rng* rng = wyrand_simd_new(42);

    clock_t start = clock();
    uint64_t sum=0;
    for(uint64_t i=0;i<iters;i++){
        sum ^= wyrand_simd_next_u64(rng);
    }
    clock_t end = clock();
    double secs = (double)(end - start)/CLOCKS_PER_SEC;

    if(sum==1) printf("Won't happen: %llu\n",(unsigned long long)sum);
    wyrand_simd_free(rng);
    return secs;
}

// Basic usage example
static void basic_usage_example() {
    printf("Basic Usage with Optimized SIMD WyRand:\n--------------------------------------\n");

    wyrand_simd_rng* rng = wyrand_simd_new(12345ULL);

    printf("First 5 random integers:\n");
    for(int i=0; i<5; i++){
        printf("  %llu\n",(unsigned long long)wyrand_simd_next_u64(rng));
    }
    printf("\nFirst 5 random doubles [0,1):\n");
    for(int i=0; i<5; i++){
        printf("  %f\n", wyrand_simd_next_double(rng));
    }
    wyrand_simd_free(rng);
    printf("\n");
}

// Performance comparison
static void performance_comparison() {
    const uint64_t iters = 100000000ULL; // 100 million
    printf("Performance Comparison:\n-----------------------\n");

    printf("Generating %llu numbers in each generator...\n",(unsigned long long)iters);

    double t1 = benchmark_original(iters);
    double t2 = benchmark_simd(iters);

#ifdef USE_OPENCL
    printf("Detected GPU (OpenCL)\n");
#elif defined(USE_AVX512)
    printf("Detected AVX-512\n");
#elif defined(USE_AVX2)
    printf("Detected AVX2\n");
#elif defined(USE_AVX)
    printf("Detected AVX\n");
#elif defined(USE_NEON)
    printf("Detected NEON\n");
#elif defined(USE_SSE2)
    printf("Detected SSE2\n");
#else
    printf("No SIMD (scalar fallback)\n");
#endif

    printf("xoroshiro128+ time:  %.4f s (%.2f M/s)\n", t1, (iters/t1)/1e6 );
    printf("WyRand Simd time:    %.4f s (%.2f M/s)\n", t2, (iters/t2)/1e6 );
    printf("Speedup: %.2fx\n", t1/t2);
}

// NEW: Provide a function that calls both usage example + comparison:
static inline void run_wyrand_bench() {
    printf("\n=== WYRAND (OPTIMIZED) BENCH ===\n\n");
    basic_usage_example();
    performance_comparison();
}

#endif // WYRAND_RNG_BENCH_OPTIMIZED_H
