// advanced_benchmarking.h
#ifndef ADVANCED_BENCHMARKING_H
#define ADVANCED_BENCHMARKING_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <stdint.h>

// High-precision timer for nanosecond-level measurements
#ifdef _WIN32
    #include <windows.h>
#elif defined(__APPLE__)
    #include <mach/mach_time.h>
#else
    #include <time.h>
#endif

typedef struct {
    // Timing information
    uint64_t total_time_ns;      // Total generation time in nanoseconds
    double   generation_rate;    // Numbers per second
    
    // Comparison metrics
    double   previous_time_ns;   // Previous run time for comparison
    double   performance_delta;  // Percentage change from previous run
    
    // Randomness preview
    struct {
        uint64_t last_integers[5];
        double   last_doubles[5];
    } sample_data;
    
    // Configuration details
    size_t   num_iterations;
    int      algorithm_type;
    int      precision_mode;
    int      implementation_type;
} BenchmarkResult;

// High-precision timer implementation
uint64_t get_nanosecond_timestamp() {
#ifdef _WIN32
    LARGE_INTEGER frequency, timestamp;
    QueryPerformanceFrequency(&frequency);
    QueryPerformanceCounter(&timestamp);
    return (timestamp.QuadPart * 1000000000ULL) / frequency.QuadPart;
#elif defined(__APPLE__)
    static mach_timebase_info_data_t timebase;
    static int initialized = 0;
    if (!initialized) {
        mach_timebase_info(&timebase);
        initialized = 1;
    }
    uint64_t timestamp = mach_absolute_time();
    return (timestamp * timebase.numer) / timebase.denom;
#else
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec * 1000000000ULL + ts.tv_nsec;
#endif
}

// Benchmark function with high-precision timing and sampling
BenchmarkResult* run_precise_benchmark(
    size_t num_iterations, 
    int algorithm_type, 
    int precision_mode,
    BenchmarkResult* previous_result  // Optional previous result for comparison
) {
    // Allocate benchmark result
    BenchmarkResult* result = malloc(sizeof(BenchmarkResult));
    memset(result, 0, sizeof(BenchmarkResult));
    
    // Populate configuration
    result->num_iterations = num_iterations;
    result->algorithm_type = algorithm_type;
    result->precision_mode = precision_mode;
    
    // Create RNG
    universal_rng_t* rng = universal_rng_new(
        time(NULL),  // Seed with current time
        algorithm_type,
        precision_mode
    );
    
    if (!rng) {
        fprintf(stderr, "Failed to create RNG for benchmarking\n");
        free(result);
        return NULL;
    }
    
    // Allocate result storage
    void* results = malloc(
        precision_mode == RNG_PRECISION_SINGLE 
            ? num_iterations * sizeof(float) 
            : num_iterations * sizeof(double)
    );
    
    // High-precision timing
    uint64_t start_time = get_nanosecond_timestamp();
    
    // Batch generation
    universal_rng_next_batch(rng, results, num_iterations);
    
    // Calculate timing
    uint64_t end_time = get_nanosecond_timestamp();
    result->total_time_ns = end_time - start_time;
    result->generation_rate = (double)num_iterations / 
        (result->total_time_ns / 1000000000.0);
    
    // Capture implementation type
    result->implementation_type = rng->implementation_type;
    
    // Sample last 5 values
    if (precision_mode == RNG_PRECISION_SINGLE) {
        float* float_results = (float*)results;
        for (int i = 0; i < 5; i++) {
            result->sample_data.last_doubles[i] = 
                float_results[num_iterations - 5 + i];
        }
    } else {
        double* double_results = (double*)results;
        for (int i = 0; i < 5; i++) {
            result->sample_data.last_doubles[i] = 
                double_results[num_iterations - 5 + i];
        }
    }
    
    // Perform comparison if previous result provided
    if (previous_result) {
        result->previous_time_ns = previous_result->total_time_ns;
        result->performance_delta = 
            ((double)result->total_time_ns - previous_result->total_time_ns) / 
            previous_result->total_time_ns * 100.0;
    }
    
    // Cleanup
    universal_rng_free(rng);
    free(results);
    
    return result;
}

// Export benchmark results to CSV
int export_benchmark_to_csv(BenchmarkResult* result, const char* filename) {
    FILE* csv_file = fopen(filename, "w");
    if (!csv_file) {
        fprintf(stderr, "Failed to open CSV file for writing\n");
        return -1;
    }
    
    // Write CSV header
    fprintf(csv_file, 
        "Iterations,Algorithm,Precision,Implementation,"
        "Total Time (ns),Generation Rate (numbers/sec),"
        "Previous Time (ns),Performance Delta (%)\n"
    );
    
    // Write benchmark results
    fprintf(csv_file, "%zu,%d,%d,%d,%llu,%.2f,%llu,%.2f\n",
        result->num_iterations,
        result->algorithm_type,
        result->precision_mode,
        result->implementation_type,
        result->total_time_ns,
        result->generation_rate,
        result->previous_time_ns,
        result->performance_delta
    );
    
    // Write sample data
    fprintf(csv_file, "\nLast 5 Doubles:\n");
    for (int i = 0; i < 5; i++) {
        fprintf(csv_file, "%.6f\n", result->sample_data.last_doubles[i]);
    }
    
    fclose(csv_file);
    return 0;
}

// Free benchmark result
void free_benchmark_result(BenchmarkResult* result) {
    if (result) {
        free(result);
    }
}

#endif // ADVANCED_BENCHMARKING_H