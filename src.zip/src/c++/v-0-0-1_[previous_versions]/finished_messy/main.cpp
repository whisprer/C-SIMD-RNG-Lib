#include "universal_rng.h"
#include "rng_benchmark.h"
#include <iostream>
#include <iomanip>
#include <vector>
#include <algorithm>

int main(int argc, char** argv) {
    std::cout << "Universal RNG Benchmark\n";
    std::cout << "======================\n\n";
    
    // Parse command line arguments
    bool run_benchmark = true;
    bool export_csv = false;
    uint64_t seed = 42;
    
    for (int i = 1; i < argc; i++) {
        std::string arg = argv[i];
        if (arg == "--no-benchmark") {
            run_benchmark = false;
        } else if (arg == "--export-csv") {
            export_csv = true;
        } else if (arg == "--seed" && i + 1 < argc) {
            try {
                seed = std::stoull(argv[++i]);
            } catch (...) {
                std::cerr << "Invalid seed value: " << argv[i] << std::endl;
                seed = 42;
            }
        } else if (arg == "--help") {
            std::cout << "Usage: " << argv[0] << " [options]\n";
            std::cout << "Options:\n";
            std::cout << "  --no-benchmark     Skip benchmarking, only show examples\n";
            std::cout << "  --export-csv       Export benchmark results to CSV\n";
            std::cout << "  --seed VALUE       Use specific seed value (default: 42)\n";
            std::cout << "  --help             Show this help message\n";
            return 0;
        }
    }
    
    // Display SIMD support information
    std::cout << "Detected SIMD support:\n";
    #ifdef USE_OPENCL
        std::cout << "  - OpenCL: Yes\n";
    #else
        std::cout << "  - OpenCL: No\n";
    #endif
    
    #ifdef USE_AVX512
        std::cout << "  - AVX-512: Yes\n";
    #else
        std::cout << "  - AVX-512: No\n";
    #endif
    
    #ifdef USE_AVX2
        std::cout << "  - AVX2: Yes\n";
    #else
        std::cout << "  - AVX2: No\n";
    #endif
    
    #ifdef USE_AVX
        std::cout << "  - AVX: Yes\n";
    #else
        std::cout << "  - AVX: No\n";
    #endif
    
    #ifdef USE_NEON
        std::cout << "  - NEON: Yes\n";
    #else
        std::cout << "  - NEON: No\n";
    #endif
    
    #ifdef USE_SSE2
        std::cout << "  - SSE2: Yes\n";
    #else
        std::cout << "  - SSE2: No\n";
    #endif
    
    std::cout << "\n";
    
    // Create universal RNGs for both algorithms
    std::cout << "Universal RNG Examples:\n";
    std::cout << "======================\n\n";
    
    // Xoroshiro128++
    rng::UniversalRNG xoroshiro_rng(rng::Algorithm::Xoroshiro128pp, seed);
    std::cout << "Xoroshiro128++ using " << xoroshiro_rng.get_implementation_name() << ":\n";
    std::cout << "First 5 random values:\n";
    for (int i = 0; i < 5; i++) {
        std::cout << "  " << xoroshiro_rng.next_u64() << "\n";
    }
    std::cout << "\n";
    
    // WyRand
    rng::UniversalRNG wyrand_rng(rng::Algorithm::WyRand, seed);
    std::cout << "WyRand using " << wyrand_rng.get_implementation_name() << ":\n";
    std::cout << "First 5 random values:\n";
    for (int i = 0; i < 5; i++) {
        std::cout << "  " << wyrand_rng.next_u64() << "\n";
    }
    std::cout << "\n";
    
    // Batch generation example
    std::vector<uint64_t> batch(10);
    xoroshiro_rng.generate_batch(batch.data(), batch.size());
    
    std::cout << "Batch generation (10 values):\n";
    for (size_t i = 0; i < batch.size(); i++) {
        std::cout << "  " << batch[i] << "\n";
    }
    std::cout << "\n";
    
    // Run benchmarks if requested
    if (run_benchmark) {
        rng::benchmark::BenchmarkConfig config;
        config.seed = seed;
        config.export_csv = export_csv;
        config.display_usage_examples = false; // We already showed examples
        
        auto results = rng::benchmark::run_all_benchmarks(config);
        
        // Find the best performer
        auto best_result = std::max_element(results.begin(), results.end(),
            [](const rng::benchmark::BenchmarkResult& a, const rng::benchmark::BenchmarkResult& b) {
                return a.millions_per_second < b.millions_per_second;
            });
        
        std::cout << "\nBest performer: " << best_result->name << " using " 
                  << best_result->implementation << " ("
                  << std::fixed << std::setprecision(2) << best_result->millions_per_second 
                  << " M/sec)\n";
    }
    
    return 0;
}