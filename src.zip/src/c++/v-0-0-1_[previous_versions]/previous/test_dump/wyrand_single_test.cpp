// wyrand_single_test.cpp
#include <stdio.h>
#include "wyrand_simd_main.h"  // Direct include of the implementation

int main() {
    printf("=== WyRand SIMD Benchmark ===\n\n");
    
    // Create a wyrand_simd_rng directly
    wyrand_simd_rng* rng = wyrand_simd_new(12345ULL);
    
    printf("First 5 random integers:\n");
    for (int i = 0; i < 5; i++) {
        printf("  %llu\n", (unsigned long long)wyrand_simd_next_u64(rng));
    }
    
    printf("\nFirst 5 random doubles [0,1):\n");
    for (int i = 0; i < 5; i++) {
        printf("  %f\n", wyrand_simd_next_double(rng));
    }
    
    wyrand_simd_free(rng);
    
    printf("\nBenchmark complete!\n");
    return 0;
}