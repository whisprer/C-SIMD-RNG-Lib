#include <iostream>
#include <memory>
#include <vector>
#include <functional>

// Forward declarations for bench functions
int run_wyrand_bench();
int run_wyrand_bench_optimized();
int run_xoroshiro_bench();
int run_xoroshiro_bench_optimized();

// Benchmark Runner Class
class BenchmarkRunner {
public:
    // Add benchmark to run list
    void addBenchmark(std::function<int()> benchmark) {
        benchmarks_.push_back(benchmark);
    }

    // Run all added benchmarks
    bool runAll() {
        bool all_successful = true;
        for (const auto& benchmark : benchmarks_) {
            try {
                int result = benchmark();
                if (result != 0) {
                    std::cerr << "Benchmark failed with code: " << result << std::endl;
                    all_successful = false;
                }
            } catch (const std::exception& e) {
                std::cerr << "Benchmark exception: " << e.what() << std::endl;
                all_successful = false;
            }
        }
        return all_successful;
    }

    // Singleton-like access
    static BenchmarkRunner& getInstance() {
        static BenchmarkRunner instance;
        return instance;
    }

private:
    // Private constructor to prevent direct instantiation
    BenchmarkRunner() {
        // Add default benchmarks
        addBenchmark(run_wyrand_bench);
        addBenchmark(run_wyrand_bench_optimized);
        addBenchmark(run_xoroshiro_bench);
        addBenchmark(run_xoroshiro_bench_optimized);
    }

    // Store benchmarks as vector of function objects
    std::vector<std::function<int()>> benchmarks_;
};

int main() {
    try {
        // Get singleton instance and run benchmarks
        auto& runner = BenchmarkRunner::getInstance();
        
        if (!runner.runAll()) {
            std::cerr << "Some benchmarks failed\n";
            return 1;
        }
    } catch (const std::exception& e) {
        std::cerr << "Benchmark runner failed: " << e.what() << std::endl;
        return 1;
    }

    return 0;
}