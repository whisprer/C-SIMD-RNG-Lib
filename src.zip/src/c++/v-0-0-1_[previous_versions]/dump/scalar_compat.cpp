#include <cstdint>
#include <cstddef>

// Simple Xoroshiro128++ scalar implementation
struct ScalarState {
    uint64_t s[2];
};

// Helper function for bit rotation
inline uint64_t rotl(uint64_t x, int k) {
    return (x << k) | (x >> (64 - k));
}

// Wrap in extern "C" to avoid name mangling issues
extern "C" {

// Create new state
void* scalar_new(uint64_t seed) {
    ScalarState* state = new ScalarState();
    
    // Seed using SplitMix64
    uint64_t z = seed + 0x9e3779b97f4a7c15ULL;
    z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
    z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
    state->s[0] = z ^ (z >> 31);
    
    z = state->s[0] + 0x9e3779b97f4a7c15ULL;
    z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
    z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
    state->s[1] = z ^ (z >> 31);
    
    return state;
}

// Get next random value
uint64_t scalar_next_u64(void* state_ptr) {
    ScalarState* state = static_cast<ScalarState*>(state_ptr);
    const uint64_t s0 = state->s[0];
    uint64_t s1 = state->s[1];
    
    // Xoroshiro128++ algorithm
    const uint64_t result = rotl(s0 + s1, 17) + s0;
    
    s1 ^= s0;
    state->s[0] = rotl(s0, 49) ^ s1 ^ (s1 << 21);
    state->s[1] = rotl(s1, 28);
    
    return result;
}

// Get next double
double scalar_next_double(void* state_ptr) {
    return (scalar_next_u64(state_ptr) >> 11) * (1.0 / (1ULL << 53));
}

// Generate batch of random numbers
void scalar_next_batch(void* state_ptr, uint64_t* results, size_t count) {
    for (size_t i = 0; i < count; ++i) {
        results[i] = scalar_next_u64(state_ptr);
    }
}

// Free state
void scalar_free(void* state_ptr) {
    delete static_cast<ScalarState*>(state_ptr);
}

} // extern "C"