#include "wyrand.h"

// Most of the implementation is in the header file since we're using templates
// and inline functions for better performance.
// This file mainly exists to ensure proper instantiation and
// to avoid linking errors with the C API functions.

// Implementation of the C API functions from the header
extern "C" {
    // Functions are already defined in the header
}