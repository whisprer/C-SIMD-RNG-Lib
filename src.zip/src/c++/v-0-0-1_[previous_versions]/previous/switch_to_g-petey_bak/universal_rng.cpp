#include "universal_rng.h"
#include "runtime_detect.h"
#include <cstdio>
#include <cstring>

uint64_t universal_rng_next_u64(universal_rng_t* rng) {
    return rng->next_u64(rng->state);
}

double universal_rng_next_double(universal_rng_t* rng) {
    return rng->next_double(rng->state);
}

void universal_rng_next_batch(universal_rng_t* rng, uint64_t* results, size_t count) {
    rng->next_batch(rng->state, results, count);
}

void universal_rng_free(universal_rng_t* rng) {
    if (!rng) return;

    if (rng->free_func) {
        rng->free_func(rng->state);
    }
    free(rng);
}

const char* universal_rng_get_impl_name(universal_rng_t* rng) {
    return rng ? rng->impl_name : "Unknown";
}

universal_rng_t* universal_rng_new(
    uint64_t seed, 
    RNGAlgorithmType algorithm_type, 
    RNGPrecisionMode precision_mode
) {
    cpu_features_t features;
    detect_cpu_features(&features);

    // Print detected CPU features
    printf("Detected CPU features:\n");
    // ... (existing feature printing)

    universal_rng_t* rng = (universal_rng_t*)malloc(sizeof(universal_rng_t));
    if (!rng) return NULL;
    memset(rng, 0, sizeof(universal_rng_t));

    // Priority order: AVX-512 -> AVX2 -> SSE2 -> Scalar
#ifdef USE_AVX512
    if (features.has_avx512f && features.has_avx512dq) {
        rng->state = avx512_advanced_new(seed);
        rng->next_u64 = avx512_advanced_next_u64;
        rng->next_double = avx512_advanced_next_double;
        rng->next_batch = avx512_advanced_next_batch;
        rng->free_func = avx512_advanced_free;
        rng->implementation_type = 3;  // AVX-512
        rng->impl_name = "AVX-512 (8-way)";
    } else 
#endif
#ifdef USE_AVX2
    if (features.has_avx2) {
        rng->state = avx2_new(seed);
        rng->next_u64 = avx2_next_u64;
        rng->next_double = avx2_next_double;
        rng->next_batch = avx2_next_batch;
        rng->free_func = avx2_free;
        rng->implementation_type = 2;  // AVX2
        rng->impl_name = "AVX2 (4-way)";
    } else 
#endif
#ifdef USE_SSE2
    if (features.has_sse2) {
        rng->state = sse2_new(seed);
        rng->next_u64 = sse2_next_u64;
        rng->next_double = sse2_next_double;
        rng->next_batch = sse2_next_batch;
        rng->free_func = sse2_free;
        rng->implementation_type = 1;  // SSE2
        rng->impl_name = "SSE2 (2-way)";
    } else 
#endif
    {
        // Fallback to scalar implementation
        rng->state = scalar_new(seed);
        rng->next_u64 = scalar_next_u64;
        rng->next_double = scalar_next_double;
        rng->next_batch = scalar_next_batch;
        rng->free_func = scalar_free;
        rng->implementation_type = 0;  // Scalar
        rng->impl_name = "Scalar";
    }

    rng->algorithm_type = algorithm_type;
    rng->precision_mode = precision_mode;

    return rng;
}

// Free the universal RNG
void universal_rng_free(universal_rng_t* rng) {
#ifdef USE_AVX512
    if (strcmp(rng->impl_name, "AVX-512 (8-way)") == 0) {
        avx512_free(rng->state);
    } else 
#endif
#ifdef USE_AVX2
    if (strcmp(rng->impl_name, "AVX2 (4-way)") == 0) {
        avx2_free(rng->state);
    } else 
#endif
#ifdef USE_SSE2
    if (strcmp(rng->impl_name, "SSE2 (2-way)") == 0) {
        sse2_free(rng->state);
    } else 
#endif
    {
        // Scalar implementation
        scalar_free(rng->state);
    }
    
    free(rng);
}

// Get next random value
uint64_t universal_rng_next_u64(universal_rng_t* rng) {
    return rng->next_u64(rng->state);
}

// Get next random double
double universal_rng_next_double(universal_rng_t* rng) {
    return rng->next_double(rng->state);
}

// Get implementation name
const char* universal_rng_get_impl_name(universal_rng_t* rng) {
    return rng->impl_name;
}

// Get a batch of random numbers
void universal_rng_next_batch(universal_rng_t* rng, uint64_t* results, size_t count) {
    rng->next_batch(rng->state, results, count);
}

