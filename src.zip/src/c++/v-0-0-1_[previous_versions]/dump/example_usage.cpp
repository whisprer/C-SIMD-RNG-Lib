#include "universal_rng.h"
#include "rng_benchmark.h"
#include "gpu_optimization_detection.h"
#include "logging_temp.cpp"
#include <iostream>
#include <memory>
#include <stdexcept>

// Example RNG Usage and Performance Analysis
class RNGPerformanceAnalyzer {
public:
    // Run comprehensive RNG benchmark
    void runBenchmark() {
        const size_t iterations = 100'000'000;
        
        try {
            // Create benchmark configuration
            auto benchmark = RNGBenchmarkConfig::create(
                iterations, 
                RNG_ALGORITHM_XOROSHIRO, 
                RNG_PRECISION_DOUBLE
            );

            // Run the benchmark
            if (!benchmark->run()) {
                log_message(LOG_ERROR, "Benchmark failed to run");
                return;
            }

            // Export results to CSV
            std::string csv_path = "xoroshiro_performance.csv";
            benchmark->export_to_csv(csv_path);
            std::cout << "Benchmark results exported to: " << csv_path << std::endl;

            // Analyze GPU capabilities
            analyzeGPUCapabilities();

        } catch (const std::exception& e) {
            log_message(LOG_CRITICAL, "Benchmark error: %s", e.what());
        }
    }

private:
    // Analyze GPU device capabilities
    void analyzeGPUCapabilities() {
        // Detect GPU capabilities
        auto gpu_caps = detect_gpu_capabilities();
        
        if (gpu_caps) {
            // Print detailed GPU information
            gpu_caps->printDetails();

            // Get optimization recommendations
            auto recommendations = gpu_caps->getOptimizationRecommendations();
            
            if (!recommendations.empty()) {
                std::cout << "\nGPU Optimization Recommendations:\n";
                for (const auto& rec : recommendations) {
                    std::cout << "- " << rec << std::endl;
                }
            }
        } else {
            log_message(LOG_WARNING, "No GPU capabilities detected");
        }
    }
};

// Main function demonstrating RNG usage and performance analysis
int main() {
    try {
        // Create and run performance analyzer
        RNGPerformanceAnalyzer analyzer;
        analyzer.runBenchmark();

        return 0;
    } catch (const std::exception& e) {
        std::cerr << "Critical error: " << e.what() << std::endl;
        return 1;
    }
}
