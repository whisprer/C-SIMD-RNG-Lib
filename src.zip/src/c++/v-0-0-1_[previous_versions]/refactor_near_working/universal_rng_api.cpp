#include "rng_includes.h"
#include "universal_rng_types.h"

// Include implementations for AVX2, SSE2, AVX512, and scalar
#include "avx2_impl.h"
#include "sse2_impl.h"
#include "avx512_impl.h"
#include "scalar_impl.h"

extern "C" {

universal_rng_t* universal_rng_new(uint64_t seed, int algorithm_type, int precision_mode) {
    std::cout << "Creating RNG...\n";
    
    // Create a new universal RNG - CRITICAL: Avoid initializer list
    universal_rng_t* rng = new universal_rng_t;
    
    // Initialize all fields explicitly one by one
    rng->state = nullptr;
    rng->next_u64 = nullptr;
    rng->next_double = nullptr;
    rng->generate_batch = nullptr;
    rng->free_func = nullptr;
    rng->implementation_type = RNG_IMPL_SCALAR; // Default to scalar
    rng->algorithm_type = static_cast<RNGAlgorithmType>(algorithm_type);
    rng->precision_mode = static_cast<RNGPrecisionMode>(precision_mode);
    
    // Detect best available implementation
    void* state = nullptr;
    
    #ifdef USE_AVX512
        // Try AVX512 first if available
        std::cout << "Trying AVX512 implementation...\n";
        state = avx512_new(seed);
        if (state) {
            std::cout << "Using AVX512 implementation\n";
            rng->implementation_type = RNG_IMPL_AVX512;
            rng->next_u64 = reinterpret_cast<uint64_t(*)(void*)>(avx512_next_u64);
            rng->next_double = reinterpret_cast<double(*)(void*)>(avx512_next_double);
            rng->generate_batch = avx512_next_batch;
            rng->free_func = avx512_free;
        }
    #endif
    
    // If AVX512 failed or wasn't available, try AVX2
    if (!state) {
        #ifdef USE_AVX2
            std::cout << "Trying AVX2 implementation...\n";
            state = avx2_new(seed);
            if (state) {
                std::cout << "Using AVX2 implementation\n";
                rng->implementation_type = RNG_IMPL_AVX2;
                rng->next_u64 = reinterpret_cast<uint64_t(*)(void*)>(avx2_next_u64);
                rng->next_double = reinterpret_cast<double(*)(void*)>(avx2_next_double);
                rng->generate_batch = avx2_next_batch;
                rng->free_func = avx2_free;
            }
        #endif
    }
    
    // If AVX2 failed or wasn't available, try SSE2
    if (!state) {
        #ifdef USE_SSE2
            std::cout << "Trying SSE2 implementation...\n";
            state = sse2_new(seed);
            if (state) {
                std::cout << "Using SSE2 implementation\n";
                rng->implementation_type = RNG_IMPL_SSE2;
                rng->next_u64 = reinterpret_cast<uint64_t(*)(void*)>(sse2_next_u64);
                rng->next_double = reinterpret_cast<double(*)(void*)>(sse2_next_double);
                rng->generate_batch = sse2_next_batch;
                rng->free_func = sse2_free;
            }
        #endif
    }
    
    // If previous implementations failed, fall back to scalar
    if (!state) {
        std::cout << "Using scalar implementation\n";
        state = scalar_new(seed);
        if (state) {
            rng->implementation_type = RNG_IMPL_SCALAR;
            rng->next_u64 = scalar_next_u64;
            rng->next_double = scalar_next_double;
            rng->generate_batch = scalar_next_batch;
            rng->free_func = scalar_free;
        }
    }
    
    // If all implementations failed, clean up and return nullptr
    if (!state) {
        std::cout << "Failed to create any RNG implementation\n";
        delete rng;
        return nullptr;
    }
    
    // Set the state last
    rng->state = state;
    std::cout << "RNG created successfully\n";
    return rng;
}

uint64_t universal_rng_next_u64(universal_rng_t* rng) {
    if (rng && rng->next_u64 && rng->state) {
        return rng->next_u64(rng->state);
    }
    return 0;
}

double universal_rng_next_double(universal_rng_t* rng) {
    if (rng && rng->next_double && rng->state) {
        return rng->next_double(rng->state);
    }
    return 0.0;
}

void universal_rng_generate_batch(universal_rng_t* rng, uint64_t* results, size_t count) {
    if (rng && rng->generate_batch && rng->state && results) {
        rng->generate_batch(rng->state, results, count);
    }
}

const char* universal_rng_get_implementation(universal_rng_t* rng) {
    if (!rng) return "Invalid RNG";
    
    std::string impl_name;
    
    // Get implementation name
    switch (rng->implementation_type) {
        case RNG_IMPL_SCALAR:
            impl_name = "Scalar";
            break;
        case RNG_IMPL_SSE2:
            impl_name = "SSE2";
            break;
        case RNG_IMPL_AVX2:
            impl_name = "AVX2";
            break;
        case RNG_IMPL_AVX512:
            impl_name = "AVX-512";
            break;
        default:
            impl_name = "Unknown";
            break;
    }
    
    // Get algorithm name
    switch (rng->algorithm_type) {
        case RNG_ALGORITHM_XOROSHIRO:
            impl_name += " Xoroshiro128++";
            break;
        case RNG_ALGORITHM_WYRAND:
            impl_name += " WyRand";
            break;
        default:
            impl_name += " Unknown Algorithm";
            break;
    }
    
    // Allocate and return string
    char* result = new char[impl_name.length() + 1];
    strcpy(result, impl_name.c_str());
    return result;
}

void universal_rng_free_string(const char* str) {
    delete[] str;
}

void universal_rng_free(universal_rng_t* rng) {
    if (rng) {
        if (rng->free_func && rng->state) {
            rng->free_func(rng->state);
        }
        delete rng;
    }
}

}  // extern "C"