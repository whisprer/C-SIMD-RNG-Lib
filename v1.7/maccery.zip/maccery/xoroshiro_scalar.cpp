#include "ua/ua_xoshiro256ss_scalar.h"
// TU intentionally minimal; header-only implementation is fine.
