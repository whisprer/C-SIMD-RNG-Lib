// opencl_rng_integration.h
#ifndef OPENCL_RNG_INTEGRATION_H
#define OPENCL_RNG_INTEGRATION_H

#include "universal_rng.h"
#include "opencl_rng_kernels.h"

// OpenCL-specific RNG creation function
universal_rng_t* create_opencl_universal_rng(
    uint64_t seed, 
    RNGAlgorithmType algorithm,
    RNGPrecisionMode precision
) {
    universal_rng_t* rng = malloc(sizeof(universal_rng_t));
    
    // Try to create OpenCL RNG state
    OpenCLRNGState* opencl_state = create_opencl_rng(
        seed, 
        DEFAULT_BATCH_SIZE,  // Define a reasonable default
        precision,
        algorithm == RNG_ALGORITHM_XOROSHIRO ? 0 : 1
    );
    
    if (!opencl_state) {
        log_message(LOG_WARNING, "OpenCL RNG initialization failed. Falling back to CPU implementation.");
        free(rng);
        return NULL;
    }
    
    // Populate universal RNG structure
    rng->state = opencl_state;
    rng->algorithm_type = algorithm;
    rng->precision_mode = precision;
    rng->implementation_type = RNG_IMPL_OPENCL;
    
    // Set function pointers
    rng->next_u64 = opencl_rng_next_u64;
    rng->next_double = opencl_rng_next_double;
    rng->next_batch = opencl_rng_next_batch;
    rng->free_func = opencl_rng_free;
    
    return rng;
}

// OpenCL-specific next_u64 implementation
uint64_t opencl_rng_next_u64(void* state) {
    OpenCLRNGState* opencl_state = (OpenCLRNGState*)state;
    
    // Regenerate batch if needed
    if (opencl_state->current_batch_pos >= opencl_state->batch_size) {
        if (generate_random_batch(opencl_state) != 0) {
            log_message(LOG_ERROR, "Failed to generate OpenCL random batch");
            return 0;  // Fallback value
        }
        opencl_state->current_batch_pos = 0;
    }
    
    // Return next value from batch
    return ((uint64_t*)opencl_state->host_results)[opencl_state->current_batch_pos++];
}

// OpenCL-specific next_double implementation
double opencl_rng_next_double(void* state) {
    OpenCLRNGState* opencl_state = (OpenCLRNGState*)state;
    
    // Ensure double precision
    if (opencl_state->precision_mode != RNG_PRECISION_DOUBLE) {
        log_message(LOG_WARNING, "Requested double in non-double precision mode");
    }
    
    // Regenerate batch if needed
    if (opencl_state->current_batch_pos >= opencl_state->batch_size) {
        if (generate_random_batch(opencl_state) != 0) {
            log_message(LOG_ERROR, "Failed to generate OpenCL random batch");
            return 0.0;  // Fallback value
        }
        opencl_state->current_batch_pos = 0;
    }
    
    // Return next double from batch
    return ((double*)opencl_state->host_doubles)[opencl_state->current_batch_pos++];
}

// OpenCL-specific batch generation
void opencl_rng_next_batch(void* state, uint64_t* results, size_t count) {
    OpenCLRNGState* opencl_state = (OpenCLRNGState*)state;
    
    // Validate batch size
    if (count > opencl_state->batch_size) {
        log_message(LOG_WARNING, "Requested batch size exceeds pre-allocated size");
        count = opencl_state->batch_size;
    }
    
    // Regenerate batch
    if (generate_random_batch(opencl_state) != 0) {
        log_message(LOG_ERROR, "Failed to generate OpenCL random batch");
        memset(results, 0, count * sizeof(uint64_t));
        return;
    }
    
    // Copy results
    memcpy(results, opencl_state->host_results, count * sizeof(uint64_t));
}

// OpenCL-specific free function
void opencl_rng_free(void* state) {
    if (state) {
        free_opencl_rng((OpenCLRNGState*)state);
    }
}

#endif // OPENCL_RNG_INTEGRATION_H