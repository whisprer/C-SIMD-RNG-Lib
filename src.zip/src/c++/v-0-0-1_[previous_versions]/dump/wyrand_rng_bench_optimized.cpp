#include "wyrand_rng_bench_optimized.h"
// Everything is in the header, so nothing else needed.