#ifndef XOROSHIRO128PP_RNG_BENCH_OPTIMIZED_H
#define XOROSHIRO128PP_RNG_BENCH_OPTIMIZED_H

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <string.h>

// Include the streamlined xorshiro128++ SIMD implementation
// Originally "simd-xoroshiro128pp-optimized.h", now "xoroshiro128pp_simd_main_optimized.h"
#include "xoroshiro128pp_simd_main_optimized.h"

// For a reference baseline, let's define a trivial XORShift or xoshiro128+ for comparison
typedef struct {
    uint64_t s[2];
} xoroshiro128plus_state;

// rotl helper
static inline uint64_t rotl_64(const uint64_t x, int k) {
    return (x << k) | (x >> (64 - k));
}

// A simpler xorshiro128+ used just for baseline
static inline uint64_t xoroshiro128plus_next(xoroshiro128plus_state* st) {
    uint64_t s0 = st->s[0];
    uint64_t s1 = st->s[1];
    uint64_t result = s0 + s1;

    s1 ^= s0;
    st->s[0] = rotl_64(s0, 24) ^ s1 ^ (s1 << 16);
    st->s[1] = rotl_64(s1, 37);
    return result;
}

static inline void xoroshiro128plus_seed(xoroshiro128plus_state* st, uint64_t seed) {
    // Very quick splitmix64
    uint64_t z = seed + 0x9e3779b97f4a7c15ULL;
    z ^= (z >> 30); z *= 0xbf58476d1ce4e5b9ULL; z ^= (z >> 27); z *= 0x94d049bb133111ebULL;
    st->s[0] = z ^ (z >> 31);

    z = st->s[0] + 0x9e3779b97f4a7c15ULL;
    z ^= (z >> 30); z *= 0xbf58476d1ce4e5b9ULL; z ^= (z >> 27); z *= 0x94d049bb133111ebULL;
    st->s[1] = z ^ (z >> 31);
}

// Compare performance of "xoroshiro128+" baseline vs. our new "xoroshiro128++" optimized
static double benchmark_original(uint64_t iters) {
    xoroshiro128plus_state st;
    xoroshiro128plus_seed(&st, 42ULL);

    clock_t start = clock();
    uint64_t sum = 0;
    for(uint64_t i=0; i<iters; i++){
        sum ^= xoroshiro128plus_next(&st);
    }
    clock_t end = clock();
    double sec = (double)(end - start)/CLOCKS_PER_SEC;
    if(sum==1) printf("No-opt: %llu\n",(unsigned long long)sum);
    return sec;
}

static double benchmark_simd(uint64_t iters) {
    xorshiro128pp_simd_rng* rng = xorshiro128pp_simd_new(42ULL);
    clock_t start = clock();
    uint64_t sum=0;
    for(uint64_t i=0; i<iters; i++){
        sum ^= xorshiro128pp_simd_next_u64(rng);
    }
    clock_t end = clock();
    double sec = (double)(end - start)/CLOCKS_PER_SEC;
    if(sum==1) printf("No-opt: %llu\n",(unsigned long long)sum);

    xorshiro128pp_simd_free(rng);
    return sec;
}

static void basic_usage_example() {
    printf("Basic Usage of xorshiro128++ (optimized) Example:\n");
    printf("----------------------------------------------\n");

    xorshiro128pp_simd_rng* rng = xorshiro128pp_simd_new(12345ULL);

    printf("First 5 random integers:\n");
    for(int i=0; i<5; i++){
        printf("  %llu\n",(unsigned long long)xorshiro128pp_simd_next_u64(rng));
    }

    printf("\nFirst 5 random doubles in [0,1):\n");
    for(int i=0; i<5; i++){
        printf("  %f\n", xorshiro128pp_simd_next_double(rng));
    }

    xorshiro128pp_simd_free(rng);
    printf("\n");
}

static void performance_comparison() {
    const uint64_t iters = 100000000ULL; // 100 million

    printf("Performance Comparison:\n-----------------------\n");

#ifdef USE_OPENCL
    printf("Detected GPU (OpenCL)\n");
#elif defined(USE_AVX512)
    printf("Detected AVX-512\n");
#elif defined(USE_AVX2)
    printf("Detected AVX2\n");
#elif defined(USE_AVX)
    printf("Detected AVX\n");
#elif defined(USE_NEON)
    printf("Detected NEON\n");
#elif defined(USE_SSE2)
    printf("Detected SSE2\n");
#else
    printf("No SIMD (scalar fallback)\n");
#endif

    printf("Generating %llu random numbers in each generator...\n",(unsigned long long)iters);

    double t1 = benchmark_original(iters);
    double t2 = benchmark_simd(iters);

    printf("xoroshiro128+ (baseline) : %.4f s (%.2f M/s)\n", t1, (iters/t1)/1e6 );
    printf("xoroshiro128++ (optimized): %.4f s (%.2f M/s)\n", t2, (iters/t2)/1e6 );
    printf("Speedup: %.2fx\n", t1/t2);
}

// main in the header for convenience
int main() {
    basic_usage_example();
    performance_comparison();
    return 0;
}

#endif // XOROSHIRO128PP_RNG_BENCH_OPTIMIZED_H
