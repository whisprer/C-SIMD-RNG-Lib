#ifndef XOROSHIRO128PP_RNG_BENCH_OPTIMIZED_H
#define XOROSHIRO128PP_RNG_BENCH_OPTIMIZED_H

#include <iostream>
#include <iomanip>
#include <string>
#include <chrono>
#include <memory>
#include <array>
#include <cstdint>
#include <functional>

// Include the streamlined xorshiro128++ SIMD implementation
#include "xoroshiro128pp_simd_main_optimized.h"
#include "verbose_mode.h"

namespace rng {
namespace benchmark {

// Modern C++ version of xoroshiro128+ for baseline comparison
class Xoroshiro128Plus {
public:
    explicit Xoroshiro128Plus(uint64_t seed) {
        seed_state(seed);
    }
    
    uint64_t next() {
        const uint64_t s0 = state_[0];
        uint64_t s1 = state_[1];
        const uint64_t result = s0 + s1;

        s1 ^= s0;
        state_[0] = rotl(s0, 24) ^ s1 ^ (s1 << 16);
        state_[1] = rotl(s1, 37);
        
        return result;
    }
    
private:
    std::array<uint64_t, 2> state_;
    
    // Helper for bit rotation
    static constexpr uint64_t rotl(uint64_t x, int k) {
        return (x << k) | (x >> (64 - k));
    }
    
    // Seed the RNG using splitmix64
    void seed_state(uint64_t seed) {
        uint64_t z = seed + 0x9e3779b97f4a7c15ULL;
        z ^= (z >> 30); z *= 0xbf58476d1ce4e5b9ULL; z ^= (z >> 27); z *= 0x94d049bb133111ebULL;
        state_[0] = z ^ (z >> 31);

        z = state_[0] + 0x9e3779b97f4a7c15ULL;
        z ^= (z >> 30); z *= 0xbf58476d1ce4e5b9ULL; z ^= (z >> 27); z *= 0x94d049bb133111ebULL;
        state_[1] = z ^ (z >> 31);
    }
};

// Template function for benchmarking
template<typename Func>
auto measure_execution_time(Func&& func) {
    auto start = std::chrono::high_resolution_clock::now();
    auto result = std::forward<Func>(func)();
    auto end = std::chrono::high_resolution_clock::now();
    
    std::chrono::duration<double> duration = end - start;
    return std::make_pair(duration.count(), result);
}

// Benchmark original xoroshiro128+
double benchmark_original(uint64_t iters) {
    Xoroshiro128Plus rng(42ULL);
    
    auto [time, sum] = measure_execution_time([&rng, iters]() {
        uint64_t sum = 0;
        for (uint64_t i = 0; i < iters; i++) {
            sum ^= rng.next();
        }
        return sum;
    });
    
    // Prevent optimization
    if (sum == 1) {
        std::cout << "No-opt: " << sum << std::endl;
    }
    
    return time;
}

// Benchmark optimized SIMD implementation
double benchmark_simd(uint64_t iters) {
    auto rng = std::unique_ptr<xorshiro128pp_simd_rng, decltype(&xorshiro128pp_simd_free)>(
        xorshiro128pp_simd_new(42ULL), xorshiro128pp_simd_free);
    
    auto [time, sum] = measure_execution_time([&rng, iters]() {
        uint64_t sum = 0;
        for (uint64_t i = 0; i < iters; i++) {
            sum ^= xorshiro128pp_simd_next_u64(rng.get());
        }
        return sum;
    });
    
    // Prevent optimization
    if (sum == 1) {
        std::cout << "No-opt: " << sum << std::endl;
    }
    
    return time;
}

// Basic usage example
void basic_usage_example() {
    std::cout << "Basic Usage of xorshiro128++ (optimized) Example:" << std::endl;
    std::cout << "----------------------------------------------" << std::endl;

    auto rng = std::unique_ptr<xorshiro128pp_simd_rng, decltype(&xorshiro128pp_simd_free)>(
        xorshiro128pp_simd_new(12345ULL), xorshiro128pp_simd_free);

    std::cout << "First 5 random integers:" << std::endl;
    for (int i = 0; i < 5; i++) {
        std::cout << "  " << xorshiro128pp_simd_next_u64(rng.get()) << std::endl;
    }

    std::cout << "\nFirst 5 random doubles in [0,1):" << std::endl;
    for (int i = 0; i < 5; i++) {
        std::cout << "  " << std::fixed << std::setprecision(6) 
                  << xorshiro128pp_simd_next_double(rng.get()) << std::endl;
    }

    std::cout << std::endl;
}

// Performance comparison
void performance_comparison() {
    const uint64_t iters = 100000000ULL; // 100 million

    std::cout << "Performance Comparison:" << std::endl;
    std::cout << "-----------------------" << std::endl;

    // Display detected SIMD capabilities
    #ifdef USE_OPENCL
        std::cout << "Detected GPU (OpenCL)" << std::endl;
    #elif defined(USE_AVX512)
        std::cout << "Detected AVX-512" << std::endl;
    #elif defined(USE_AVX2)
        std::cout << "Detected AVX2" << std::endl;
    #elif defined(USE_AVX)
        std::cout << "Detected AVX" << std::endl;
    #elif defined(USE_NEON)
        std::cout << "Detected NEON" << std::endl;
    #elif defined(USE_SSE2)
        std::cout << "Detected SSE2" << std::endl;
    #else
        std::cout << "No SIMD (scalar fallback)" << std::endl;
    #endif

    std::cout << "Generating " << iters << " random numbers in each generator..." << std::endl;

    double t1 = benchmark_original(iters);
    double t2 = benchmark_simd(iters);

    std::cout << "xoroshiro128+ (baseline) : " << std::fixed << std::setprecision(4) 
              << t1 << " s (" << std::setprecision(2) << (iters/t1)/1e6 << " M/s)" << std::endl;
    std::cout << "xoroshiro128++ (optimized): " << std::fixed << std::setprecision(4) 
              << t2 << " s (" << std::setprecision(2) << (iters/t2)/1e6 << " M/s)" << std::endl;
    std::cout << "Speedup: " << std::fixed << std::setprecision(2) << t1/t2 << "x" << std::endl;
}

} // namespace benchmark
} // namespace rng

// C-compatible function for backward compatibility
extern "C" {

// Function to run both usage example and performance comparison
void run_xoroshiro_non_bench() {
    std::cout << "\n=== XOROSHIRO (NON-OPTIMIZED) BENCH ===\n" << std::endl;
    rng::benchmark::basic_usage_example();
    rng::benchmark::performance_comparison();
}

} // extern "C"

#endif // XOROSHIRO128PP_RNG_BENCH_OPTIMIZED_H