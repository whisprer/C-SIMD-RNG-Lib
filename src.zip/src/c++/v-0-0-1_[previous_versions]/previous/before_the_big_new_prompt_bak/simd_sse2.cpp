#include "universal_rng.h"

#ifdef USE_SSE2
#include <emmintrin.h>
#include <cstring>
#include <stdexcept>

// SSE2 implementation of xoroshiro128++ for 2 parallel streams
class SSE2RNGState {
public:
    __m128i s0;  // First 128-bit register (2 uint64_t values)
    __m128i s1;  // Second 128-bit register (2 uint64_t values)
    uint64_t results[2]; // To store extracted results
    int next_idx;        // Index for the next value to return

    SSE2RNGState() : next_idx(2) {}
};

// Helper function for SSE2 bit rotation
static inline __m128i rotl_sse2(__m128i x, int k) {
    return _mm_or_si128(
        _mm_slli_epi64(x, k),
        _mm_srli_epi64(x, 64 - k)
    );
}

// Create a new SSE2 RNG state
void* sse2_new(uint64_t seed) {
    SSE2RNGState* state = new SSE2RNGState();
    
    // Initialize 2 parallel generators with different seeds
    uint64_t seeds[2] = {seed, seed + 1};
    uint64_t s0_vals[2];
    uint64_t s1_vals[2];
    
    for (int i = 0; i < 2; i++) {
        // Use SplitMix64 seeding for each stream
        uint64_t z = (seeds[i] + 0x9e3779b97f4a7c15ULL);
        z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
        z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
        s0_vals[i] = z ^ (z >> 31);
        
        z = (s0_vals[i] + 0x9e3779b97f4a7c15ULL);
        z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
        z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
        s1_vals[i] = z ^ (z >> 31);
    }
    
    // Load initial states into SSE2 registers
    state->s0 = _mm_loadu_si128((__m128i*)s0_vals);
    state->s1 = _mm_loadu_si128((__m128i*)s1_vals);
    
    // Pre-generate first batch of random numbers
    _mm_storeu_si128((__m128i*)state->results, 
        _mm_add_epi64(
            rotl_sse2(_mm_add_epi64(state->s0, state->s1), 17), 
            state->s0
        )
    );
    
    return state;
}

// Free SSE2 RNG state
void sse2_free(void* state_ptr) {
    if (state_ptr) {
        delete static_cast<SSE2RNGState*>(state_ptr);
    }
}

// Generate next 64-bit random number
uint64_t sse2_next_u64(void* state_ptr) {
    SSE2RNGState* state = static_cast<SSE2RNGState*>(state_ptr);
    
    // If we've used all pre-generated numbers, generate a new batch
    if (state->next_idx >= 2) {
        // Calculate new state and results
        __m128i s0 = state->s0;
        __m128i s1 = state->s1;
        
        // Calculate result: rotl(s0 + s1, 17) + s0
        __m128i sum = _mm_add_epi64(s0, s1);
        __m128i rotated_sum = rotl_sse2(sum, 17);
        __m128i result_vec = _mm_add_epi64(rotated_sum, s0);
        
        // Store results
        _mm_storeu_si128((__m128i*)state->results, result_vec);
        
        // Update state
        s1 = _mm_xor_si128(s1, s0);
        state->s0 = _mm_xor_si128(
                        rotl_sse2(s0, 49),
                        _mm_xor_si128(
                            s1,
                            _mm_slli_epi64(s1, 21)
                        )
                    );
        state->s1 = rotl_sse2(s1, 28);
        
        // Reset index
        state->next_idx = 0;
    }
    
    // Return next pre-generated number
    return state->results[state->next_idx++];
}

// Generate next random double in [0,1) range
double sse2_next_double(void* state) {
    // Convert to double using high 53 bits
    return (sse2_next_u64(state) >> 11) * (1.0 / (1ULL << 53));
}

// Generate a batch of random numbers
void sse2_next_batch(void* state_ptr, uint64_t* results, size_t count) {
    SSE2RNGState* state = static_cast<SSE2RNGState*>(state_ptr);
    size_t generated = 0;
    
    while (generated < count) {
        // How many values can we get from current batch
        size_t available = 2 - state->next_idx;
        size_t to_copy = (available < (count - generated)) ? available : (count - generated);
        
        // Copy values from current batch
        memcpy(results + generated, state->results + state->next_idx, 
               to_copy * sizeof(uint64_t));
               
        generated += to_copy;
        state->next_idx += to_copy;
        
        // If we need more values, generate a new batch
        if (state->next_idx >= 2 && generated < count) {
            // Update SIMD state and generate new batch
            __m128i s0 = state->s0;
            __m128i s1 = state->s1;
            
            // Calculate result: rotl(s0 + s1, 17) + s0
            __m128i sum = _mm_add_epi64(s0, s1);
            __m128i rotated_sum = rotl_sse2(sum, 17);
            __m128i result_vec = _mm_add_epi64(rotated_sum, s0);
            
            // Store results
            _mm_storeu_si128((__m128i*)state->results, result_vec);
            
            // Update state
            s1 = _mm_xor_si128(s1, s0);
            state->s0 = _mm_xor_si128(
                        rotl_sse2(s0, 49),
                        _mm_xor_si128(
                            s1,
                            _mm_slli_epi64(s1, 21)
                        )
                    );
            state->s1 = rotl_sse2(s1, 28);
            
            state->next_idx = 0;
        }
    }
}

#endif // USE_SSE2
