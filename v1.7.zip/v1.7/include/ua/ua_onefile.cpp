mkdir -p /d/tmp/uabench
cd /d/tmp/uabench
pwd    # should print /d/tmp/uabench
