#ifndef XOROSHIRO128PP_H
#define XOROSHIRO128PP_H

#include "rng_common.h"

namespace rng {

class Xoroshiro128PlusPlus {
public:
    explicit Xoroshiro128PlusPlus(uint64_t seed = 0) {
        seed_state(seed);
    }
    
    // Copy operations
    Xoroshiro128PlusPlus(const Xoroshiro128PlusPlus&) = default;
    Xoroshiro128PlusPlus& operator=(const Xoroshiro128PlusPlus&) = default;
    
    // Move operations
    Xoroshiro128PlusPlus(Xoroshiro128PlusPlus&&) noexcept = default;
    Xoroshiro128PlusPlus& operator=(Xoroshiro128PlusPlus&&) noexcept = default;
    
    // Default destructor is fine - no resources
    ~Xoroshiro128PlusPlus() = default;
    
    // Generate next 64-bit unsigned integer
    uint64_t next_u64() {
        const uint64_t s0 = m_state[0];
        uint64_t s1 = m_state[1];
        const uint64_t result = rotl64(s0 + s1, 17) + s0;
        
        s1 ^= s0;
        m_state[0] = rotl64(s0, 49) ^ s1 ^ (s1 << 21);
        m_state[1] = rotl64(s1, 28);
        
        return result;
    }
    
    // Generate a random double in range [0, 1)
    double next_double() {
        // Convert to a double between [0, 1) using the high 53 bits
        return static_cast<double>(next_u64() >> 11) * (1.0 / (1ULL << 53));
    }
    
    // Seed the generator (using SplitMix64 algorithm)
    void seed_state(uint64_t seed) {
        uint64_t z = seed + 0x9e3779b97f4a7c15ULL;
        z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
        z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
        m_state[0] = z ^ (z >> 31);
        
        z = m_state[0] + 0x9e3779b97f4a7c15ULL;
        z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
        z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
        m_state[1] = z ^ (z >> 31);
    }
    
    // Jump ahead by 2^64 calls to next_u64()
    void jump() {
        static const std::array<uint64_t, 2> JUMP = { 0x2bd7a6a6e99c2ddc, 0x0992ccaf6a6fca05 };
        
        std::array<uint64_t, 2> s = {0, 0};
        for(size_t i = 0; i < JUMP.size(); i++) {
            for(int b = 0; b < 64; b++) {
                if (JUMP[i] & (1ULL << b)) {
                    s[0] ^= m_state[0];
                    s[1] ^= m_state[1];
                }
                next_u64();
            }
        }
        
        m_state = s;
    }
    
    // Long jump ahead by 2^96 calls to next_u64()
    void long_jump() {
        static const std::array<uint64_t, 2> LONG_JUMP = { 0x360fd5f2cf8d5d99, 0x9c6e6877736c46e3 };
        
        std::array<uint64_t, 2> s = {0, 0};
        for(size_t i = 0; i < LONG_JUMP.size(); i++) {
            for(int b = 0; b < 64; b++) {
                if (LONG_JUMP[i] & (1ULL << b)) {
                    s[0] ^= m_state[0];
                    s[1] ^= m_state[1];
                }
                next_u64();
            }
        }
        
        m_state = s;
    }
    
private:
    std::array<uint64_t, 2> m_state;
};

// The original xoroshiro128+ algorithm (for benchmarking comparison)
class Xoroshiro128Plus {
public:
    explicit Xoroshiro128Plus(uint64_t seed = 0) {
        seed_state(seed);
    }
    
    // Copy operations
    Xoroshiro128Plus(const Xoroshiro128Plus&) = default;
    Xoroshiro128Plus& operator=(const Xoroshiro128Plus&) = default;
    
    // Move operations
    Xoroshiro128Plus(Xoroshiro128Plus&&) noexcept = default;
    Xoroshiro128Plus& operator=(Xoroshiro128Plus&&) noexcept = default;
    
    // Default destructor is fine - no resources
    ~Xoroshiro128Plus() = default;
    
    // Generate next 64-bit unsigned integer
    uint64_t next_u64() {
        const uint64_t s0 = m_state[0];
        uint64_t s1 = m_state[1];
        const uint64_t result = s0 + s1;
        
        s1 ^= s0;
        m_state[0] = rotl64(s0, 24) ^ s1 ^ (s1 << 16);
        m_state[1] = rotl64(s1, 37);
        
        return result;
    }
    
    // Generate a random double in range [0, 1)
    double next_double() {
        return static_cast<double>(next_u64() >> 11) * (1.0 / (1ULL << 53));
    }
    
    // Seed the generator
    void seed_state(uint64_t seed) {
        uint64_t z = seed + 0x9e3779b97f4a7c15ULL;
        z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
        z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
        m_state[0] = z ^ (z >> 31);
        
        z = m_state[0] + 0x9e3779b97f4a7c15ULL;
        z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
        z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
        m_state[1] = z ^ (z >> 31);
    }
    
private:
    std::array<uint64_t, 2> m_state;
};

// SIMD-optimized implementation of xoroshiro128++
class Xoroshiro128PpSimd {
public:
    explicit Xoroshiro128PpSimd(uint64_t seed = 0) 
        : m_state(std::make_unique<std::array<uint64_t, 2>>()) {
        seed_state(seed);
    }
    
    // Rule of five implementation
    ~Xoroshiro128PpSimd() = default;
    
    Xoroshiro128PpSimd(const Xoroshiro128PpSimd& other) 
        : m_state(std::make_unique<std::array<uint64_t, 2>>(*other.m_state)) {
    }
    
    Xoroshiro128PpSimd& operator=(const Xoroshiro128PpSimd& other) {
        if (this != &other) {
            *m_state = *other.m_state;
        }
        return *this;
    }
    
    Xoroshiro128PpSimd(Xoroshiro128PpSimd&& other) noexcept = default;
    Xoroshiro128PpSimd& operator=(Xoroshiro128PpSimd&& other) noexcept = default;
    
    // Generate next 64-bit unsigned integer
    uint64_t next_u64() {
        const uint64_t s0 = (*m_state)[0];
        uint64_t s1 = (*m_state)[1];
        const uint64_t result = rotl64(s0 + s1, 17) + s0;
        
        s1 ^= s0;
        (*m_state)[0] = rotl64(s0, 49) ^ s1 ^ (s1 << 21);
        (*m_state)[1] = rotl64(s1, 28);
        
        return result;
    }
    
    // Generate a random double in range [0, 1)
    double next_double() {
        return static_cast<double>(next_u64() >> 11) * (1.0 / (1ULL << 53));
    }
    
    // Seed the generator
    void seed_state(uint64_t seed) {
        uint64_t z = seed + 0x9e3779b97f4a7c15ULL;
        z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
        z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
        (*m_state)[0] = z ^ (z >> 31);
        
        z = (*m_state)[0] + 0x9e3779b97f4a7c15ULL;
        z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
        z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
        (*m_state)[1] = z ^ (z >> 31);
    }
    
private:
    std::unique_ptr<std::array<uint64_t, 2>> m_state;
};

} // namespace rng

// C API compatibility layer
extern "C" {
    // Opaque struct type for the C API
    struct xorshiro128pp_simd_rng {
        std::shared_ptr<rng::Xoroshiro128PpSimd> impl;
    };
    
    // Create a new RNG instance
    xorshiro128pp_simd_rng* xorshiro128pp_simd_new(uint64_t seed) {
        auto rng = new xorshiro128pp_simd_rng;
        rng->impl = std::make_shared<rng::Xoroshiro128PpSimd>(seed);
        return rng;
    }
    
    // Free the RNG instance
    void xorshiro128pp_simd_free(xorshiro128pp_simd_rng* rng) {
        if (rng) {
            delete rng;
        }
    }
    
    // Get next 64-bit unsigned integer