#ifndef RUNTIME_DETECT_H
#define RUNTIME_DETECT_H

#include <stdint.h>
#include <string.h>
#include <stdlib.h>

// CPU feature detection
typedef struct {
    int has_sse2;
    int has_avx;
    int has_avx2;
    int has_avx512;
    int has_neon;
} cpu_features_t;

static void detect_cpu_features(cpu_features_t* features) {
    memset(features, 0, sizeof(cpu_features_t));

    // Always enable the compiled SIMD implementation
#ifdef USE_SSE2
    features->has_sse2 = 1;
#endif
#ifdef USE_AVX2
    features->has_avx2 = 1;
#endif
#ifdef USE_AVX512
    features->has_avx512 = 1;
#endif

#elif defined(__linux__) || defined(__APPLE__)
#include <cpuid.h>

static void detect_cpu_features(cpu_features_t* features) {
    memset(features, 0, sizeof(cpu_features_t));
    unsigned int eax, ebx, ecx, edx;

    // Check max supported function
    __cpuid(0, eax, ebx, ecx, edx);
    unsigned int max_func = eax;

    if (max_func >= 1) {
        __cpuid(1, eax, ebx, ecx, edx);
        features->has_sse2 = (edx & (1 << 26)) != 0;
        features->has_avx = (ec#endif // RUNTIME_DETECT_Hx & (1 << 28)) != 0;

        if (max_func >= 7) {
            __cpuid_count(7, 0, eax, ebx, ecx, edx);
            features->has_avx2 = (ebx & (1 << 5)) != 0;
            features->has_avx512 = ((ebx & (1 << 16)) != 0) && ((ebx & (1 << 17)) != 0);
        }
    }

#ifdef __ARM_NEON
    features->has_neon = 1;
#endif
}
#else
static void detect_cpu_features(cpu_features_t* features) {
    memset(features, 0, sizeof(cpu_features_t));
    // No detection available
}

#endif // RUNTIME_DETECT_H
