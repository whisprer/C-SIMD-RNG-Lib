#include "universal_rng.h"
#include "runtime_detect.h"
#include "xoroshiro128pp_simd_main.h"  // For xoroshiro128pp_simd_new, etc.
#include "xoroshiro128pp_simd_main_optimized.h"  // Another potential source

// Scalar implementation of seeding
static void scalar_seed(xoroshiro128pp_state *state, uint64_t seed) {
    uint64_t z = (seed + 0x9e3779b97f4a7c15ULL);
    z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
    z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
    state->s[0] = z ^ (z >> 31);

    z = (state->s[0] + 0x9e3779b97f4a7c15ULL);
    z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
    z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
    state->s[1] = z ^ (z >> 31);
}

// Scalar implementation of next random number
static uint64_t scalar_next(xoroshiro128pp_state *state) {
    const uint64_t s0 = state->s[0];
    uint64_t s1 = state->s[1];
    
    const uint64_t result = rotl(s0 + s1, 17) + s0;
    
    s1 ^= s0;
    state->s[0] = rotl(s0, 49) ^ s1 ^ (s1 << 21);
    state->s[1] = rotl(s1, 28);
    
    return result;
}

universal_rng_t* universal_rng_new(uint64_t seed, 
                                   RNGAlgorithmType algorithm, 
                                   RNGPrecisionMode precision) {
    // Allocate the universal RNG structure
    universal_rng_t* rng = (universal_rng_t*)malloc(sizeof(universal_rng_t));
    if (!rng) return NULL;

    // Detect CPU features
    cpu_features_t features;
    detect_cpu_features(&features);

    // Create RNG using the appropriate SIMD implementation
    xorshiro128pp_simd_rng* simd_rng = xorshiro128pp_simd_new(seed);
    
    if (simd_rng) {
        rng->state = simd_rng;
        
        // Map implementation types
        switch (simd_rng->type) {
            case 2:  // AVX-512
                rng->impl_type = 4;
                rng->impl_name = "AVX-512 (8-way)";
                break;
            case 1:  // AVX2
                rng->impl_type = 3;
                rng->impl_name = "AVX2 (4-way)";
                break;
            case 4:  // SSE2
                rng->impl_type = 1;
                rng->impl_name = "SSE2 (2-way)";
                break;
            case 3:  // NEON
                rng->impl_type = 5;
                rng->impl_name = "NEON (2-way)";
                break;
            default:
                rng->impl_type = 0;
                rng->impl_name = "Scalar";
                break;
        }

        // Set function pointers
        rng->next_u64 = (xoroshiro_next_func)xorshiro128pp_simd_next_u64;
        rng->next_double = (xoroshiro_next_double_func)xorshiro128pp_simd_next_double;
        rng->free_func = (xoroshiro_free_func)xorshiro128pp_simd_free;

        return rng;
    }

    // Scalar fallback
    xoroshiro128pp_state* scalar_state = (xoroshiro128pp_state*)malloc(sizeof(xoroshiro128pp_state));
    if (!scalar_state) {
        free(rng);
        return NULL;
    }

    // Seed the scalar state
    scalar_seed(scalar_state, seed);
    
    rng->state = scalar_state;
    rng->impl_type = 0;
    rng->impl_name = "Scalar";
    rng->next_u64 = (xoroshiro_next_func)scalar_next;
    rng->next_double = (xoroshiro_next_double_func)[](void* state) {
        uint64_t v = scalar_next((xoroshiro128pp_state*)state);
        return (v >> 11) * (1.0 / (1ULL << 53));
    };
    rng->free_func = (xoroshiro_free_func)free;

    return rng;
}
