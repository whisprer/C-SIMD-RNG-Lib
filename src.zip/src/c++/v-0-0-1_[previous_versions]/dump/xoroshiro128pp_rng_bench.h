#include "xoroshiro128pp_rng_bench.h"

// Main function implementation
int main() {
    rng::bench::Xoroshiro128PpBench::run();
    return 0;
}