// universal_bench.cpp - remove duplicate function and fix iters usage
#include "universal_rng.h"
#include <cmath> // For sqrt function
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#ifdef USE_AVX2
#undef USE_AVX2
#endif
#define USE_AVX2

typedef struct {
    double min;
    double max;
    double avg;
    double std_dev;
} benchmark_stats_t;

static benchmark_stats_t calculate_stats(double times[], int num_runs) {
    benchmark_stats_t stats;
    
    // Find min and max
    stats.min = times[0];
    stats.max = times[0];
    double sum = times[0];
    
    for (int i = 1; i < num_runs; i++) {
        if (times[i] < stats.min) stats.min = times[i];
        if (times[i] > stats.max) stats.max = times[i];
        sum += times[i];
    }
    
    // Calculate average
    stats.avg = sum / num_runs;
    
    // Calculate standard deviation
    double variance_sum = 0;
    for (int i = 0; i < num_runs; i++) {
        double diff = times[i] - stats.avg;
        variance_sum += diff * diff;
    }
    
    stats.std_dev = sqrt(variance_sum / num_runs);
    
    return stats;
}

static inline __m256i rotl_avx2(__m256i x, int k) {
    return _mm256_or_si256(
        _mm256_slli_epi64(x, k),
        _mm256_srli_epi64(x, 64 - k)
    );
}

// Original xoroshiro128+ for comparison
typedef struct {
    uint64_t s[2];
} xoroshiro128plus_state;

static inline uint64_t xoroshiro128plus_next(xoroshiro128plus_state *state) {
    const uint64_t s0 = state->s[0];
    uint64_t s1 = state->s[1];
    
    // Calculate output with + scrambler (just add)
    const uint64_t result = s0 + s1;
    
    // Update state
    s1 ^= s0;
    state->s[0] = rotl(s0, 24) ^ s1 ^ (s1 << 16);
    state->s[1] = rotl(s1, 37);
    
    return result;
}

static inline void xoroshiro128plus_seed(xoroshiro128plus_state *state, uint64_t seed) {
    // SplitMix64
    uint64_t z = (seed + 0x9e3779b97f4a7c15ULL);
    z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
    z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
    state->s[0] = z ^ (z >> 31);

    z = (state->s[0] + 0x9e3779b97f4a7c15ULL);
    z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
    z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
    state->s[1] = z ^ (z >> 31);
}

// Benchmark function for original algorithm
static double benchmark_original(uint64_t iters) {
    xoroshiro128plus_state st;
    xoroshiro128plus_seed(&st, 42);

    clock_t start = clock();
    uint64_t sum = 0;
    for (uint64_t i = 0; i < iters; i++) {
        sum ^= xoroshiro128plus_next(&st);
    }
    clock_t end = clock();
    double secs = (double)(end - start)/CLOCKS_PER_SEC;

    // Anti-optimization
    if (sum == 1) printf("Won't happen: %llu\n", (unsigned long long)sum);
    return secs;
}

// Benchmark function for universal implementation
static double benchmark_universal(uint64_t iters) {
    // Create new RNG with silent detection
    universal_rng_t* rng = universal_rng_new(42, RNG_ALGORITHM_XOROSHIRO, RNG_PRECISION_DOUBLE);

    clock_t start = clock();
    uint64_t sum = 0;
    for (uint64_t i = 0; i < iters; i++) {
        sum ^= universal_rng_next_u64(rng);
    }
    clock_t end = clock();
    double secs = (double)(end - start)/CLOCKS_PER_SEC;

    // Anti-optimization
    if (sum == 1) printf("Won't happen: %llu\n", (unsigned long long)sum);
    universal_rng_free(rng);
    return secs;
}

// Performance comparison
static void performance_comparison() {
    const uint64_t iters = 100000000ULL; // 100 million
    const int num_runs = 5;
    
    printf("Performance Comparison:\n");
    printf("-----------------------\n");
    
    // Print CPU features once at the beginning
    cpu_features_t features;
    detect_cpu_features(&features, 0);  // Not silent - print features
    
    printf("Generating %llu numbers with each generator (%d runs)...\n", 
           (unsigned long long)iters, num_runs);
    
    // Arrays to store timings from multiple runs
    double times_original[num_runs];
    double times_universal[num_runs];
    
    // Perform multiple benchmark runs
    for (int run = 0; run < num_runs; run++) {
        // Run original benchmark
        times_original[run] = benchmark_original(iters);
        
        // Run universal benchmark
        times_universal[run] = benchmark_universal(iters);
        
        // Print individual run results
        printf("Run %d: Original: %.4f s (%.2f M/s), Universal: %.4f s (%.2f M/s), Speedup: %.2fx\n",
               run + 1,
               times_original[run], (iters/times_original[run])/1e6,
               times_universal[run], (iters/times_universal[run])/1e6,
               times_original[run]/times_universal[run]);
    }
    
    // Calculate statistics
    benchmark_stats_t stats_original = calculate_stats(times_original, num_runs);
    benchmark_stats_t stats_universal = calculate_stats(times_universal, num_runs);
    
    // Print summary statistics
    printf("\nStatistics Summary:\n");
    printf("--------------------\n");
    printf("Original xoroshiro128+:\n");
    printf("  Min:    %.4f s (%.2f M/s)\n", stats_original.min, (iters/stats_original.min)/1e6);
    printf("  Max:    %.4f s (%.2f M/s)\n", stats_original.max, (iters/stats_original.max)/1e6);
    printf("  Avg:    %.4f s (%.2f M/s)\n", stats_original.avg, (iters/stats_original.avg)/1e6);
    printf("  StdDev: %.4f s\n", stats_original.std_dev);
    
    printf("Universal RNG:\n");
    printf("  Min:    %.4f s (%.2f M/s)\n", stats_universal.min, (iters/stats_universal.min)/1e6);
    printf("  Max:    %.4f s (%.2f M/s)\n", stats_universal.max, (iters/stats_universal.max)/1e6);
    printf("  Avg:    %.4f s (%.2f M/s)\n", stats_universal.avg, (iters/stats_universal.avg)/1e6);
    printf("  StdDev: %.4f s\n", stats_universal.std_dev);
    
    printf("Average Speedup: %.2fx\n", stats_original.avg/stats_universal.avg);
    printf("Min Speedup:     %.2fx\n", stats_original.min/stats_universal.max);
    printf("Max Speedup:     %.2fx\n", stats_original.max/stats_universal.min);
    
    // Report variance as a percentage of mean
    printf("Variance (Original): %.2f%%\n", (stats_original.std_dev/stats_original.avg)*100);
    printf("Variance (Universal): %.2f%%\n", (stats_universal.std_dev/stats_universal.avg)*100);
}

// Simple usage example
static void basic_usage_example() {
    printf("Basic Usage of Universal xoroshiro128++:\n");
    printf("--------------------------------------\n");

    universal_rng_t* rng = universal_rng_new(42, RNG_ALGORITHM_XOROSHIRO, RNG_PRECISION_DOUBLE);
    printf("Using implementation: %s\n\n", universal_rng_get_impl_name(rng));

    printf("First 5 random integers:\n");
    for (int i = 0; i < 5; i++) {
        printf("  %llu\n", (unsigned long long)universal_rng_next_u64(rng));
    }

    printf("\nFirst 5 random doubles [0,1):\n");
    for (int i = 0; i < 5; i++) {
        printf("  %f\n", universal_rng_next_double(rng));
    }

    universal_rng_free(rng);
    printf("\n");
}

// Batch generation benchmark
static void benchmark_batch() {
    const uint64_t count = 10000000ULL; // 10 million
    [[maybe_unused]] const uint64_t iters = count; // C++17 standard way
    const int num_runs = 5;
    
    uint64_t* results = (uint64_t*)malloc(count * sizeof(uint64_t));
    
    printf("\nBatch Generation Performance:\n");
    printf("---------------------------\n");
    
    // Print CPU feature detection once at the beginning
    cpu_features_t features;
    detect_cpu_features(&features, 0);
    
    printf("Generating %llu numbers in batch mode (%d runs)...\n", 
           (unsigned long long)count, num_runs);
    
    // Arrays to store timings from multiple runs
    double times_one_at_a_time[num_runs];
    double times_batch[num_runs];
    
    for (int run = 0; run < num_runs; run++) {
        universal_rng_t* rng = universal_rng_new(
            12345ULL,  // seed
            RNG_ALGORITHM_XOROSHIRO,  // algorithm
            RNG_PRECISION_DOUBLE      // precision
        );
        
        // Traditional one-at-a-time approach
        clock_t start1 = clock();
        for (uint64_t i = 0; i < count; i++) {
            results[i] = universal_rng_next_u64(rng);
        }
        clock_t end1 = clock();
        times_one_at_a_time[run] = (double)(end1 - start1)/CLOCKS_PER_SEC;
        
        // Batch generation
        clock_t start2 = clock();
        universal_rng_next_batch(rng, results, count);
        clock_t end2 = clock();
        times_batch[run] = (double)(end2 - start2)/CLOCKS_PER_SEC;
        
        printf("Run %d: One-at-a-time: %.4f s (%.2f M/s), Batch: %.4f s (%.2f M/s), Speedup: %.2fx\n",
               run + 1,
               times_one_at_a_time[run], (count/times_one_at_a_time[run])/1e6,
               times_batch[run], (count/times_batch[run])/1e6,
               times_one_at_a_time[run]/times_batch[run]);
        
        universal_rng_free(rng);
    }
    
    // Calculate statistics
    benchmark_stats_t stats_one_at_a_time = calculate_stats(times_one_at_a_time, num_runs);
    benchmark_stats_t stats_batch = calculate_stats(times_batch, num_runs);
    
    // Print summary statistics
    printf("\nStatistics Summary:\n");
    printf("--------------------\n");
    printf("One-at-a-time:\n");
    printf("  Min:    %.4f s (%.2f M/s)\n", stats_one_at_a_time.min, (count/stats_one_at_a_time.min)/1e6);
    printf("  Max:    %.4f s (%.2f M/s)\n", stats_one_at_a_time.max, (count/stats_one_at_a_time.max)/1e6);
    printf("  Avg:    %.4f s (%.2f M/s)\n", stats_one_at_a_time.avg, (count/stats_one_at_a_time.avg)/1e6);
    printf("  StdDev: %.4f s\n", stats_one_at_a_time.std_dev);
    
    printf("Batch mode:\n");
    printf("  Min:    %.4f s (%.2f M/s)\n", stats_batch.min, (count/stats_batch.min)/1e6);
    printf("  Max:    %.4f s (%.2f M/s)\n", stats_batch.max, (count/stats_batch.max)/1e6);
    printf("  Avg:    %.4f s (%.2f M/s)\n", stats_batch.avg, (count/stats_batch.avg)/1e6);
    printf("  StdDev: %.4f s\n", stats_batch.std_dev);
    
    printf("Average Speedup: %.2fx\n", stats_one_at_a_time.avg/stats_batch.avg);
    
    // Report variance as a percentage of mean
    printf("Variance (One-at-a-time): %.2f%%\n", (stats_one_at_a_time.std_dev/stats_one_at_a_time.avg)*100);
    printf("Variance (Batch): %.2f%%\n", (stats_batch.std_dev/stats_batch.avg)*100);
    
    free(results);
}

// Main function to run benchmarks
int main() {
    printf("\n=== Universal xoroshiro128++ Benchmark ===\n\n");
    basic_usage_example();
    performance_comparison();
    benchmark_batch();
    return 0;
}
