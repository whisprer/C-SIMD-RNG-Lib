#ifndef LOGGING_H
#define LOGGING_H

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <chrono>
#include <mutex>
#include <memory>
#include <cstdarg>

// Modern C++ Logging System
class Logger {
public:
    // Log Levels
    enum class Level {
        DEBUG,
        INFO,
        WARNING,
        ERROR,
        CRITICAL
    };

    // Singleton access
    static Logger& getInstance() {
        static Logger instance;
        return instance;
    }

    // Log message with variable arguments
    void log(Level level, const char* format, ...) {
        va_list args;
        va_start(args, format);
        
        // Format the message
        std::string formatted_message = formatMessage(level, format, args);
        
        va_end(args);

        // Thread-safe logging
        std::lock_guard<std::mutex> lock(log_mutex_);
        
        // Console output
        outputToConsole(level, formatted_message);
        
        // File logging
        outputToFile(level, formatted_message);
    }

    // Set log file (optional)
    void setLogFile(const std::string& filename) {
        std::lock_guard<std::mutex> lock(log_mutex_);
        if (log_file_.is_open()) {
            log_file_.close();
        }
        log_file_.open(filename, std::ios::app);
    }

    // Set minimum log level
    void setLogLevel(Level level) {
        min_log_level_ = level;
    }

private:
    // Private constructor for singleton
    Logger() : 
        min_log_level_(Level::INFO),
        log_file_("universal_rng.log", std::ios::app) {}

    // Prevent copying
    Logger(const Logger&) = delete;
    Logger& operator=(const Logger&) = delete;

    // Format log message
    std::string formatMessage(Level level, const char* format, va_list args) {
        // Determine log level string
        const char* level_strings[] = {
            "[DEBUG]   ", 
            "[INFO]    ", 
            "[WARNING] ", 
            "[ERROR]   ", 
            "[CRITICAL]"
        };

        // Get current timestamp
        auto now = std::chrono::system_clock::now();
        auto time = std::chrono::system_clock::to_time_t(now);
        char timestamp[26];
        ctime_s(timestamp, sizeof(timestamp), &time);
        std::string timestamp_str(timestamp);
        timestamp_str = timestamp_str.substr(0, timestamp_str.length() - 1);  // Remove newline

        // Format the message
        char buffer[1024];
        vsnprintf(buffer, sizeof(buffer), format, args);

        // Combine timestamp, level, and message
        std::ostringstream formatted;
        formatted << timestamp_str << " " 
                  << level_strings[static_cast<int>(level)] 
                  << buffer;

        return formatted.str();
    }

    // Output to console
    void outputToConsole(Level level, const std::string& message) {
        if (level >= min_log_level_) {
            // Determine output stream based on log level
            std::ostream& output = (level >= Level::WARNING) ? std::cerr : std::cout;
            output << message << std::endl;
        }
    }

    // Output to file
    void outputToFile(Level level, const std::string& message) {
        if (log_file_.is_open() && level >= min_log_level_) {
            log_file_ << message << std::endl;
        }
    }

    // Member variables
    Level min_log_level_;
    std::ofstream log_file_;
    std::mutex log_mutex_;
};

// Convenience function for logging
inline void log_message(LogLevel level, const char* format, ...) {
    va_list args;
    va_start(args, format);
    
    // Convert legacy LogLevel to new Logger::Level
    Logger::Level mapped_level;
    switch (level) {
        case LOG_DEBUG:    mapped_level = Logger::Level::DEBUG; break;
        case LOG_INFO:     mapped_level = Logger::Level::INFO; break;
        case LOG_WARNING:  mapped_level = Logger::Level::WARNING; break;
        case LOG_ERROR:    mapped_level = Logger::Level::ERROR; break;
        case LOG_CRITICAL: mapped_level = Logger::Level::CRITICAL; break;
        default:           mapped_level = Logger::Level::INFO; break;
    }

    // Log the message
    Logger::getInstance().log(mapped_level, format, args);
    
    va_end(args);
}

#endif // LOGGING_H
