#include "runtime_detect.h"

// Include all necessary headers at the global scope
#include <cstdio>  // Add this for printf
#ifdef _WIN32
#include <intrin.h>
#elif defined(__linux__) || defined(__APPLE__)
#include <cpuid.h>
#endif

// Now implement the function
void detect_cpu_features(cpu_features_t* features) {
    // Initialize all features to false
    memset(features, 0, sizeof(cpu_features_t));

    // Handle explicit SIMD forcing
#ifdef DISABLE_AUTO_DETECT
    #ifdef USE_SSE2
        features->has_sse2 = 1;
    #endif
    #ifdef USE_AVX
        features->has_avx = 1;
    #endif
    #ifdef USE_AVX2
        features->has_avx2 = 1;
    #endif
    #ifdef USE_AVX512
        features->has_avx512f = 1;
        features->has_avx512dq = 1;
    #endif

    // Check specific AVX-512 extensions
    #ifdef AVX512F_AVAILABLE
        features->has_avx512f = 1;
    #endif
    #ifdef AVX512CD_AVAILABLE
        features->has_avx512cd = 1;
    #endif
    #ifdef AVX512BW_AVAILABLE
        features->has_avx512bw = 1;
    #endif
    #ifdef AVX512DQ_AVAILABLE
        features->has_avx512dq = 1;
    #endif
    #ifdef AVX512VL_AVAILABLE
        features->has_avx512vl = 1;
    #endif
    #ifdef AVX512IFMA_AVAILABLE
        features->has_avx512ifma = 1;
    #endif
    #ifdef AVX512VBMI_AVAILABLE
        features->has_avx512vbmi = 1;
    #endif
    #ifdef AVX512VBMI2_AVAILABLE
        features->has_avx512vbmi2 = 1;
    #endif
    #ifdef AVX512VNNI_AVAILABLE
        features->has_avx512vnni = 1;
    #endif
    #ifdef AVX512BITALG_AVAILABLE
        features->has_avx512bitalg = 1;
    #endif
    #ifdef AVX512VPOPCNTDQ_AVAILABLE
        features->has_avx512vpopcntdq = 1;
    #endif

    return;
#endif

    // Platform-specific implementations for automatic detection
#ifdef _WIN32
    int cpu_info[4] = {0};
    
    // Check max supported function
    __cpuid(cpu_info, 0);
    int max_func = cpu_info[0];
    
    // Get features
    if (max_func >= 1) {
        __cpuid(cpu_info, 1);
        features->has_sse2 = (cpu_info[3] & (1 << 26)) != 0;
        
        // Check for AVX and OSXSAVE (required for AVX)
        bool has_avx = (cpu_info[2] & (1 << 28)) != 0;
        bool has_osxsave = (cpu_info[2] & (1 << 27)) != 0;
        
        // Only set AVX if both CPU and OS support it
        if (has_avx && has_osxsave) {
            // Check if OS supports saving YMM state
            unsigned long long xcr0 = _xgetbv(0);
            features->has_avx = (xcr0 & 6) == 6; // XCR0[2:1] = '11b' (XMM and YMM state)
        }
        
        // Only check AVX2 and AVX-512 if AVX is supported
        if (features->has_avx && max_func >= 7) {
            int avx_info[4] = {0};
            __cpuidex(avx_info, 7, 0);
            
            // AVX2
            features->has_avx2 = (avx_info[1] & (1 << 5)) != 0;
            
            // Check for AVX-512 Foundation
            bool has_avx512f = (avx_info[1] & (1 << 16)) != 0;
            
            // Only set AVX-512 if OS supports ZMM state
            if (has_avx512f && has_osxsave) {
                unsigned long long xcr0 = _xgetbv(0);
                bool os_supports_avx512 = (xcr0 & 0xE0) == 0xE0; // XCR0[7:5] = '111b'
                
                if (os_supports_avx512) {
                    features->has_avx512f = 1;
                    features->has_avx512dq = (avx_info[1] & (1 << 17)) != 0;
                    features->has_avx512cd = (avx_info[1] & (1 << 28)) != 0;
                    features->has_avx512bw = (avx_info[1] & (1 << 30)) != 0;
                    features->has_avx512vl = (avx_info[1] & (1U << 31)) != 0;
                    features->has_avx512ifma = (avx_info[1] & (1 << 21)) != 0;
                    features->has_avx512vbmi = (avx_info[2] & (1 << 1)) != 0;
                    features->has_avx512vbmi2 = (avx_info[2] & (1 << 6)) != 0;
                    features->has_avx512vnni = (avx_info[2] & (1 << 11)) != 0;
                    features->has_avx512bitalg = (avx_info[2] & (1 << 12)) != 0;
                    features->has_avx512vpopcntdq = (avx_info[2] & (1 << 14)) != 0;
                }
            }
        }
    }
#elif defined(__linux__) || defined(__APPLE__)
    // Similar implementation for Linux/macOS
    unsigned int eax, ebx, ecx, edx;
    
    // Check max supported function
    __cpuid(0, eax, ebx, ecx, edx);
    unsigned int max_func = eax;
    
    if (max_func >= 1) {
        __cpuid(1, eax, ebx, ecx, edx);
        features->has_sse2 = (edx & (1 << 26)) != 0;
        
        // Check for AVX and OSXSAVE
        bool has_avx = (ecx & (1 << 28)) != 0;
        bool has_osxsave = (ecx & (1 << 27)) != 0;
        
        if (has_avx && has_osxsave) {
            // Check if OS supports saving YMM state
            unsigned int xcr0_eax = 0, xcr0_edx = 0;
            __asm__ __volatile__("xgetbv" : "=a"(xcr0_eax), "=d"(xcr0_edx) : "c"(0));
            features->has_avx = (xcr0_eax & 6) == 6; // XMM and YMM state
        }
        
        if (features->has_avx && max_func >= 7) {
            __cpuid_count(7, 0, eax, ebx, ecx, edx);
            
            // AVX2
            features->has_avx2 = (ebx & (1 << 5)) != 0;
            
            // Check for AVX-512 Foundation
            bool has_avx512f = (ebx & (1 << 16)) != 0;
            
            if (has_avx512f && has_osxsave) {
                unsigned int xcr0_eax = 0, xcr0_edx = 0;
                __asm__ __volatile__("xgetbv" : "=a"(xcr0_eax), "=d"(xcr0_edx) : "c"(0));
                bool os_supports_avx512 = (xcr0_eax & 0xE0) == 0xE0; // ZMM state
                
                if (os_supports_avx512) {
                    features->has_avx512f = 1;
                    features->has_avx512dq = (ebx & (1 << 17)) != 0;
                    features->has_avx512cd = (ebx & (1 << 28)) != 0;
                    features->has_avx512bw = (ebx & (1 << 30)) != 0;
                    features->has_avx512vl = (ebx & (1U << 31)) != 0;
                    features->has_avx512ifma = (ebx & (1 << 21)) != 0;
                    features->has_avx512vbmi = (ecx & (1 << 1)) != 0;
                    features->has_avx512vbmi2 = (ecx & (1 << 6)) != 0;
                    features->has_avx512vnni = (ecx & (1 << 11)) != 0;
                    features->has_avx512bitalg = (ecx & (1 << 12)) != 0;
                    features->has_avx512vpopcntdq = (ecx & (1 << 14)) != 0;
                }
            }
        }
    }
#endif

#ifdef __ARM_NEON
    features->has_neon = 1;
#endif

    // Print detection results for debugging
    printf("CPU Feature Detection:\n");
    printf("  SSE2: %s\n", features->has_sse2 ? "Yes" : "No");
    printf("  AVX: %s\n", features->has_avx ? "Yes" : "No");
    printf("  AVX2: %s\n", features->has_avx2 ? "Yes" : "No");
    printf("  AVX-512F: %s\n", features->has_avx512f ? "Yes" : "No");
    printf("  AVX-512DQ: %s\n", features->has_avx512dq ? "Yes" : "No");
}
