#ifndef XOROSHIRO_STATE_H
#define XOROSHIRO_STATE_H

#include <cstdint>
#include <functional>

// Enum for RNG Algorithm Types
enum RNGAlgorithmType {
    RNG_ALGORITHM_XOROSHIRO = 0,
    RNG_ALGORITHM_WYRAND = 1
};

// Enum for Precision Modes
enum RNGPrecisionMode {
    RNG_PRECISION_SINGLE = 0,
    RNG_PRECISION_DOUBLE = 1
};

// Enum for Implementation Types
enum RngImplType {
    RNG_IMPL_SCALAR = 0,
    RNG_IMPL_SSE2 = 1,
    RNG_IMPL_AVX = 2,
    RNG_IMPL_AVX2 = 3,
    RNG_IMPL_AVX512 = 4,
    RNG_IMPL_NEON = 5,
    RNG_IMPL_OPENCL = 6
};

// Forward declaration of RNG state structure
struct universal_rng_t {
    void* state;                    // Actual RNG state
    void (*next_u64)(void*);        // Function to generate next 64-bit random number
    void (*next_double)(void*);     // Function to generate next double
    void (*generate_batch)(void*, uint64_t*, size_t); // Batch generation
    void (*free_func)(void*);       // Function to free the state
    RngImplType implementation_type;// Implementation type (scalar, SSE2, etc.)
    RNGAlgorithmType algorithm_type;// Algorithm type (Xoroshiro, WyRand)
    RNGPrecisionMode precision_mode;// Precision mode
};

#endif // XOROSHIRO_STATE_H