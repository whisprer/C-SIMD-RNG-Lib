#include "universal_rng.h"

#ifdef USE_AVX512
#include <immintrin.h>
#include <cstring>
#include <stdexcept>
#include <cstdlib>

// Helper for AVX-512 rotl
static inline __m512i rotl_avx512(__m512i x, int k) {
    return _mm512_or_si512(_mm512_slli_epi64(x, k), _mm512_srli_epi64(x, 64 - k));
}

// Basic AVX-512 implementation (requires AVX-512F and AVX-512DQ)
class AVX512RNGState {
    public:
        __m512i s0;  // First 512-bit register (8 uint64_t values)
        __m512i s1;  // Second 512-bit register (8 uint64_t values)
        uint64_t results[8]; // To store extracted results
        int next_idx;        // Index for the next value to return
    
        AVX512RNGState() : next_idx(8) {}
    };
    
    // Advanced AVX-512 implementation (using additional extensions)
    class AVX512AdvancedRNGState {
    public:
        __m512i s0;  // First 512-bit register
        __m512i s1;  // Second 512-bit register
        uint64_t results[8];
        int next_idx;
        
        // Add more state variables for optimized paths
        #ifdef AVX512BW
        __m512i mask_bw;  // Specialized mask for byte/word operations
        #endif
        
        #ifdef AVX512VL
        __m256i s0_half;  // Half-width state for transitioning between widths
        __m256i s1_half;
        #endif
     
        AVX512AdvancedRNGState() : next_idx(8) {}
    };

// Basic AVX-512 implementation (F and DQ only)
void* avx512_new(uint64_t seed) {
    AVX512RNGState* state = (AVX512RNGState*)ALIGNED_ALLOC(64, sizeof(AVX512RNGState));
    if (!state) {
        // Handle allocation failure
        return nullptr;
    }
    // Initialize 8 parallel generators with different seeds
    uint64_t seeds[16]; // s0[8] and s1[8]
    seeds[0] = seed;
    
    // Create 8 different seeds from the master seed
    for (int i = 1; i < 16; i++) {
        // Use a simple increment-based seed generation
        seeds[i] = seed + i;
    }
    
    uint64_t s0_vals[8];
    uint64_t s1_vals[8];
    
    for (int i = 0; i < 8; i++) {
        // Use SplitMix64 seeding for each stream
        uint64_t z = (seeds[i] + 0x9e3779b97f4a7c15ULL);
        z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
        z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
        s0_vals[i] = z ^ (z >> 31);
        
        z = (s0_vals[i] + 0x9e3779b97f4a7c15ULL);
        z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
        z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
        s1_vals[i] = z ^ (z >> 31);
    }
    
    // Load initial states into AVX-512 registers
    state->s0 = _mm512_setr_epi64(
        s0_vals[0], s0_vals[1], s0_vals[2], s0_vals[3],
        s0_vals[4], s0_vals[5], s0_vals[6], s0_vals[7]
    );
    state->s1 = _mm512_setr_epi64(
        s1_vals[0], s1_vals[1], s1_vals[2], s1_vals[3],
        s1_vals[4], s1_vals[5], s1_vals[6], s1_vals[7]
    );
    
    // Pre-generate first batch of random numbers
    _mm512_storeu_si512((__m512i*)state->results, 
        _mm512_add_epi64(
            rotl_avx512(_mm512_add_epi64(state->s0, state->s1), 17), 
            state->s0
        )
    );

    return state;
}

// Advanced AVX-512 implementation (using additional extensions)
void* avx512_advanced_new(uint64_t seed) {
    AVX512AdvancedRNGState* state = (AVX512AdvancedRNGState*)ALIGNED_ALLOC(64, sizeof(AVX512AdvancedRNGState));
    
    // Initialize seeds similar to basic version
    uint64_t seeds[16];
    seeds[0] = seed;
    
    for (int i = 1; i < 16; i++) {
        seeds[i] = seed + i;
    }
    
    uint64_t s0_vals[8];
    uint64_t s1_vals[8];
    
    for (int i = 0; i < 8; i++) {
        uint64_t z = (seeds[i] + 0x9e3779b97f4a7c15ULL);
        z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
        z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
        s0_vals[i] = z ^ (z >> 31);
        
        z = (s0_vals[i] + 0x9e3779b97f4a7c15ULL);
        z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
        z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
        s1_vals[i] = z ^ (z >> 31);
    }
    
    // Load initial states
    state->s0 = _mm512_setr_epi64(
        s0_vals[0], s0_vals[1], s0_vals[2], s0_vals[3],
        s0_vals[4], s0_vals[5], s0_vals[6], s0_vals[7]
    );
    state->s1 = _mm512_setr_epi64(
        s1_vals[0], s1_vals[1], s1_vals[2], s1_vals[3],
        s1_vals[4], s1_vals[5], s1_vals[6], s1_vals[7]
    );
    
    // Pre-generate first batch of random numbers
    _mm512_storeu_si512((__m512i*)state->results, 
        _mm512_add_epi64(
            rotl_avx512(_mm512_add_epi64(state->s0, state->s1), 17), 
            state->s0
        )
    );
    
    #ifdef AVX512BW
    state->mask_bw = _mm512_set1_epi64(0x00000000FFFFFFFFULL);
    #endif
    
    #ifdef AVX512VL
    // Initialize half-width state (placeholder values)
    state->s0_half = _mm256_setr_epi64x(s0_vals[0], s0_vals[1], s0_vals[2], s0_vals[3]);
    state->s1_half = _mm256_setr_epi64x(s1_vals[0], s1_vals[1], s1_vals[2], s1_vals[3]);
    #endif
    
    return state;
}

// Basic AVX-512 next_u64 implementation
uint64_t avx512_next_u64(void* state_ptr) {
    AVX512RNGState* state = static_cast<AVX512RNGState*>(state_ptr);
    
    // If we've used all pre-generated numbers, generate a new batch
    if (state->next_idx >= 8) {
        // [Basic AVX-512 implementation using only AVX-512F and AVX-512DQ]
        // Calculate output: rotl(s0 + s1, 17) + s0
        __m512i sum = _mm512_add_epi64(state->s0, state->s1);
        __m512i rotated_sum = rotl_avx512(sum, 17);
        __m512i result = _mm512_add_epi64(rotated_sum, state->s0);
        
        // Store results
        _mm512_storeu_si512((__m512i*)state->results, result);
        
        // Update state
        __m512i s1 = _mm512_xor_si512(state->s1, state->s0);
        
        state->s0 = _mm512_xor_si512(
                      rotl_avx512(state->s0, 49),
                      _mm512_xor_si512(
                          s1,
                          _mm512_slli_epi64(s1, 21)
                      )
                    );
                    
        state->s1 = rotl_avx512(s1, 28);
        
        // Reset index
        state->next_idx = 0;
    }
    
    // Return next pre-generated number
    return state->results[state->next_idx++];
}

// Advanced AVX-512 next_u64 implementation using additional extensions
uint64_t avx512_advanced_next_u64(void* state_ptr) {
    AVX512AdvancedRNGState* state = static_cast<AVX512AdvancedRNGState*>(state_ptr);
    
    if (state->next_idx >= 8) {
        // Calculate output with optimized AVX-512 operations
        __m512i s0 = state->s0;
        __m512i s1 = state->s1;
        
        // Calculate output: rotl(s0 + s1, 17) + s0
        __m512i sum = _mm512_add_epi64(s0, s1);
        
        #ifdef AVX512BW
        // BW optimized rotl with variable rotation using shuffles for certain rotations
        // This can be more efficient for specific rotation amounts
        __m512i rotated_sum;
        if (17 % 8 == 0) {
            // For rotations that are multiples of 8, we can use permutexvar
            __m512i idx = _mm512_set_epi64(
                0, 7, 6, 5, 4, 3, 2, 1
            );
            rotated_sum = _mm512_permutexvar_epi8(idx, 
                _mm512_rol_epi64(sum, 17));
        } else {
            // Use standard rotation for non-byte-aligned shifts
            rotated_sum = _mm512_or_si512(
                _mm512_slli_epi64(sum, 17),
                _mm512_srli_epi64(sum, 64 - 17)
            );
        }
        #else
        // Standard rotation if AVX512BW not available
        __m512i rotated_sum = _mm512_or_si512(
            _mm512_slli_epi64(sum, 17),
            _mm512_srli_epi64(sum, 64 - 17)
        );
        #endif
        
        __m512i result = _mm512_add_epi64(rotated_sum, s0);
        
        // Store results
        _mm512_storeu_si512((__m512i*)state->results, result);
        
        // Update state with optimizations
        s1 = _mm512_xor_si512(s1, s0);
        
        #ifdef AVX512VL
        // Using VL extensions to optimize certain operations
        // For example, blend operations can be more efficient
        __m512i rotated_s0 = _mm512_or_si512(
            _mm512_slli_epi64(s0, 49),
            _mm512_srli_epi64(s0, 64 - 49)
        );
        
        // Using mask operations for conditionally selecting values
        __mmask8 mask = _mm512_cmplt_epi64_mask(s1, _mm512_set1_epi64(0));
        __m512i s1_shifted = _mm512_slli_epi64(s1, 21);
        
        // Optimized XOR chain using mask blend
        state->s0 = _mm512_xor_si512(
            rotated_s0,
            _mm512_xor_si512(
                s1,
                s1_shifted
            )
        );
        #else
        // Standard update if AVX512VL not available
        state->s0 = _mm512_xor_si512(
            _mm512_or_si512(
                _mm512_slli_epi64(s0, 49),
                _mm512_srli_epi64(s0, 64 - 49)
            ),
            _mm512_xor_si512(
                s1,
                _mm512_slli_epi64(s1, 21)
            )
        );
        #endif
        
        // Rotate s1 by 28 bits
        state->s1 = _mm512_or_si512(
            _mm512_slli_epi64(s1, 28),
            _mm512_srli_epi64(s1, 64 - 28)
        );
        
        // Reset index
        state->next_idx = 0;
    }
    
    return state->results[state->next_idx++];
}

// Free AVX-512 RNG state
void avx512_free(void* state_ptr) {
  if (state_ptr) {
      ALIGNED_FREE(state_ptr);
  }
}

void avx512_advanced_free(void* state_ptr) {
  if (state_ptr) {
      ALIGNED_FREE(state_ptr);
  }
}

// Next double implementations
double avx512_next_double(void* state) {
    // Convert to double in [0,1) range
    uint64_t v = avx512_next_u64(state);
    return (v >> 11) * (1.0 / (1ULL << 53));
}

double avx512_advanced_next_double(void* state) {
    uint64_t v = avx512_advanced_next_u64(state);
    return (v >> 11) * (1.0 / (1ULL << 53));
}

// Batch generation implementation for AVX-512
void avx512_next_batch(void* state_ptr, uint64_t* results, size_t count) {
    AVX512RNGState* state = static_cast<AVX512RNGState*>(state_ptr);
    size_t generated = 0;
    
    while (generated < count) {
        // How many values can we get from current batch
        size_t available = 8 - state->next_idx;
        size_t to_copy = (available < (count - generated)) ? available : (count - generated);
        
        // Copy values from current batch
        memcpy(results + generated, state->results + state->next_idx, 
               to_copy * sizeof(uint64_t));
               
        generated += to_copy;
        state->next_idx += to_copy;
        
        // If we need more values, generate a new batch
        if (state->next_idx >= 8 && generated < count) {
            // Update SIMD state and generate new batch
            __m512i s0 = state->s0;
            __m512i s1 = state->s1;
            
            // Calculate result: rotl(s0 + s1, 17) + s0
            __m512i sum = _mm512_add_epi64(s0, s1);
            __m512i rotated_sum = _mm512_or_si512(
                _mm512_slli_epi64(sum, 17),
                _mm512_srli_epi64(sum, 64 - 17)
            );
            __m512i result = _mm512_add_epi64(rotated_sum, s0);
            
            // Store results
            _mm512_storeu_si512((__m512i*)state->results, result);
            
            // Update state
            s1 = _mm512_xor_si512(s1, s0);
            state->s0 = _mm512_xor_si512(
                _mm512_or_si512(
                    _mm512_slli_epi64(s0, 49),
                    _mm512_srli_epi64(s0, 64 - 49)
                ),
                _mm512_xor_si512(
                    s1,
                    _mm512_slli_epi64(s1, 21)
                )
            );
            state->s1 = _mm512_or_si512(
                _mm512_slli_epi64(s1, 28),
                _mm512_srli_epi64(s1, 64 - 28)
            );
            
            state->next_idx = 0;
        }
    }
}

// Advanced AVX-512 batch generation with extension optimizations
void avx512_advanced_next_batch(void* state_ptr, uint64_t* results, size_t count) {
    AVX512AdvancedRNGState* state = static_cast<AVX512AdvancedRNGState*>(state_ptr);
    size_t generated = 0;
    
    // For large batches, we'll use direct generation rather than going through the buffer
    if (count >= 32) {
        // Process in chunks of 8 (AVX-512 width)
        size_t chunks = count / 8;
        
        for (size_t chunk = 0; chunk < chunks; chunk++) {
            __m512i s0 = state->s0;
            __m512i s1 = state->s1;
            
            // Generate result directly into output buffer
            __m512i sum = _mm512_add_epi64(s0, s1);
            
            #ifdef AVX512BW
            // Optimized rotation for AVX512BW
            __m512i rotated_sum;
            if (17 % 8 == 0) {
                __m512i idx = _mm512_set_epi64(0, 7, 6, 5, 4, 3, 2, 1);
                rotated_sum = _mm512_permutexvar_epi8(idx, 
                    _mm512_rol_epi64(sum, 17));
            } else {
                rotated_sum = _mm512_or_si512(
                    _mm512_slli_epi64(sum, 17),
                    _mm512_srli_epi64(sum, 64 - 17)
                );
            }
            #else
            __m512i rotated_sum = _mm512_or_si512(
                _mm512_slli_epi64(sum, 17),
                _mm512_srli_epi64(sum, 64 - 17)
            );
            #endif
            
            __m512i result = _mm512_add_epi64(rotated_sum, s0);
            
            // Store directly into output
            _mm512_storeu_si512((__m512i*)(results + generated), result);
            generated += 8;
            
            // Update state for next iteration
            s1 = _mm512_xor_si512(s1, s0);
            
            #ifdef AVX512VL
            // Optimizations using AVX512VL
            __m512i rotated_s0 = _mm512_or_si512(
                _mm512_slli_epi64(s0, 49),
                _mm512_srli_epi64(s0, 64 - 49)
            );
            
            __mmask8 mask = _mm512_cmplt_epi64_mask(s1, _mm512_set1_epi64(0));
            __m512i s1_shifted = _mm512_slli_epi64(s1, 21);
            
            state->s0 = _mm512_xor_si512(
                rotated_s0,
                _mm512_xor_si512(s1, s1_shifted)
            );
            #else
            state->s0 = _mm512_xor_si512(
                _mm512_or_si512(
                    _mm512_slli_epi64(s0, 49),
                    _mm512_srli_epi64(s0, 64 - 49)
                ),
                _mm512_xor_si512(
                    s1,
                    _mm512_slli_epi64(s1, 21)
                )
            );
            #endif
            
            state->s1 = _mm512_or_si512(
                _mm512_slli_epi64(s1, 28),
                _mm512_srli_epi64(s1, 64 - 28)
            );
        }
        
        // Update internal buffer with latest state for remaining items
        if (generated < count) {
            __m512i s0 = state->s0;
            __m512i s1 = state->s1;
            
            __m512i sum = _mm512_add_epi64(s0, s1);
            __m512i rotated_sum = _mm512_or_si512(
                _mm512_slli_epi64(sum, 17),
                _mm512_srli_epi64(sum, 64 - 17)
            );
            __m512i result = _mm512_add_epi64(rotated_sum, s0);
            
            _mm512_storeu_si512((__m512i*)state->results, result);
            
            // Update state
            s1 = _mm512_xor_si512(s1, s0);
            state->s0 = _mm512_xor_si512(
                _mm512_or_si512(
                    _mm512_slli_epi64(s0, 49),
                    _mm512_srli_epi64(s0, 64 - 49)
                ),
                _mm512_xor_si512(
                    s1,
                    _mm512_slli_epi64(s1, 21)
                )
            );
            state->s1 = _mm512_or_si512(
                _mm512_slli_epi64(s1, 28),
                _mm512_srli_epi64(s1, 64 - 28)
            );
            
            state->next_idx = 0;
            
            // Copy remaining items
            size_t remaining = count - generated;
            memcpy(results + generated, state->results, remaining * sizeof(uint64_t));
            state->next_idx = remaining;
        }
    } else {
        // For small batches, use the buffer approach
        while (generated < count) {
            // How many values can we get from current batch
            size_t available = 8 - state->next_idx;
            size_t to_copy = (available < (count - generated)) ? available : (count - generated);
            
            // Copy values from current batch
            memcpy(results + generated, state->results + state->next_idx, 
                  to_copy * sizeof(uint64_t));
                  
            generated += to_copy;
            state->next_idx += to_copy;
            
            // If we need more values, generate a new batch
            if (state->next_idx >= 8 && generated < count) {
                __m512i s0 = state->s0;
                __m512i s1 = state->s1;
                
                // Calculate result with AVX-512 optimizations
                __m512i sum = _mm512_add_epi64(s0, s1);
                
                #ifdef AVX512BW
                // Optimized rotation for specific values
                __m512i rotated_sum;
                if (17 % 8 == 0) {
                    __m512i idx = _mm512_set_epi64(0, 7, 6, 5, 4, 3, 2, 1);
                    rotated_sum = _mm512_permutexvar_epi8(idx, 
                        _mm512_rol_epi64(sum, 17));
                } else {
                    rotated_sum = _mm512_or_si512(
                        _mm512_slli_epi64(sum, 17),
                        _mm512_srli_epi64(sum, 64 - 17)
                    );
                }
                #else
                __m512i rotated_sum = _mm512_or_si512(
                    _mm512_slli_epi64(sum, 17),
                    _mm512_srli_epi64(sum, 64 - 17)
                );
                #endif
                
                __m512i result = _mm512_add_epi64(rotated_sum, s0);
                
                // Store results in buffer
                _mm512_storeu_si512((__m512i*)state->results, result);
                
                // Update state with applicable optimizations
                s1 = _mm512_xor_si512(s1, s0);
                
                #ifdef AVX512VL
                // Using VL-specific optimizations
                __m512i rotated_s0 = _mm512_or_si512(
                    _mm512_slli_epi64(s0, 49),
                    _mm512_srli_epi64(s0, 64 - 49)
                );
                
                state->s0 = _mm512_xor_si512(
                    rotated_s0,
                    _mm512_xor_si512(
                        s1,
                        _mm512_slli_epi64(s1, 21)
                    )
                );
                #else
                state->s0 = _mm512_xor_si512(
                    _mm512_or_si512(
                        _mm512_slli_epi64(s0, 49),
                        _mm512_srli_epi64(s0, 64 - 49)
                    ),
                    _mm512_xor_si512(
                        s1,
                        _mm512_slli_epi64(s1, 21)
                    )
                );
                #endif
                
                state->s1 = _mm512_or_si512(
                    _mm512_slli_epi64(s1, 28),
                    _mm512_srli_epi64(s1, 64 - 28)
                );
                
                state->next_idx = 0;
            }
        }
    }
}

#endif // USE_AVX512
