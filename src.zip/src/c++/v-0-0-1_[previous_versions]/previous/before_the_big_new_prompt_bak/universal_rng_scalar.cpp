#include "universal_rng.h"
#include <cstdlib>

// Utility function for bit rotation
uint64_t rotl(const uint64_t x, int k) {
    return (x << k) | (x >> (64 - k));
}

// Scalar implementation of xoroshiro128++ functions
uint64_t scalar_next_u64(void* state) {
    xoroshiro128pp_state* s = static_cast<xoroshiro128pp_state*>(state);
    const uint64_t s0 = s->s[0];
    uint64_t s1 = s->s[1];
    
    // Calculate output with ++ scrambler
    const uint64_t result = rotl(s0 + s1, 17) + s0;
    
    // Update state
    s1 ^= s0;
    s->s[0] = rotl(s0, 49) ^ s1 ^ (s1 << 21);
    s->s[1] = rotl(s1, 28);
    
    return result;
}

double scalar_next_double(void* state) {
    // Convert to double in [0,1) using the high 53 bits
    return (scalar_next_u64(state) >> 11) * (1.0 / (1ULL << 53));
}

void* scalar_new(uint64_t seed) {
    xoroshiro128pp_state* state = new xoroshiro128pp_state;
    
    // SplitMix64 seeding algorithm
    uint64_t z = (seed + 0x9e3779b97f4a7c15ULL);
    z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
    z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
    state->s[0] = z ^ (z >> 31);
    
    z = (state->s[0] + 0x9e3779b97f4a7c15ULL);
    z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
    z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
    state->s[1] = z ^ (z >> 31);
    
    return state;
}

void scalar_free(void* state) {
    delete static_cast<xoroshiro128pp_state*>(state);
}

void scalar_next_batch(void* state, uint64_t* results, size_t count) {
    for (size_t i = 0; i < count; i++) {
        results[i] = scalar_next_u64(state);
    }
}
