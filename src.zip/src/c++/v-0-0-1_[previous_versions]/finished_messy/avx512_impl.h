#ifndef AVX512_IMPL_H
#define AVX512_IMPL_H

#include <immintrin.h>
#include <cstdint>
#include <memory>
#include <array>
#include <string>

// Forward declarations
class AVX512RNGState {
public:
    explicit AVX512RNGState(uint64_t seed);
    
    // Static factory method
    static std::unique_ptr<AVX512RNGState> create(uint64_t seed);
    
    uint64_t next_u64();
    double next_double();
    void next_batch(uint64_t* results, size_t count);
    const char* get_implementation_name() const;

private:
    void generate_batch();
    void initialize_state(uint64_t seed);
    static __m512i rotl_avx512(__m512i x, int k);

    // State variables
    __m512i s0_;
    __m512i s1_;
    std::array<uint64_t, 8> results_;
    size_t next_idx_;
};

// C-compatible API declarations
extern "C" {
    void* avx512_new(uint64_t seed);
    uint64_t avx512_next_u64(void* state);
    double avx512_next_double(void* state);
    void avx512_next_batch(void* state, uint64_t* results, size_t count);
    void avx512_free(void* state);
}

#endif // AVX512_IMPL_H