#include "runtime_detect.h"

// Include all necessary headers at the global scope
#ifdef _WIN32
#include <intrin.h>
#elif defined(__linux__) || defined(__APPLE__)
#include <cpuid.h>
#endif

// Now implement the function
void detect_cpu_features(cpu_features_t* features) {
    memset(features, 0, sizeof(cpu_features_t));

    // Platform-specific implementations
#ifdef _WIN32
    int cpu_info[4] = {0};
    
    // Check max supported function
    __cpuid(cpu_info, 0);
    int max_func = cpu_info[0];
    
    // Get features
    if (max_func >= 1) {
        __cpuid(cpu_info, 1);
        features->has_sse2 = (cpu_info[3] & (1 << 26)) != 0;
        features->has_avx = (cpu_info[2] & (1 << 28)) != 0;
        
        if (max_func >= 7) {
            // Check AVX2 and AVX-512 features
            __cpuidex(cpu_info, 7, 0);
            
            // AVX2
            features->has_avx2 = (cpu_info[1] & (1 << 5)) != 0;
            
            // AVX-512 Foundation and Doubleword/Quadword
            features->has_avx512f = (cpu_info[1] & (1 << 16)) != 0;
            features->has_avx512dq = (cpu_info[1] & (1 << 17)) != 0;
            
            // Other AVX-512 extensions
            features->has_avx512cd = (cpu_info[1] & (1 << 28)) != 0;
            features->has_avx512bw = (cpu_info[1] & (1 << 30)) != 0;
            features->has_avx512vl = (cpu_info[1] & (1 << 31)) != 0;
            
            // More AVX-512 extensions (in ECX)
            features->has_avx512ifma = (cpu_info[1] & (1 << 21)) != 0;
            features->has_avx512vbmi = (cpu_info[2] & (1 << 1)) != 0;
            features->has_avx512vbmi2 = (cpu_info[2] & (1 << 6)) != 0;
            features->has_avx512vnni = (cpu_info[2] & (1 << 11)) != 0;
            features->has_avx512bitalg = (cpu_info[2] & (1 << 12)) != 0;
            features->has_avx512vpopcntdq = (cpu_info[2] & (1 << 14)) != 0;
        }
    }
#elif defined(__linux__) || defined(__APPLE__)
    unsigned int eax, ebx, ecx, edx;
    
    // Check max supported function
    __cpuid(0, eax, ebx, ecx, edx);
    unsigned int max_func = eax;
    
    if (max_func >= 1) {
        __cpuid(1, eax, ebx, ecx, edx);
        features->has_sse2 = (edx & (1 << 26)) != 0;
        features->has_avx = (ecx & (1 << 28)) != 0;
        
        if (max_func >= 7) {
            // Check AVX2 and AVX-512 features
            __cpuid_count(7, 0, eax, ebx, ecx, edx);
            
            // AVX2
            features->has_avx2 = (ebx & (1 << 5)) != 0;
            
            // AVX-512 Foundation and Doubleword/Quadword
            features->has_avx512f = (ebx & (1 << 16)) != 0;
            features->has_avx512dq = (ebx & (1 << 17)) != 0;
            
            // Other AVX-512 extensions
            features->has_avx512cd = (ebx & (1 << 28)) != 0;
            features->has_avx512bw = (ebx & (1 << 30)) != 0;
            features->has_avx512vl = (ebx & (1 << 31)) != 0;
            
            // More AVX-512 extensions (in ECX)
            features->has_avx512ifma = (ebx & (1 << 21)) != 0;
            features->has_avx512vbmi = (ecx & (1 << 1)) != 0;
            features->has_avx512vbmi2 = (ecx & (1 << 6)) != 0;
            features->has_avx512vnni = (ecx & (1 << 11)) != 0;
            features->has_avx512bitalg = (ecx & (1 << 12)) != 0;
            features->has_avx512vpopcntdq = (ecx & (1 << 14)) != 0;
        }
    }
    
    #ifdef __ARM_NEON
        features->has_neon = 1;
    #endif
#endif
}
