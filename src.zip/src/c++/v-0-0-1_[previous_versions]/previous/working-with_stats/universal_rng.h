#ifndef UNIVERSAL_RNG_H
#define UNIVERSAL_RNG_H

#include <cstdint>
#include <cstddef>
#include "runtime_detect.h"
#include "xoroshiro128pp_simd_main_optimized.h"  // Use the optimized version

#ifdef USE_AVX2
#undef USE_AVX2
#endif
#define USE_AVX2

static inline uint64_t rotl(const uint64_t x, int k) {
    return (x << k) | (x >> (64 - k));
};

// Algorithm type enums
typedef enum {
    RNG_ALGORITHM_XOROSHIRO,
    RNG_ALGORITHM_WYRAND
} RNGAlgorithmType;

typedef enum {
    RNG_PRECISION_SINGLE,
    RNG_PRECISION_DOUBLE
} RNGPrecisionMode;

// Forward declaration of function pointer types
typedef uint64_t (*xoroshiro_next_func)(void* state);
typedef double (*xoroshiro_next_double_func)(void* state);
typedef void (*xoroshiro_free_func)(void* state);

// Universal RNG structure definition
typedef struct universal_rng_t {
    void* state;
    int impl_type;
    const char* impl_name;
    xoroshiro_next_func next_u64;
    xoroshiro_next_double_func next_double;
    xoroshiro_free_func free_func;
} universal_rng_t;

// Function declarations
universal_rng_t* universal_rng_new(uint64_t seed, 
                                   RNGAlgorithmType algorithm, 
                                   RNGPrecisionMode precision);
uint64_t universal_rng_next_u64(universal_rng_t* rng);
double universal_rng_next_double(universal_rng_t* rng);
void universal_rng_free(universal_rng_t* rng);
const char* universal_rng_get_impl_name(universal_rng_t* rng);
void universal_rng_next_batch(universal_rng_t* rng, uint64_t* results, size_t count);

// Inline implementations
inline uint64_t universal_rng_next_u64(universal_rng_t* rng) {
    return rng->next_u64(rng->state);
}

inline double universal_rng_next_double(universal_rng_t* rng) {
    return rng->next_double(rng->state);
}

inline void universal_rng_free(universal_rng_t* rng) {
    if (rng) {
        rng->free_func(rng->state);
        free(rng);
    }
}

inline const char* universal_rng_get_impl_name(universal_rng_t* rng) {
    return rng ? rng->impl_name : "Unknown";
}

inline void universal_rng_next_batch(universal_rng_t* rng, uint64_t* results, size_t count) {
    for (size_t i = 0; i < count; i++) {
        results[i] = universal_rng_next_u64(rng);
    }
}

#endif // UNIVERSAL_RNG_H
