// OpenCL Random Number Generator Kernels
// Supports both xoroshiro128++ and WyRand algorithms
// Optimized for double precision with single precision fallback

#ifndef OPENCL_RNG_KERNELS_H
#define OPENCL_RNG_KERNELS_H

// Precision mode definitions
typedef enum {
    RNG_PRECISION_SINGLE,
    RNG_PRECISION_DOUBLE,
    RNG_PRECISION_MIXED
} RNGPrecisionMode;

// Kernel source code for both RNG algorithms
const char* opencl_rng_kernels = R"(
// Utility functions for bit manipulation and rotations
inline ulong rotl64(ulong x, int k) {
    return (x << k) | (x >> (64 - k));
}

// SplitMix64 seeding function
inline ulong splitmix64(ulong z) {
    z += 0x9e3779b97f4a7c15UL;
    z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9UL;
    z = (z ^ (z >> 27)) * 0x94d049bb133111ebUL;
    return z ^ (z >> 31);
}

// xoroshiro128++ Kernel Implementation
__kernel void xoroshiro128pp_init(
    __global ulong2* states,   // [s0, s1] for each stream
    ulong seed,                // Base seed
    uint num_streams           // Total number of parallel streams
) {
    uint gid = get_global_id(0);
    if (gid >= num_streams) return;

    // Use SplitMix64 to generate initial states
    ulong z = seed + ((ulong)gid * 0x9e3779b97f4a7c15UL);
    ulong s0 = splitmix64(z);
    
    z = s0 + 0x9e3779b97f4a7c15UL;
    ulong s1 = splitmix64(z);

    states[gid] = (ulong2)(s0, s1);
}

__kernel void xoroshiro128pp_generate(
    __global ulong2* states,   // Input/output states
    __global ulong* results,   // Generated random numbers
    uint num_streams           // Total number of parallel streams
) {
    uint gid = get_global_id(0);
    if (gid >= num_streams) return;

    // Load current state
    ulong2 current_state = states[gid];
    ulong s0 = current_state.x;
    ulong s1 = current_state.y;

    // xoroshiro128++ core generation
    ulong result = rotl64(s0 + s1, 17) + s0;
    results[gid] = result;

    // Update state
    s1 ^= s0;
    s0 = rotl64(s0, 49) ^ s1 ^ (s1 << 21);
    s1 = rotl64(s1, 28);

    // Store updated state
    states[gid] = (ulong2)(s0, s1);
}

// WyRand Kernel Implementation
__kernel void wyrand_init(
    __global ulong* states,    // State for each stream
    ulong seed,                // Base seed
    uint num_streams           // Total number of parallel streams
) {
    uint gid = get_global_id(0);
    if (gid >= num_streams) return;

    // Use SplitMix64 to generate initial state
    ulong z = seed + ((ulong)gid * 0x9e3779b97f4a7c15UL);
    states[gid] = splitmix64(z);
}

__kernel void wyrand_generate(
    __global ulong* states,    // Input/output states
    __global ulong* results,   // Generated random numbers
    uint num_streams           // Total number of parallel streams
) {
    uint gid = get_global_id(0);
    if (gid >= num_streams) return;

    // Load current state
    ulong seed = states[gid];

    // WyRand core generation
    seed += 0xa0761d6478bd642FULL;
    ulong x = seed ^ (seed >> 32);
    ulong result = x * (seed ^ 0xe7037ed1a0b428dbULL);
    result = (result >> 64) ^ result;

    // Store result
    results[gid] = result;

    // Update state
    states[gid] = seed;
}

// Double precision conversion kernels
__kernel void convert_uint64_to_double(
    __global ulong* input,     // 64-bit unsigned integer input
    __global double* output,   // Double precision output
    uint num_streams           // Total number of streams
) {
    uint gid = get_global_id(0);
    if (gid >= num_streams) return;

    // Convert to double in [0,1) range
    ulong v = input[gid];
    output[gid] = (v >> 11) * (1.0 / (1ULL << 53));
}

// Single precision conversion kernels
__kernel void convert_uint64_to_float(
    __global ulong* input,     // 64-bit unsigned integer input
    __global float* output,    // Single precision output
    uint num_streams           // Total number of streams
) {
    uint gid = get_global_id(0);
    if (gid >= num_streams) return;

    // Convert to float in [0,1) range
    ulong v = input[gid];
    output[gid] = (float)((v >> 11) * (1.0 / (1ULL << 53)));
}
)";

// OpenCL RNG State Structure
typedef struct {
    cl_context       context;
    cl_command_queue command_queue;
    cl_program       program;
    
    // Kernel handles
    cl_kernel        init_kernel;
    cl_kernel        generate_kernel;
    cl_kernel        convert_double_kernel;
    cl_kernel        convert_float_kernel;
    
    // Buffer objects
    cl_mem           state_buffer;
    cl_mem           result_buffer;
    cl_mem           double_buffer;
    cl_mem           float_buffer;
    
    // Configuration
    RNGPrecisionMode precision_mode;
    size_t           batch_size;
    
    // Host-side buffers
    void*            host_results;
    void*            host_doubles;
    void*            host_floats;
    
    // RNG Algorithm Type
    enum {
        RNG_XOROSHIRO,
        RNG_WYRAND
    } algorithm;
    
    // State tracking
    int              is_initialized;
} OpenCLRNGState;

// Function to select the best GPU device
cl_device_id select_best_gpu_device() {
    cl_platform_id platforms[10];
    cl_uint num_platforms;
    cl_int err;

    // Get available platforms
    err = clGetPlatformIDs(10, platforms, &num_platforms);
    if (err != CL_SUCCESS || num_platforms == 0) {
        fprintf(stderr, "No OpenCL platforms found\n");
        return NULL;
    }

    // Prioritize NVIDIA, then Intel, then AMD
    const char* preferred_vendors[] = {
        "NVIDIA Corporation", 
        "Intel(R) Corporation", 
        "Advanced Micro Devices, Inc."
    };
    const int num_vendors = sizeof(preferred_vendors) / sizeof(preferred_vendors[0]);

    for (int v = 0; v < num_vendors; v++) {
        for (cl_uint p = 0; p < num_platforms; p++) {
            char platform_vendor[128];
            err = clGetPlatformInfo(
                platforms[p], 
                CL_PLATFORM_VENDOR, 
                sizeof(platform_vendor), 
                platform_vendor, 
                NULL
            );

            // Check if current platform matches preferred vendor
            if (strstr(platform_vendor, preferred_vendors[v])) {
                cl_device_id devices[10];
                cl_uint num_devices;
                
                // Try to get GPU devices
                err = clGetDeviceIDs(
                    platforms[p], 
                    CL_DEVICE_TYPE_GPU, 
                    10, 
                    devices, 
                    &num_devices
                );
                
                if (err == CL_SUCCESS && num_devices > 0) {
                    // Return first GPU device from this platform
                    return devices[0];
                }
            }
        }
    }
    
    // No suitable device found
    return NULL;
}

// Create OpenCL RNG state
OpenCLRNGState* create_opencl_rng(
    uint64_t seed, 
    size_t batch_size, 
    RNGPrecisionMode precision_mode,
    int algorithm_type  // 0 for xoroshiro, 1 for wyrand
) {
    cl_int err;
    
    // Allocate state
    OpenCLRNGState* state = malloc(sizeof(OpenCLRNGState));
    if (!state) return NULL;
    
    // Initialize state
    memset(state, 0, sizeof(OpenCLRNGState));
    
    // Select device
    cl_device_id device = select_best_gpu_device();
    if (!device) {
        free(state);
        return NULL;
    }
    
    // Create context
    state->context = clCreateContext(NULL, 1, &device, NULL, NULL, &err);
    if (err != CL_SUCCESS) {
        free(state);
        return NULL;
    }
    
    // Create command queue
    state->command_queue = clCreateCommandQueue(
        state->context, device, 0, &err
    );
    if (err != CL_SUCCESS) {
        clReleaseContext(state->context);
        free(state);
        return NULL;
    }
    
    // Create program
    const char* source = opencl_rng_kernels;
    state->program = clCreateProgramWithSource(
        state->context, 1, &source, NULL, &err
    );
    if (err != CL_SUCCESS) {
        clReleaseCommandQueue(state->command_queue);
        clReleaseContext(state->context);
        free(state);
        return NULL;
    }
    
    // Build program
    err = clBuildProgram(state->program, 1, &device, NULL, NULL, NULL);
    if (err != CL_SUCCESS) {
        // Error handling and logging would go here
        clReleaseProgram(state->program);
        clReleaseCommandQueue(state->command_queue);
        clReleaseContext(state->context);
        free(state);
        return NULL;
    }
    
    // Select and create kernels based on algorithm
    if (algorithm_type == 0) {  // xoroshiro128++
        state->init_kernel = clCreateKernel(
            state->program, "xoroshiro128pp_init", &err
        );
        state->generate_kernel = clCreateKernel(
            state->program, "xoroshiro128pp_generate", &err
        );
        state->algorithm = RNG_XOROSHIRO;
    } else {  // WyRand
        state->init_kernel = clCreateKernel(
            state->program, "wyrand_init", &err
        );
        state->generate_kernel = clCreateKernel(
            state->program, "wyrand_generate", &err
        );
        state->algorithm = RNG_WYRAND;
    }
    
    // Create conversion kernels
    state->convert_double_kernel = clCreateKernel(
        state->program, "convert_uint64_to_double", &err
    );
    state->convert_float_kernel = clCreateKernel(
        state->program, "convert_uint64_to_float", &err
    );
    
    // Set precision mode and batch size
    state->precision_mode = precision_mode;
    state->batch_size = batch_size;
    
    // Allocate buffers
    state->state_buffer = clCreateBuffer(
        state->context, 
        CL_MEM_READ_WRITE, 
        batch_size * sizeof(state->algorithm == RNG_XOROSHIRO ? uint64_t * 2 : uint64_t), 
        NULL, &err
    );
    
    state->result_buffer = clCreateBuffer(
        state->context, 
        CL_MEM_WRITE_ONLY, 
        batch_size * sizeof(uint64_t), 
        NULL, &err
    );
    
    // Allocation for conversion buffers based on precision mode
    switch (precision_mode) {
        case RNG_PRECISION_DOUBLE:
            state->double_buffer = clCreateBuffer(
                state->context, 
                CL_MEM_WRITE_ONLY, 
                batch_size * sizeof(double), 
                NULL, &err
            );
            state->host_doubles = malloc(batch_size * sizeof(double));
            break;
        case RNG_PRECISION_SINGLE:
            state->float_buffer = clCreateBuffer(
                state->context, 
                CL_MEM_WRITE_ONLY, 
                batch_size * sizeof(float), 
                NULL, &err
            );
            state->host_floats = malloc(batch_size * sizeof(float));
            break;
        case RNG_PRECISION_MIXED:
            state->double_buffer = clCreateBuffer(
                state->context, 
                CL_MEM_WRITE_ONLY, 
                batch_size * sizeof(double), 
                NULL, &err
            );
            state->float_buffer = clCreateBuffer(
                state->context, 
                CL_MEM_WRITE_ONLY, 
                batch_size * sizeof(float), 
                NULL, &err
            );
            state->host_doubles = malloc(batch_size * sizeof(double));
            state->host_floats = malloc(batch_size * sizeof(float));
            break;
    }
    
    // Host-side result buffer
    state->host_results = malloc(batch_size * sizeof(uint64_t));
    
    // Mark as initialized
    state->is_initialized = 1;
    
    return state;
}

// Cleanup function
void free_opencl_rng(OpenCLRNGState* state) {
    if (!state) return;
    
    // Release OpenCL resources
    if (state->state_buffer) clReleaseMemObject(state->state_buffer);
    if (state->result_buffer) clReleaseMemObject(state->result_buffer);
    if (state->double_buffer) clReleaseMemObject(state->double_buffer);
    if (state->float_buffer) clReleaseMemObject(state->float_buffer);
    
    // Release kernels
    if (state->init_kernel) clReleaseKernel(state->init_kernel);
    if (state->generate_kernel) clReleaseKernel(state->generate_kernel);
    if (state->convert_double_kernel) clReleaseKernel(state->convert_double_kernel);
    if (state->convert_float_kernel) clReleaseKernel(state->convert_float_kernel);
    
    // Release program and context
    if (state->program) clReleaseProgram(state->program);

// Generate next batch of random numbers
int generate_random_batch(OpenCLRNGState* state) {
    if (!state || !state->is_initialized) {
        fprintf(stderr, "OpenCL RNG state not properly initialized\n");
        return -1;
    }

    cl_int err;
    size_t global_work_size = state->batch_size;

    // Set initialization kernel arguments
    err = clSetKernelArg(state->init_kernel, 0, sizeof(cl_mem), 
        state->algorithm == RNG_XOROSHIRO ? &state->state_buffer : &state->state_buffer);
    err |= clSetKernelArg(state->init_kernel, 1, sizeof(uint64_t), &seed);
    err |= clSetKernelArg(state->init_kernel, 2, sizeof(uint32_t), &global_work_size);

    if (err != CL_SUCCESS) {
        fprintf(stderr, "Failed to set initialization kernel arguments\n");
        return -1;
    }

    // Enqueue initialization kernel
    err = clEnqueueNDRangeKernel(
        state->command_queue, 
        state->init_kernel, 
        1, 
        NULL, 
        &global_work_size, 
        NULL, 
        0, 
        NULL, 
        NULL
    );

    if (err != CL_SUCCESS) {
        fprintf(stderr, "Failed to enqueue initialization kernel\n");
        return -1;
    }

    // Set generation kernel arguments
    err = clSetKernelArg(state->generate_kernel, 0, sizeof(cl_mem), 
        state->algorithm == RNG_XOROSHIRO ? &state->state_buffer : &state->state_buffer);
    err |= clSetKernelArg(state->generate_kernel, 1, sizeof(cl_mem), &state->result_buffer);
    err |= clSetKernelArg(state->generate_kernel, 2, sizeof(uint32_t), &global_work_size);

    if (err != CL_SUCCESS) {
        fprintf(stderr, "Failed to set generation kernel arguments\n");
        return -1;
    }

    // Enqueue generation kernel
    err = clEnqueueNDRangeKernel(
        state->command_queue, 
        state->generate_kernel, 
        1, 
        NULL, 
        &global_work_size, 
        NULL, 
        0, 
        NULL, 
        NULL
    );

    if (err != CL_SUCCESS) {
        fprintf(stderr, "Failed to enqueue generation kernel\n");
        return -1;
    }

    // Read results back to host
    err = clEnqueueReadBuffer(
        state->command_queue, 
        state->result_buffer, 
        CL_TRUE,  // Blocking read
        0, 
        state->batch_size * sizeof(uint64_t), 
        state->host_results, 
        0, 
        NULL, 
        NULL
    );

    if (err != CL_SUCCESS) {
        fprintf(stderr, "Failed to read results buffer\n");
        return -1;
    }

    // Conversion based on precision mode
    switch (state->precision_mode) {
        case RNG_PRECISION_DOUBLE: {
            // Set double conversion kernel arguments
            err = clSetKernelArg(state->convert_double_kernel, 0, sizeof(cl_mem), &state->result_buffer);
            err |= clSetKernelArg(state->convert_double_kernel, 1, sizeof(cl_mem), &state->double_buffer);
            err |= clSetKernelArg(state->convert_double_kernel, 2, sizeof(uint32_t), &global_work_size);

            if (err != CL_SUCCESS) {
                fprintf(stderr, "Failed to set double conversion kernel arguments\n");
                return -1;
            }

            // Enqueue double conversion kernel
            err = clEnqueueNDRangeKernel(
                state->command_queue, 
                state->convert_double_kernel, 
                1, 
                NULL, 
                &global_work_size, 
                NULL, 
                0, 
                NULL, 
                NULL
            );

            if (err != CL_SUCCESS) {
                fprintf(stderr, "Failed to enqueue double conversion kernel\n");
                return -1;
            }

            // Read double results
            err = clEnqueueReadBuffer(
                state->command_queue, 
                state->double_buffer, 
                CL_TRUE,  // Blocking read
                0, 
                state->batch_size * sizeof(double), 
                state->host_doubles, 
                0, 
                NULL, 
                NULL
            );
            break;
        }

        case RNG_PRECISION_SINGLE: {
            // Set float conversion kernel arguments
            err = clSetKernelArg(state->convert_float_kernel, 0, sizeof(cl_mem), &state->result_buffer);
            err |= clSetKernelArg(state->convert_float_kernel, 1, sizeof(cl_mem), &state->float_buffer);
            err |= clSetKernelArg(state->convert_float_kernel, 2, sizeof(uint32_t), &global_work_size);

            if (err != CL_SUCCESS) {
                fprintf(stderr, "Failed to set float conversion kernel arguments\n");
                return -1;
            }

            // Enqueue float conversion kernel
            err = clEnqueueNDRangeKernel(
                state->command_queue, 
                state->convert_float_kernel, 
                1, 
                NULL, 
                &global_work_size, 
                NULL, 
                0, 
                NULL, 
                NULL
            );

            if (err != CL_SUCCESS) {
                fprintf(stderr, "Failed to enqueue float conversion kernel\n");
                return -1;
            }

            // Read float results
            err = clEnqueueReadBuffer(
                state->command_queue, 
                state->float_buffer, 
                CL_TRUE,  // Blocking read
                0, 
                state->batch_size * sizeof(float), 
                state->host_floats, 
                0, 
                NULL, 
                NULL
            );
            break;
        }

        case RNG_PRECISION_MIXED: {
            // Perform both single and double conversions
            // (Reuse the single and double conversion code from above)
            // This allows flexibility in using both precisions
            break;
        }
    }

    // Ensure all commands have completed
    clFinish(state->command_queue);

    return 0;
}

// Retrieve results based on precision mode
void* get_random_results(OpenCLRNGState* state, size_t* out_size) {
    if (!state) return NULL;

    switch (state->precision_mode) {
        case RNG_PRECISION_DOUBLE:
            *out_size = state->batch_size * sizeof(double);
            return state->host_doubles;
        
        case RNG_PRECISION_SINGLE:
            *out_size = state->batch_size * sizeof(float);
            return state->host_floats;
        
        case RNG_PRECISION_MIXED:
            // In mixed mode, you might want to implement a custom retrieval logic
            // For now, we'll default to double
            *out_size = state->batch_size * sizeof(double);
            return state->host_doubles;
        
        default:
            return NULL;
    }
}

// Performance profiling function (optional but recommended)
int profile_opencl_rng(OpenCLRNGState* state) {
    cl_event events[3];  // Initialization, generation, conversion events
    cl_int err;
    
    // Enable profiling on the command queue
    clReleaseCommandQueue(state->command_queue);
    cl_command_queue_properties props[] = {CL_QUEUE_PROPERTIES, CL_QUEUE_PROFILING_ENABLE, 0};
    state->command_queue = clCreateCommandQueueWithProperties(
        state->context, 
        clGetCommandQueueInfo_device(state->command_queue), 
        props, 
        &err
    );
    
    if (err != CL_SUCCESS) {
        fprintf(stderr, "Failed to create profiling command queue\n");
        return -1;
    }

    // Perform generation with event tracking
    size_t global_work_size = state->batch_size;

    // Initialization kernel profiling
    err = clEnqueueNDRangeKernel(
        state->command_queue, 
        state->init_kernel, 
        1, 
        NULL, 
        &global_work_size, 
        NULL, 
        0, 
        NULL, 
        &events[0]
    );

    // Generation kernel profiling
    err |= clEnqueueNDRangeKernel(
        state->command_queue, 
        state->generate_kernel, 
        1, 
        NULL, 
        &global_work_size, 
        NULL, 
        0, 
        NULL, 
        &events[1]
    );

    // Conversion kernel profiling
    cl_kernel conversion_kernel = (state->precision_mode == RNG_PRECISION_SINGLE) 
        ? state->convert_float_kernel 
        : state->convert_double_kernel;
    
    err |= clEnqueueNDRangeKernel(
        state->command_queue, 
        conversion_kernel, 
        1, 
        NULL, 
        &global_work_size, 
        NULL, 
        0, 
        NULL, 
        &events[2]
    );

    if (err != CL_SUCCESS) {
        fprintf(stderr, "Profiling kernel enqueue failed\n");
        return -1;
    }

    // Wait for all events to complete
    clWaitForEvents(3, events);

    // Calculate and print timing information
    cl_ulong init_start, init_end, 
             gen_start, gen_end, 
             conv_start, conv_end;

    clGetEventProfilingInfo(events[0], CL_PROFILING_COMMAND_START, sizeof(cl_ulong), &init_start, NULL);
    clGetEventProfilingInfo(events[0], CL_PROFILING_COMMAND_END, sizeof(cl_ulong), &init_end, NULL);
    
    clGetEventProfilingInfo(events[1], CL_PROFILING_COMMAND_START, sizeof(cl_ulong), &gen_start, NULL);
    clGetEventProfilingInfo(events[1], CL_PROFILING_COMMAND_END, sizeof(cl_ulong), &gen_end, NULL);
    
    clGetEventProfilingInfo(events[2], CL_PROFILING_COMMAND_START, sizeof(cl_ulong), &conv_start, NULL);
    clGetEventProfilingInfo(events[2], CL_PROFILING_COMMAND_END, sizeof(cl_ulong), &conv_end, NULL);

    // Convert nanoseconds to milliseconds
    double init_time = (init_end - init_start) / 1e6;
    double gen_time = (gen_end - gen_start) / 1e6;
    double conv_time = (conv_end - conv_start) / 1e6;

    printf("OpenCL RNG Kernel Performance:\n");
    printf("- Initialization Kernel: %.3f ms\n", init_time);
    printf("- Generation Kernel:    %.3f ms\n", gen_time);
    printf("- Conversion Kernel:    %.3f ms\n", conv_time);
    printf("- Total Kernel Time:    %.3f ms\n", init_time + gen_time + conv_time);

    // Release events
    for (int i = 0; i < 3; i++) {
        clReleaseEvent(events[i]);
    }

    return 0;
}

#endif // OPENCL_RNG_KERNELS_H