#include "wyrand_rng_bench_optimized.h"
// All implementation is in the header - this is just a placeholder file
// to maintain compatibility with the original code structure.