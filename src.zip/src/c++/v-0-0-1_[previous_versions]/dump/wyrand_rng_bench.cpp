#include "wyrand_rng_bench.h"

// Main function implementation
int main() {
    rng::bench::WyRandBench::run();
    return 0;
}