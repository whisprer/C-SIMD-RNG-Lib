#include "rng_bench.h"
// The main function is already in the header, so nothing else needed here.