// universal_rng_config.h
#ifndef UNIVERSAL_RNG_CONFIG_H
#define UNIVERSAL_RNG_CONFIG_H

// Define which implementations to use
// Uncomment only one of these
//#define USE_WYRAND_ORIGINAL
#define USE_WYRAND_OPTIMIZED
//#define USE_XOROSHIRO_ORIGINAL
//#define USE_XOROSHIRO_OPTIMIZED

// Include the appropriate implementation
#ifdef USE_WYRAND_ORIGINAL
#include "wyrand_simd_main.h"
#endif

#ifdef USE_WYRAND_OPTIMIZED
#include "wyrand_simd_main_optimized.h"
#endif

#ifdef USE_XOROSHIRO_ORIGINAL
#include "xoroshiro128pp_simd_main.h"
#endif

#ifdef USE_XOROSHIRO_OPTIMIZED
#include "xoroshiro128pp_simd_main_optimized.h"
#endif

#endif // UNIVERSAL_RNG_CONFIG_H