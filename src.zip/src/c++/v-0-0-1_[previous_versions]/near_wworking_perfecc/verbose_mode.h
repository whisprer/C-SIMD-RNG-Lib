// verbose_mode.h
#ifndef VERBOSE_MODE_H
#define VERBOSE_MODE_H

#include <stdio.h>

// Global verbose mode flag
static int g_verbose_mode = 0;

// Verbose logging macro
#define VERBOSE_LOG(fmt, ...) \
    do { \
        if (g_verbose_mode) { \
            fprintf(stdout, "[VERBOSE] " fmt, ##__VA_ARGS__); \
        } \
    } while (0)

// Function to enable verbose mode
void enable_verbose_mode() {
    g_verbose_mode = 1;
    VERBOSE_LOG("Verbose mode enabled\n");
}

// Function to disable verbose mode
void disable_verbose_mode() {
    VERBOSE_LOG("Verbose mode disabled\n");
    g_verbose_mode = 0;
}

// Implementation type to string conversion
const char* get_implementation_type_string(int impl_type) {
    switch (impl_type) {
        case RNG_IMPL_SCALAR:   return "Scalar";
        case RNG_IMPL_SSE2:     return "SSE2";
        case RNG_IMPL_AVX:      return "AVX";
        case RNG_IMPL_AVX2:     return "AVX2";
        case RNG_IMPL_AVX512:   return "AVX-512";
        case RNG_IMPL_NEON:     return "NEON";
        case RNG_IMPL_OPENCL:   return "OpenCL";
        default:                return "Unknown";
    }
}

// Verbose logging for RNG initialization
void log_rng_initialization(universal_rng_t* rng) {
    if (!g_verbose_mode || !rng) return;

    VERBOSE_LOG("RNG Initialization Details:\n");
    VERBOSE_LOG("- Algorithm:       %s\n", 
        rng->algorithm_type == RNG_ALGORITHM_XOROSHIRO ? "Xoroshiro128++" : "WyRand");
    VERBOSE_LOG("- Precision:       %s\n", 
        rng->precision_mode == RNG_PRECISION_SINGLE ? "Single" : "Double");
    VERBOSE_LOG("- Implementation:  %s\n", 
        get_implementation_type_string(rng->implementation_type));
}

#endif // VERBOSE_MODE_H
