#ifndef XOROSHIRO128PP_SIMD_MAIN_OPTIMIZED_H
#define XOROSHIRO128PP_SIMD_MAIN_OPTIMIZED_H

#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <memory>

#ifdef _MSC_VER
#include <intrin.h>
#else
#include <x86intrin.h>
#endif

#if defined(__AVX512F__) && defined(__AVX512DQ__)
  #ifndef USE_AVX512
    #define USE_AVX512
  #endif
#elif defined(__AVX2__)
  #ifndef USE_AVX2
    #define USE_AVX2
  #endif
#elif defined(__AVX__)
  #ifndef USE_AVX
    #define USE_AVX
  #endif
#elif defined(__ARM_NEON) || defined(__ARM_NEON__)
  #ifndef USE_NEON
    #define USE_NEON
  #endif
  #include <arm_neon.h>
#elif defined(__SSE2__)
  #ifndef USE_SSE2
    #define USE_SSE2
  #endif
#endif

static inline uint64_t rotl64(const uint64_t x, int k) {
    return (x << k) | (x >> (64 - k));
}

static inline uint64_t xorshiro128pp_next_scalar(uint64_t *s0, uint64_t *s1) {
    const uint64_t s0v = *s0;
    uint64_t s1v       = *s1;
    const uint64_t result = rotl64(s0v + s1v, 17) + s0v;

    s1v ^= s0v;
    *s0 = rotl64(s0v, 49) ^ s1v ^ (s1v << 21);
    *s1 = rotl64(s1v, 28);

    return result;
}

#ifdef USE_NEON
#include <arm_neon.h>
typedef struct {
    uint64x2_t s0;
    uint64x2_t s1;
} xorshiro128pp_neon_state;

static inline void xorshiro128pp_neon_init(xorshiro128pp_neon_state* st, const uint64_t seeds[4]) {
    uint64_t temp0[2] = { seeds[0], seeds[1] };
    uint64_t temp1[2] = { seeds[2], seeds[3] };
    st->s0 = vld1q_u64(temp0);
    st->s1 = vld1q_u64(temp1);
}

static inline void xorshiro128pp_neon_next(xorshiro128pp_neon_state* st, uint64_t results[2]) {
    uint64_t s0temp[2], s1temp[2];
    vst1q_u64(s0temp, st->s0);
    vst1q_u64(s1temp, st->s1);

    results[0] = xorshiro128pp_next_scalar(&s0temp[0], &s1temp[0]);
    results[1] = xorshiro128pp_next_scalar(&s0temp[1], &s1temp[1]);

    st->s0 = vld1q_u64(s0temp);
    st->s1 = vld1q_u64(s1temp);
}
#endif // USE_NEON

#ifdef USE_SSE2
#include <emmintrin.h>
typedef struct {
    __m128i s0; 
    __m128i s1;
} xorshiro128pp_sse2_state;

static inline void xorshiro128pp_sse2_init(xorshiro128pp_sse2_state* st, const uint64_t seeds[4]) {
    st->s0 = _mm_set_epi64x(seeds[1], seeds[0]); 
    st->s1 = _mm_set_epi64x(seeds[3], seeds[2]);
}

static inline void xorshiro128pp_sse2_next(xorshiro128pp_sse2_state* st, uint64_t results[2]) {
    uint64_t s0temp[2], s1temp[2];
    _mm_storeu_si128((__m128i*)s0temp, st->s0);
    _mm_storeu_si128((__m128i*)s1temp, st->s1);

    results[0] = xorshiro128pp_next_scalar(&s0temp[0], &s1temp[0]);
    results[1] = xorshiro128pp_next_scalar(&s0temp[1], &s1temp[1]);

    st->s0 = _mm_set_epi64x(s0temp[1], s0temp[0]);
    st->s1 = _mm_set_epi64x(s1temp[1], s1temp[0]);
}
#endif // USE_SSE2

#if defined(USE_AVX) || defined(USE_AVX2)
#include <immintrin.h>
#endif

#ifdef USE_AVX
typedef struct {
    __m256i s0;
    __m256i s1; 
} xorshiro128pp_avx_state;

static inline void xorshiro128pp_avx_init(xorshiro128pp_avx_state* st, const uint64_t seeds[8]) {
    st->s0 = _mm256_loadu_si256((__m256i*)&seeds[0]);
    st->s1 = _mm256_loadu_si256((__m256i*)&seeds[4]);
}

static inline void xorshiro128pp_avx_next(xorshiro128pp_avx_state* st, uint64_t results[4]) {
    uint64_t s0temp[4], s1temp[4];
    _mm256_storeu_si256((__m256i*)s0temp, st->s0);
    _mm256_storeu_si256((__m256i*)s1temp, st->s1);

    for(int i=0;i<4;i++){
        results[i] = xorshiro128pp_next_scalar(&s0temp[i], &s1temp[i]);
    }
    st->s0 = _mm256_loadu_si256((__m256i*)s0temp);
    st->s1 = _mm256_loadu_si256((__m256i*)s1temp);
}
#endif

#ifdef USE_AVX2
typedef struct {
    __m256i s0;
    __m256i s1;
} xorshiro128pp_avx2_state;

static inline void xorshiro128pp_avx2_init(xorshiro128pp_avx2_state* st, const uint64_t seeds[8]) {
    st->s0 = _mm256_loadu_si256((__m256i*)&seeds[0]);
    st->s1 = _mm256_loadu_si256((__m256i*)&seeds[4]);
}

static inline void xorshiro128pp_avx2_next(xorshiro128pp_avx2_state* st, uint64_t results[4]) {
    uint64_t s0temp[4], s1temp[4];
    _mm256_storeu_si256((__m256i*)s0temp, st->s0);
    _mm256_storeu_si256((__m256i*)s1temp, st->s1);

    for(int i=0;i<4;i++){
        results[i] = xorshiro128pp_next_scalar(&s0temp[i], &s1temp[i]);
    }
    st->s0 = _mm256_loadu_si256((__m256i*)s0temp);
    st->s1 = _mm256_loadu_si256((__m256i*)s1temp);
}
#endif

#ifdef USE_AVX512
#include <immintrin.h>
typedef struct {
    __m512i s0; 
    __m512i s1;
} xorshiro128pp_avx512_state;

static inline void xorshiro128pp_avx512_init(xorshiro128pp_avx512_state* st, const uint64_t seeds[16]) {
    st->s0 = _mm512_loadu_si512((__m512i*)(&seeds[0]));
    st->s1 = _mm512_loadu_si512((__m512i*)(&seeds[8]));
}

static inline void xorshiro128pp_avx512_next(xorshiro128pp_avx512_state* st, uint64_t results[8]) {
    uint64_t s0temp[8], s1temp[8];
    _mm512_storeu_si512((void*)s0temp, st->s0);
    _mm512_storeu_si512((void*)s1temp, st->s1);

    for(int i=0;i<8;i++){
        results[i] = xorshiro128pp_next_scalar(&s0temp[i], &s1temp[i]);
    }
    st->s0 = _mm512_loadu_si512((void*)s0temp);
    st->s1 = _mm512_loadu_si512((void*)s1temp);
}
#endif

#ifdef USE_OPENCL

#ifdef _WIN32
#include <CL/cl.h>
#else
#include <OpenCL/opencl.h>
#endif

#include <stdio.h>

static const char* xorshiro128pp_opencl_src = R"(
... // Truncated for brevity
)";

typedef struct {
    cl_context       ctx;
    cl_command_queue cq;
    cl_program       prog;
    cl_kernel        kgen;
    cl_kernel        kinit;
    cl_mem           stbuf;
    cl_mem           resbuf;
    size_t           wgsize;
    size_t           batch;
    std::unique_ptr<uint64_t[]> hostres;
    size_t           pos;
    int              ok;
} xoroshiro128pp_opencl_state;

static std::unique_ptr<xoroshiro128pp_opencl_state> xorshiro128pp_opencl_new(uint64_t seedval) {
    auto st = std::make_unique<xoroshiro128pp_opencl_state>();
    cl_int err;
    cl_platform_id plat;
    cl_device_id dev;

    err = clGetPlatformIDs(1, &plat, NULL);
    if (err != CL_SUCCESS) { return nullptr; }
    err = clGetDeviceIDs(plat, CL_DEVICE_TYPE_GPU, 1, &dev, NULL);
    if (err != CL_SUCCESS) {
        err = clGetDeviceIDs(plat, CL_DEVICE_TYPE_CPU, 1, &dev, NULL);
        if (err != CL_SUCCESS) { return nullptr; }
    }
    st->ctx = clCreateContext(NULL, 1, &dev, NULL, NULL, &err);
    if (err != CL_SUCCESS) { return nullptr; }

#ifdef CL_VERSION_2_0
    st->cq = clCreateCommandQueueWithProperties(st->ctx, dev, 0, &err);
#else
    st->cq = clCreateCommandQueue(st->ctx, dev, 0, &err);
#endif
    if (err != CL_SUCCESS) { return nullptr; }

    st->prog = clCreateProgramWithSource(st->ctx, 1, &xorshiro128pp_opencl_src, NULL, &err);
    if (err != CL_SUCCESS) { return nullptr; }
    
    err = clBuildProgram(st->prog, 1, &dev, NULL, NULL, NULL);
    if (err != CL_SUCCESS) {
        size_t logsize; clGetProgramBuildInfo(st->prog, dev, CL_PROGRAM_BUILD_LOG, 0, NULL, &logsize);
        std::unique_ptr<char[]> log = std::make_unique<char[]>(logsize);
        clGetProgramBuildInfo(st->prog, dev, CL_PROGRAM_BUILD_LOG, logsize, log.get(), NULL);
        fprintf(stderr, "OpenCL build error:\n%s\n", log.get());
        return nullptr;
    }

    st->kgen = clCreateKernel(st->prog, "xorshiro128pp_generate", &err);
    if (err != CL_SUCCESS) { return nullptr; }
    st->kinit = clCreateKernel(st->prog, "xorshiro128pp_init", &err);
    if (err != CL_SUCCESS) { return nullptr; }
    
    err = clGetKernelWorkGroupInfo(st->kgen, dev, CL_KERNEL_WORK_GROUP_SIZE, sizeof(size_t), &st->wgsize, NULL);
    if (err != CL_SUCCESS) { st->wgsize = 64; }

    st->batch = st->wgsize * 64;
    st->stbuf = clCreateBuffer(st->ctx, CL_MEM_READ_WRITE, st->batch * sizeof(cl_ulong2), NULL, &err);
    if (err != CL_SUCCESS) { return nullptr; }
    st->resbuf = clCreateBuffer(st->ctx, CL_MEM_READ_WRITE, st->batch * sizeof(cl_ulong), NULL, &err);
    if (err != CL_SUCCESS) { return nullptr; }

    st->hostres = std::make_unique<uint64_t[]>(st->batch);

    // init
    err = clSetKernelArg(st->kinit, 0, sizeof(cl_mem), &st->stbuf);
    err |= clSetKernelArg(st->kinit, 1, sizeof(cl_ulong), &seedval);
    err |= clSetKernelArg(st->kinit, 2, sizeof(cl_uint), &st->batch);
    size_t gs = ((st->batch + st->wgsize - 1) / st->wgsize) * st->wgsize;
    err = clEnqueueNDRangeKernel(st->cq, st->kinit, 1, NULL, &gs, &st->wgsize, 0, NULL, NULL);

    // gen kernel
    err = clSetKernelArg(st->kgen, 0, sizeof(cl_mem), &st->stbuf);
    err |= clSetKernelArg(st->kgen, 1, sizeof(cl_mem), &st->resbuf);
    err |= clSetKernelArg(st->kgen, 2, sizeof(cl_uint), &st->batch);

    // first batch
    err = clEnqueueNDRangeKernel(st->cq, st->kgen, 1, NULL, &gs, &st->wgsize, 0, NULL, NULL);
    err = clEnqueueReadBuffer(st->cq, st->resbuf, CL_TRUE, 0, st->batch * sizeof(cl_ulong), st->hostres.get(), 0, NULL, NULL);

    st->pos = 0; st->ok = 1;
    return st;
}

static inline void xorshiro

static inline void xorshiro128pp_opencl_refill(xorshiro128pp_opencl_state* st){
    size_t gs= ((st->batch+st->wgsize-1)/st->wgsize)*st->wgsize;
    clEnqueueNDRangeKernel(st->cq, st->kgen,1,NULL,&gs,&st->wgsize,0,NULL,NULL);
    clEnqueueReadBuffer(st->cq, st->resbuf,CL_TRUE,0, st->batch*sizeof(cl_ulong), st->hostres.get(),0,NULL,NULL);
    st->pos=0;
}

static inline uint64_t xorshiro128pp_opencl_next(xorshiro128pp_opencl_state* st){
    if(st->pos>=st->batch){ xorshiro128pp_opencl_refill(st); }
    return st->hostres[st->pos++];
}

#endif // USE_OPENCL

#if defined(USE_OPENCL)
  #define XORO_PARALLEL_STREAMS 1024
#elif defined(USE_AVX512)
  #define XORO_PARALLEL_STREAMS 8
#elif defined(USE_AVX2) || defined(USE_AVX)
  #define XORO_PARALLEL_STREAMS 4
#elif defined(USE_NEON) || defined(USE_SSE2)
  #define XORO_PARALLEL_STREAMS 2
#else
  #define XORO_PARALLEL_STREAMS 1
#endif

typedef struct {
    std::shared_ptr<void> state;    
    int      type;     
    int      buffer_pos;
    uint64_t buffer[XORO_PARALLEL_STREAMS];
} xorshiro128pp_simd_rng;

static inline std::unique_ptr<xorshiro128pp_simd_rng> xorshiro128pp_simd_new(uint64_t seed) {
    auto rng = std::make_unique<xorshiro128pp_simd_rng>();
    rng->buffer_pos= XORO_PARALLEL_STREAMS; 

#ifdef USE_OPENCL
    {
        auto st = xoroshiro128pp_opencl_new(seed);
        if(st){
            rng->state = std::shared_ptr<void>(st.release());
            rng->type  = 6;
            return rng;
        } else {
            fprintf(stderr,"OpenCL init failed, falling back to CPU.\n");
        }
    }
#endif

#ifdef USE_AVX512
    {
        auto st = std::make_unique<xorshiro128pp_avx512_state>();
        uint64_t seeds[16];
        uint64_t tmp0= seed? seed:0x1234567890ABCDEFULL;
        for(int i=0;i<8;i++){
            uint64_t z= tmp0 + 0x9e3779b97f4a7c15ULL*i;
            z ^= (z>>30); z *= 0xbf58476d1ce4e5b9ULL; z ^= (z>>27); z *= 0x94d049bb133111ebULL; 
            seeds[i]   = z ^ (z>>31);
            z = seeds[i] + 0x9e3779b97f4a7c15ULL;
            z ^= (z>>30); z *= 0xbf58476d1ce4e5b9ULL; z ^= (z>>27); z *= 0x94d049bb133111ebULL; 
            seeds[i+8] = z ^ (z>>31);
        }
        xorshiro128pp_avx512_init(st.get(),seeds);
        rng->state= std::shared_ptr<void>(st.release());
        rng->type=3;
        return rng;
    }
#elif defined(USE_AVX2)
    {
        auto st = std::make_unique<xorshiro128pp_avx2_state>(); 
        uint64_t seeds[8];
        uint64_t tmp0= seed? seed:0x1234567890ABCDEFULL;
        for(int i=0;i<4;i++){
            uint64_t z= tmp0 + 0x9e3779b97f4a7c15ULL*i;
            z ^= (z>>30); z *= 0xbf58476d1ce4e5b9ULL; z ^= (z>>27); z *= 0x94d049bb133111ebULL;
            seeds[i]   = z ^ (z>>31);
            z = seeds[i] + 0x9e3779b97f4a7c15ULL;
            z ^= (z>>30); z *= 0xbf58476d1ce4e5b9ULL; z ^= (z>>27); z *= 0x94d049bb133111ebULL;
            seeds[i+4] = z ^ (z>>31);
        }
        xorshiro128pp_avx2_init(st.get(),seeds);
        rng->state = std::shared_ptr<void>(st.release()); 
        rng->type=2;
        return rng;
    }
#elif defined(USE_AVX)
    { 
        auto st = std::make_unique<xorshiro128pp_avx_state>();
        uint64_t seeds[8];
        uint64_t tmp0= seed? seed:0x1234567890ABCDEFULL;
        for(int i=0;i<4;i++){
            uint64_t z= tmp0 + 0x9e3779b97f4a7c15ULL*i;
            z ^= (z>>30); z *= 0xbf58476d1ce4e5b9ULL; z ^= (z>>27); z *= 0x94d049bb133111ebULL;
            seeds[i]   = z ^ (z>>31);
            z = seeds[i] + 0x9e3779b97f4a7c15ULL;
            z ^= (z>>30); z *= 0xbf58476d1ce4e5b9ULL; z ^= (z>>27); z *= 0x94d049bb133111ebULL;
            seeds[i+4] = z ^ (z>>31);
        }
        xorshiro128pp_avx_init(st.get(),seeds);
        rng->state= std::shared_ptr<void>(st.release());
        rng->type=1;
        return rng;
    }
#elif defined(USE_NEON)  
    {
        auto st= std::make_unique<xorshiro128pp_neon_state>();
        uint64_t seeds[4];
        uint64_t z= seed? seed:0x1234567890ABCDEFULL;
        z ^= (z>>30); z *= 0xbf58476d1ce4e5b9ULL; z ^= (z>>27); z *= 0x94d049bb133111ebULL;
        seeds[0] = z ^ (z>>31);
        z = seeds[0]+0x9e3779b97f4a7c15ULL;
        z ^= (z>>30); z *= 0xbf58476d1ce4e5b9ULL; z ^= (z>>27); z *= 0x94d049bb133111ebULL;
        seeds[1] = z ^ (z>>31);

        z = seeds[1]+0x9e3779b97f4a7c15ULL;
        z ^= (z>>30); z *= 0xbf58476d1ce4e5b9ULL; z ^= (z>>27); z *= 0x94d049bb133111ebULL;
        seeds[2] = z ^ (z>>31);
        z = seeds[2]+0x9e3779b97f4a7c15ULL;
        z ^= (z>>30); z *= 0xbf58476d1ce4e5b9ULL; z ^= (z>>27); z *= 0x94d049bb133111ebULL;
        seeds[3] = z ^ (z>>31);

        xorshiro128pp_neon_init(st.get(), seeds);
        rng->state= std::shared_ptr<void>(st.release());
        rng->type=4;
        return rng;
    }
#elif defined(USE_SSE2)
    {
        auto st= std::make_unique<xorshiro128pp_sse2_state>();
        uint64_t seeds[4];
        uint64_t z= seed? seed:0x1234567890ABCDEFULL;
        z ^= (z>>30); z *= 0xbf58476d1ce4e5b9ULL; z ^= (z>>27); z *= 0x94d049bb133111ebULL;
        seeds[0] = z ^ (z>>31);
        z = seeds[0]+0x9e3779b97f4a7c15ULL;
        z ^= (z>>30); z *= 0xbf58476d1ce4e5b9ULL; z ^= (z>>27); z *= 0x94d049bb133111ebULL;
        seeds[1] = z ^ (z>>31);

        z = seeds[1]+0x9e3779b97f4a7c15ULL;
        z ^= (z>>30); z *= 0xbf58476d1ce4e5b9ULL; z ^= (z>>27); z *= 0x94d049bb133111ebULL;
        seeds[2] = z ^ (z>>31);
        z = seeds[2]+0x9e3779b97f4a7c15ULL;
        z ^= (z>>30); z *= 0xbf58476d1ce4e5b9ULL; z ^= (z>>27); z *= 0x94d049bb133111ebULL;  
        seeds[3] = z ^ (z>>31);

        xorshiro128pp_sse2_init(st.get(),seeds);
        rng->state= std::shared_ptr<void>(st.release());
        rng->type=5;
        return rng;
    }
#else
    {
        // scalar fallback: just store s0,s1
        auto st = std::make_unique<uint64_t[]>(2);
        uint64_t z= seed? seed:0x1234567890ABCDEFULL;
        z ^= (z>>30); z *= 0xbf58476d1ce4e5b9ULL; z ^= (z>>27); z *= 0x94d049bb133111ebULL;
        st[0] = z ^ (z>>31); // s0
        z = st[0]+0x9e3779b97f4a7c15ULL;
        z ^= (z>>30); z *= 0xbf58476d1ce4e5b9ULL; z ^= (z>>27); z *= 0x94d049bb133111ebULL;
        st[1] = z ^ (z>>31); // s1

        rng->state = std::shared_ptr<uint64_t>(st.release());
        rng->type  = 0;
        return rng;
    }
#endif
}

static inline void xorshiro128pp_simd_free(std::unique_ptr<xorshiro128pp_simd_rng>& rng) {
    // Nothing to do, the unique_ptr will handle memory cleanup
}

static inline uint64_t xorshiro128pp_simd_next_u64(xorshiro128pp_simd_rng* rng) {
#ifdef USE_OPENCL
    if(rng->type==6){
        return xorshiro128pp_opencl_next((xoroshiro128pp_opencl_state*)rng->state.get());
    }
#endif
    if(rng->buffer_pos >= XORO_PARALLEL_STREAMS){
        // refill
        switch(rng->type){
            case 0: {
                // scalar
                uint64_t* st = (uint64_t*)rng->state.get();
                rng->buffer[0] = xorshiro128pp_next_scalar(&st[0], &st[1]);
            } break;
#ifdef USE_AVX
            case 1: {
                auto* st= (xorshiro128pp_avx_state*)rng->state.get();
                xorshiro128pp_avx_next(st, rng->buffer);
            } break;
#endif
#ifdef USE_AVX2 
            case 2: {
                auto* st= (xorshiro128pp_avx2_state*)rng->state.get();
                xorshiro128pp_avx2_next(st, rng->buffer);
            } break;
#endif
#ifdef USE_AVX512
            case 3: {
                auto* st= (xorshiro128pp_avx512_state*)rng->state.get();  
                xorshiro128pp_avx512_next(st, rng->buffer);
            } break;
#endif
#ifdef USE_NEON
            case 4: {
                auto* st= (xorshiro128pp_neon_state*)rng->state.get();
                xorshiro128pp_neon_next(st, rng->buffer);  
            } break;
#endif
#ifdef USE_SSE2
            case 5: {
                auto* st= (xorshiro128pp_sse2_state*)rng->state.get();
                xorshiro128pp_sse2_next(st, rng->buffer);
            } break;  
#endif
            default: break;
        }
        rng->buffer_pos=0;
    }
    return rng->buffer[rng->buffer_pos++];
}

static inline double xorshiro128pp_simd_next_double(xorshiro128pp_simd_rng* rng){
    uint64_t v = xorshiro128pp_simd_next_u64(rng);
    return (v >> 11) * (1.0 / (1ULL << 53));
}

static inline void xorshiro128pp_simd_jump(xorshiro128pp_simd_rng* rng){
    (void)rng;
}

#endif // XOROSHIRO128PP_SIMD_MAIN_OPTIMIZED_H

