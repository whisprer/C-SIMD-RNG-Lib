#ifndef UNIVERSAL_RNG_CONFIG_H
#define UNIVERSAL_RNG_CONFIG_H

#include <type_traits>
#include <stdexcept>
#include <string>
#include <optional>

// Compile-time RNG Configuration Template
template<typename Implementation>
class RNGConfig {
public:
    // Enum for configuration options
    enum class Algorithm {
        WYRAND,
        XOROSHIRO
    };

    enum class Implementation {
        ORIGINAL,
        OPTIMIZED
    };

    // Compile-time configuration selection
    static constexpr bool is_valid_config() {
        return std::is_same_v<Implementation, WyRandOriginal> ||
               std::is_same_v<Implementation, WyRandOptimized> ||
               std::is_same_v<Implementation, XoroshiroOriginal> ||
               std::is_same_v<Implementation, XoroshiroOptimized>;
    }

    // Get the appropriate header path based on configuration
    static constexpr const char* get_header_path() {
        if constexpr (std::is_same_v<Implementation, WyRandOriginal>) {
            return "wyrand_simd_main.h";
        } else if constexpr (std::is_same_v<Implementation, WyRandOptimized>) {
            return "wyrand_simd_main_optimized.h";
        } else if constexpr (std::is_same_v<Implementation, XoroshiroOriginal>) {
            return "xoroshiro128pp_simd_main.h";
        } else if constexpr (std::is_same_v<Implementation, XoroshiroOptimized>) {
            return "xoroshiro128pp_simd_main_optimized.h";
        } else {
            throw std::runtime_error("Invalid RNG configuration");
        }
    }

    // Get a human-readable name for the implementation
    static std::string get_implementation_name() {
        if constexpr (std::is_same_v<Implementation, WyRandOriginal>) {
            return "WyRand Original";
        } else if constexpr (std::is_same_v<Implementation, WyRandOptimized>) {
            return "WyRand Optimized";
        } else if constexpr (std::is_same_v<Implementation, XoroshiroOriginal>) {
            return "Xoroshiro Original";
        } else if constexpr (std::is_same_v<Implementation, XoroshiroOptimized>) {
            return "Xoroshiro Optimized";
        } else {
            return "Unknown";
        }
    }

    // Validate configuration at compile-time
    static_assert(is_valid_config(), "Invalid RNG configuration selected");
};

// Type aliases for easier configuration
using WyRandOriginal = RNGConfig<struct WyRandOriginalTag>;
using WyRandOptimized = RNGConfig<struct WyRandOptimizedTag>;
using XoroshiroOriginal = RNGConfig<struct XoroshiroOriginalTag>;
using XoroshiroOptimized = RNGConfig<struct XoroshiroOptimizedTag>;

// Convenience macro for including the right header
#define INCLUDE_RNG_IMPLEMENTATION \
    constexpr const char* implementation_header = RNGConfig<Implementation>::get_header_path(); \
    static_assert(implementation_header != nullptr, "Invalid RNG implementation"); \
    _Pragma("message(\"Using RNG implementation: \")" #implementation_header) \
    _Pragma("GCC diagnostic push") \
    _Pragma("GCC diagnostic ignored \"-Wunused-variable\"") \
    #include implementation_header \
    _Pragma("GCC diagnostic pop")

// Configuration Analyzer
class RNGConfigAnalyzer {
public:
    // Analyze and provide detailed configuration information
    template<typename ConfigType>
    static std::optional<std::string> analyze() {
        if constexpr (ConfigType::is_valid_config()) {
            return std::optional<std::string>(
                "RNG Configuration Details:\n" +
                "  Algorithm:       " + ConfigType::get_implementation_name() + "\n" +
                "  Header Path:     " + ConfigType::get_header_path() + "\n"
            );
        }
        return std::nullopt;
    }
};

#endif // UNIVERSAL_RNG_CONFIG_H
