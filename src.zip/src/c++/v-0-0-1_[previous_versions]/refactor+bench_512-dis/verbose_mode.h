// verbose_mode.h
#ifndef VERBOSE_MODE_H
#define VERBOSE_MODE_H

#include <iostream>
#include <string>
#include <atomic>
#include <type_traits>

// Forward declarations
struct universal_rng_t;
enum RngImplType : int;
enum RngAlgorithmType : int;
enum RngPrecisionMode : int;

// Include our implementation type definitions from the main header
#include "xoroshiro128pp_simd_main_optimized.h"

namespace rng {
namespace verbose {

// Thread-safe global verbose mode flag
class VerboseMode {
public:
    VerboseMode() = default;
    
    // Singleton accessor
    static VerboseMode& instance() {
        static VerboseMode instance;
        return instance;
    }
    
    // Enable verbose mode
    void enable() {
        enabled_ = true;
        log("Verbose mode enabled\n");
    }
    
    // Disable verbose mode
    void disable() {
        log("Verbose mode disabled\n");
        enabled_ = false;
    }
    
    // Check if verbose mode is enabled
    bool is_enabled() const {
        return enabled_;
    }
    
    // Log a message if verbose mode is enabled
    template<typename... Args>
    void log(const char* format, Args&&... args) const {
        if (enabled_) {
            fprintf(stdout, "[VERBOSE] ");
            fprintf(stdout, format, std::forward<Args>(args)...);
        }
    }
    
    // Convert implementation type to string
    static std::string impl_type_to_string(RngImplType impl_type) {
        switch (impl_type) {
            case RNG_IMPL_SCALAR:   return "Scalar";
            case RNG_IMPL_SSE2:     return "SSE2";
            case RNG_IMPL_AVX:      return "AVX";
            case RNG_IMPL_AVX2:     return "AVX2";
            case RNG_IMPL_AVX512:   return "AVX-512";
            case RNG_IMPL_NEON:     return "NEON";
            case RNG_IMPL_OPENCL:   return "OpenCL";
            default:                return "Unknown";
        }
    }
    
    // Convert algorithm type to string
    static std::string algorithm_type_to_string(RngAlgorithmType algo_type) {
        switch (algo_type) {
            case RNG_ALGORITHM_XOROSHIRO: return "Xoroshiro128++";
            case RNG_ALGORITHM_WYRAND:    return "WyRand";
            default:                      return "Unknown";
        }
    }
    
    // Convert precision mode to string
    static std::string precision_mode_to_string(RngPrecisionMode precision) {
        switch (precision) {
            case RNG_PRECISION_SINGLE: return "Single";
            case RNG_PRECISION_DOUBLE: return "Double";
            default:                   return "Unknown";
        }
    }
    
    // Log RNG initialization details
    void log_rng_initialization(const universal_rng_t* rng) const {
        if (!enabled_ || !rng) return;
        
        log("RNG Initialization Details:\n");
        log("- Algorithm:       %s\n", algorithm_type_to_string(rng->algorithm_type).c_str());
        log("- Precision:       %s\n", precision_mode_to_string(rng->precision_mode).c_str());
        log("- Implementation:  %s\n", impl_type_to_string(rng->implementation_type).c_str());
    }
    
private:
    std::atomic<bool> enabled_{false};
};

} // namespace verbose
} // namespace rng

// C-compatible API for backwards compatibility
extern "C" {

// Function to enable verbose mode
void enable_verbose_mode() {
    rng::verbose::VerboseMode::instance().enable();
}

// Function to disable verbose mode
void disable_verbose_mode() {
    rng::verbose::VerboseMode::instance().disable();
}

// Function to get implementation type string
const char* get_implementation_type_string(int impl_type) {
    static thread_local std::string result;
    result = rng::verbose::VerboseMode::impl_type_to_string(static_cast<RngImplType>(impl_type));
    return result.c_str();
}

// Log RNG initialization details
void log_rng_initialization(universal_rng_t* rng) {
    rng::verbose::VerboseMode::instance().log_rng_initialization(rng);
}

// Verbose logging macro (backward compatibility)
#define VERBOSE_LOG(fmt, ...) \
    do { \
        rng::verbose::VerboseMode::instance().log(fmt, ##__VA_ARGS__); \
    } while (0)

} // extern "C"

#endif // VERBOSE_MODE_H