// xoroshiro_opt_test.cpp
#include <stdio.h>
#include "xoroshiro128pp_rng_bench_optimized.h"

int main() {
    printf("=== Xoroshiro128++ Benchmark (Optimized) ===\n\n");
    run_xoroshiro_bench_optimized();
    return 0;
}