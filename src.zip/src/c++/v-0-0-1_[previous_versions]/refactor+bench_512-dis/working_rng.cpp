#include <iostream>
#include <cstdint>
#include <cstddef>
#include <vector>
#include <chrono>
#include <iomanip>

// Define the necessary types
enum RNGAlgorithmType {
    RNG_ALGORITHM_XOROSHIRO = 0,
    RNG_ALGORITHM_WYRAND = 1
};

enum RNGPrecisionMode {
    RNG_PRECISION_SINGLE = 0,
    RNG_PRECISION_DOUBLE = 1
};

enum RngImplType {
    RNG_IMPL_SCALAR = 0,
    RNG_IMPL_SSE2 = 1,
    RNG_IMPL_AVX = 2,
    RNG_IMPL_AVX2 = 3,
    RNG_IMPL_AVX512 = 4,
    RNG_IMPL_NEON = 5,
    RNG_IMPL_OPENCL = 6
};

struct universal_rng_t {
    void* state;
    uint64_t (*next_u64)(void*);
    double (*next_double)(void*);
    void (*generate_batch)(void*, uint64_t*, size_t);
    void (*free_func)(void*);
    RngImplType implementation_type;
    RNGAlgorithmType algorithm_type;
    RNGPrecisionMode precision_mode;
};

// Simple Xoroshiro128++ implementation
struct XoroshiroState {
    uint64_t s[2];
};

uint64_t xoroshiro_next_u64(void* state_ptr) {
    XoroshiroState* state = static_cast<XoroshiroState*>(state_ptr);
    const uint64_t s0 = state->s[0];
    uint64_t s1 = state->s[1];
    
    // Xoroshiro128++ algorithm
    const uint64_t result = ((s0 + s1) << 17 | (s0 + s1) >> 47) + s0;
    
    s1 ^= s0;
    state->s[0] = ((s0 << 49) | (s0 >> 15)) ^ s1 ^ (s1 << 21);
    state->s[1] = ((s1 << 28) | (s1 >> 36));
    
    return result;
}

double xoroshiro_next_double(void* state_ptr) {
    // Convert to double using high 53 bits
    return (xoroshiro_next_u64(state_ptr) >> 11) * (1.0 / (1ULL << 53));
}

void xoroshiro_generate_batch(void* state_ptr, uint64_t* results, size_t count) {
    for (size_t i = 0; i < count; ++i) {
        results[i] = xoroshiro_next_u64(state_ptr);
    }
}

void xoroshiro_free(void* state_ptr) {
    delete static_cast<XoroshiroState*>(state_ptr);
}

// Create a new RNG
universal_rng_t* create_rng(uint64_t seed, RNGAlgorithmType algorithm_type, RNGPrecisionMode precision_mode) {
    // Create a new universal RNG with all fields initialized
    universal_rng_t* rng = new universal_rng_t{
        nullptr,                    // state
        xoroshiro_next_u64,         // next_u64
        xoroshiro_next_double,      // next_double
        xoroshiro_generate_batch,   // generate_batch
        xoroshiro_free,             // free_func
        RNG_IMPL_SCALAR,            // implementation_type
        algorithm_type,             // algorithm_type
        precision_mode              // precision_mode
    };
    
    // Initialize state with SplitMix64
    XoroshiroState* state = new XoroshiroState();
    
    // Seed using SplitMix64
    uint64_t z = seed + 0x9e3779b97f4a7c15ULL;
    z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
    z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
    state->s[0] = z ^ (z >> 31);
    
    z = state->s[0] + 0x9e3779b97f4a7c15ULL;
    z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
    z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
    state->s[1] = z ^ (z >> 31);
    
    // Set the state
    rng->state = state;
    
    return rng;
}

// Helper functions to use the RNG
uint64_t get_next_u64(universal_rng_t* rng) {
    if (rng && rng->next_u64 && rng->state) {
        return rng->next_u64(rng->state);
    }
    return 0;
}

double get_next_double(universal_rng_t* rng) {
    if (rng && rng->next_double && rng->state) {
        return rng->next_double(rng->state);
    }
    return 0.0;
}

void generate_batch(universal_rng_t* rng, uint64_t* results, size_t count) {
    if (rng && rng->generate_batch && rng->state && results) {
        rng->generate_batch(rng->state, results, count);
    }
}

void free_rng(universal_rng_t* rng) {
    if (rng) {
        if (rng->free_func && rng->state) {
            rng->free_func(rng->state);
        }
        delete rng;
    }
}

// Benchmark function
double benchmark_rng(universal_rng_t* rng, size_t iterations) {
    auto start = std::chrono::high_resolution_clock::now();
    
    // Allocate buffer for batch generation
    std::vector<uint64_t> results(1000);
    
    for (size_t i = 0; i < iterations; i += 1000) {
        size_t batch_size = (i + 1000 <= iterations) ? 1000 : (iterations - i);
        generate_batch(rng, results.data(), batch_size);
    }
    
    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> duration = end - start;
    
    return duration.count();
}

// Main function for testing and benchmarking
int main() {
    std::cout << "Universal RNG Benchmark\n";
    std::cout << "=====================\n\n";
    
    // Create RNGs for both algorithms
    uint64_t seed = 42;
    universal_rng_t* xoroshiro_rng = create_rng(seed, RNG_ALGORITHM_XOROSHIRO, RNG_PRECISION_DOUBLE);
    
    if (!xoroshiro_rng) {
        std::cerr << "Failed to create Xoroshiro RNG instance\n";
        return 1;
    }
    
    std::cout << "RNG created successfully\n\n";
    
    // Generate and display some random numbers
    std::cout << "First 5 random values:\n";
    for (int i = 0; i < 5; i++) {
        std::cout << "  " << get_next_u64(xoroshiro_rng) << "\n";
    }
    
    std::cout << "\nFirst 5 random doubles:\n";
    for (int i = 0; i < 5; i++) {
        std::cout << "  " << get_next_double(xoroshiro_rng) << "\n";
    }
    
    // Run a benchmark
    constexpr size_t ITERATIONS = 10000000;
    std::cout << "\nRunning benchmark with " << ITERATIONS << " iterations...\n";
    
    double time = benchmark_rng(xoroshiro_rng, ITERATIONS);
    double rate = ITERATIONS / time / 1e6; // M/s
    
    std::cout << "Benchmark results:\n";
    std::cout << "  Time:   " << std::fixed << std::setprecision(4) << time << " s\n";
    std::cout << "  Rate:   " << std::fixed << std::setprecision(2) << rate << " M/s\n";
    
    // Clean up
    free_rng(xoroshiro_rng);
    
    std::cout << "\nBenchmark completed successfully.\n";
    return 0;
}