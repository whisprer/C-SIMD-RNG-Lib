// wyrand_opt_test.cpp
#include <stdio.h>
#include "wyrand_rng_bench_optimized.h"

int main() {
    printf("=== WyRand Benchmark (Optimized) ===\n\n");
    run_wyrand_bench_optimized();
    return 0;
}