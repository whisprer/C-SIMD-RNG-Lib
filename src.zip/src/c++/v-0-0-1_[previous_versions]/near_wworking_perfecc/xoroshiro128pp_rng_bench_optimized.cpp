#include "xoroshiro128pp_rng_bench_optimized.h"
// Nothing else needed here, main() is in the header.