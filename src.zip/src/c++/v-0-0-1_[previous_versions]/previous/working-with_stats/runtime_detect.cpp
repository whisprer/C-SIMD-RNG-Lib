#include "runtime_detect.h"

// Include all necessary headers at the global scope
#include <cstdio>  // Add this for printf
#ifdef _WIN32
#include <intrin.h>
#elif defined(__linux__) || defined(__APPLE__)
#include <cpuid.h>
#endif

// Now implement the function
void detect_cpu_features(cpu_features_t* features, int silent) {
    memset(features, 0, sizeof(cpu_features_t));

    // Platform-specific implementations
    #ifdef _WIN32
    int cpu_info[4] = {0};
    
    // Check max supported function
    __cpuid(cpu_info, 0);
    int max_func = cpu_info[0];
    
    // Get features
    if (max_func >= 1) {
        __cpuid(cpu_info, 1);
        features->has_sse2 = (cpu_info[3] & (1 << 26)) != 0;
        features->has_avx = (cpu_info[2] & (1 << 28)) != 0;
        
        // Check for OSXSAVE bit - required for AVX
        bool osxsave = (cpu_info[2] & (1 << 27)) != 0;
        
        // Only check AVX2 and AVX-512 if AVX is supported and OSXSAVE is set
        if (features->has_avx && osxsave && max_func >= 7) {
            int extended_info[4] = {0};
            __cpuidex(extended_info, 7, 0);
            
            // AVX2
            features->has_avx2 = (extended_info[1] & (1 << 5)) != 0;
            
            // AVX-512 Foundation and Doubleword/Quadword
            features->has_avx512f = (extended_info[1] & (1 << 16)) != 0;
            features->has_avx512dq = (extended_info[1] & (1 << 17)) != 0;
            
            // Double-check AVX-512 support with OS context check
            if (features->has_avx512f) {
                // Check if OS supports saving YMM and ZMM state
                unsigned long long xcr0 = _xgetbv(0);
                // bool avx_supported = (xcr0 & 6) == 6; // XCR0[2:1] = '11b' (XMM and YMM state)
                bool avx512_supported = (xcr0 & 0xE0) == 0xE0; // XCR0[7:5] = '111b' (OPMASK, ZMM0-15, ZMM16-31)
                
                if (!avx512_supported) {
                    features->has_avx512f = false;
                    features->has_avx512dq = false;
                    // Clear all other AVX-512 feature flags
                    features->has_avx512cd = false;
                    features->has_avx512bw = false;
                    features->has_avx512vl = false;
                    features->has_avx512ifma = false;
                    features->has_avx512vbmi = false;
                    features->has_avx512vbmi2 = false;
                    features->has_avx512vnni = false;
                    features->has_avx512bitalg = false;
                    features->has_avx512vpopcntdq = false;
                }
            }
            
            // Only set other AVX-512 features if Foundation is available
            if (features->has_avx512f) {
                features->has_avx512cd = (extended_info[1] & (1 << 28)) != 0;
                features->has_avx512bw = (extended_info[1] & (1 << 30)) != 0;
                features->has_avx512vl = (extended_info[1] & (1 << 31)) != 0;
                features->has_avx512ifma = (extended_info[1] & (1 << 21)) != 0;
                features->has_avx512vbmi = (extended_info[2] & (1 << 1)) != 0;
                features->has_avx512vbmi2 = (extended_info[2] & (1 << 6)) != 0;
                features->has_avx512vnni = (extended_info[2] & (1 << 11)) != 0;
                features->has_avx512bitalg = (extended_info[2] & (1 << 12)) != 0;
                features->has_avx512vpopcntdq = (extended_info[2] & (1 << 14)) != 0;
            }
        }
    }
    #elif defined(__linux__) || defined(__APPLE__)
    // Similar implementation for Linux/macOS
    // ...
    #endif

    #ifdef __ARM_NEON
        features->has_neon = 1;
    #endif

    // Print feature detection only if silent is false
    if (!silent) {
        printf("CPU Feature Detection:\n");
        printf("  SSE2: %s\n", features->has_sse2 ? "Yes" : "No");
        printf("  AVX: %s\n", features->has_avx ? "Yes" : "No");
        printf("  AVX2: %s\n", features->has_avx2 ? "Yes" : "No");
        printf("  AVX-512F: %s\n", features->has_avx512f ? "Yes" : "No");
        printf("  AVX-512DQ: %s\n", features->has_avx512dq ? "Yes" : "No");
    }
}