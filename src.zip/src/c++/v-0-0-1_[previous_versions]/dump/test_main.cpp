#include "universal_rng_types.h"
#include "universal_rng.h"
#include "rng_includes.h"
#include <iostream>
#include <vector>

int main() {
    std::cout << "API Test" << std::endl;
    std::cout << "========" << std::endl << std::endl;
    
    try {
        std::cout << "Calling universal_rng_new..." << std::endl;
        // Try with scalar implementation and simple algorithm
        universal_rng_t* rng = universal_rng_new(42, 0, 0);
        
        if (rng) {
            std::cout << "RNG created successfully." << std::endl;
            
            // Try a simple operation
            uint64_t val = universal_rng_next_u64(rng);
            std::cout << "Generated value: " << val << std::endl;
            
            // Clean up
            universal_rng_free(rng);
            std::cout << "RNG freed successfully." << std::endl;
        } else {
            std::cout << "Failed to create RNG." << std::endl;
        }
    } catch (const std::exception& e) {
        std::cout << "Exception caught: " << e.what() << std::endl;
    } catch (...) {
        std::cout << "Unknown exception caught." << std::endl;
    }
    
    std::cout << std::endl << "Test completed." << std::endl;
    return 0;
}