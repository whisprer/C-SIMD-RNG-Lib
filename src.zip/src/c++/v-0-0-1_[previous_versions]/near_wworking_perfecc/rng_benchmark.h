// rng_benchmark.h
#ifndef RNG_BENCHMARK_H
#define RNG_BENCHMARK_H

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

// Benchmark configuration structure
typedef struct {
    // Test parameters
    size_t num_iterations;     // Number of random numbers to generate
    int algorithm_type;        // Which RNG algorithm to use
    int precision_mode;        // Single/Double precision
    int implementation_type;   // Scalar/SIMD/OpenCL etc.

    // Performance metrics
    double total_generation_time;
    double numbers_per_second;
    
    // Result storage
    void* raw_results;         // Raw generated numbers
    void* statistical_data;    // Optional statistical analysis results

    // Export configuration
    char* csv_output_path;     // Path for CSV export
} RNGBenchmarkConfig;

// Benchmark result export function
int export_benchmark_to_csv(RNGBenchmarkConfig* config) {
    // Default to a timestamped filename if not specified
    if (!config->csv_output_path) {
        time_t now;
        time(&now);
        char filename[256];
        snprintf(filename, sizeof(filename), 
            "rng_benchmark_%ld.csv", (long)now);
        config->csv_output_path = strdup(filename);
    }

    FILE* csv_file = fopen(config->csv_output_path, "w");
    if (!csv_file) {
        fprintf(stderr, "Failed to open CSV file for writing\n");
        return -1;
    }

    // Write CSV header
    fprintf(csv_file, 
        "Iterations,Algorithm,Precision,Implementation,"
        "Total Time (s),Numbers/Second\n"
    );

    // Write benchmark results
    fprintf(csv_file, "%zu,%d,%d,%d,%.4f,%.2f\n",
        config->num_iterations,
        config->algorithm_type,
        config->precision_mode,
        config->implementation_type,
        config->total_generation_time,
        config->numbers_per_second
    );

    fclose(csv_file);
    return 0;
}

// Comprehensive benchmark function
RNGBenchmarkConfig* run_rng_benchmark(
    size_t num_iterations, 
    int algorithm_type, 
    int precision_mode
) {
    // Allocate benchmark configuration
    RNGBenchmarkConfig* benchmark = malloc(sizeof(RNGBenchmarkConfig));
    memset(benchmark, 0, sizeof(RNGBenchmarkConfig));

    // Set benchmark parameters
    benchmark->num_iterations = num_iterations;
    benchmark->algorithm_type = algorithm_type;
    benchmark->precision_mode = precision_mode;

    // Select appropriate RNG implementation
    universal_rng_t* rng = universal_rng_new(
        time(NULL),  // Seed with current time
        algorithm_type,
        precision_mode
    );

    if (!rng) {
        fprintf(stderr, "Failed to create RNG for benchmarking\n");
        free(benchmark);
        return NULL;
    }

    // Allocate result storage
    void* results = malloc(
        precision_mode == RNG_PRECISION_SINGLE 
            ? num_iterations * sizeof(float) 
            : num_iterations * sizeof(double)
    );

    // Timing setup
    clock_t start = clock();

    // Batch generation
    universal_rng_next_batch(rng, results, num_iterations);

    // Calculate timing
    clock_t end = clock();
    double total_time = (double)(end - start) / CLOCKS_PER_SEC;

    // Populate benchmark results
    benchmark->total_generation_time = total_time;
    benchmark->numbers_per_second = num_iterations / total_time;
    benchmark->raw_results = results;
    benchmark->implementation_type = rng->implementation_type;

    // Cleanup
    universal_rng_free(rng);

    return benchmark;
}

// Cleanup function for benchmark results
void free_benchmark_results(RNGBenchmarkConfig* benchmark) {
    if (!benchmark) return;

    free(benchmark->raw_results);
    if (benchmark->csv_output_path) {
        free(benchmark->csv_output_path);
    }
    free(benchmark);
}

#endif // RNG_BENCHMARK_H
