#ifndef XOROSHIRO128PP_SIMD_MAIN_OPTIMIZED_H
#define XOROSHIRO128PP_SIMD_MAIN_OPTIMIZED_H

// This file is intentionally left as a backward compatibility wrapper
// All its functionality has been moved to the modern C++ implementation in xoroshiro128pp.h
#include "xoroshiro128pp.h"

// The functionality is provided through the C API defined in xoroshiro128pp.h

#endif // XOROSHIRO128PP_SIMD_MAIN_OPTIMIZED_H