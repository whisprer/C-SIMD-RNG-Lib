#ifndef RNG_COMPREHENSIVE_BENCH_H
#define RNG_COMPREHENSIVE_BENCH_H

#include "rng_common.h"
#include "wyrand_impl.h"
#include "xoroshiro_impl.h"
#include <iostream>
#include <iomanip>
#include <memory>
#include <vector>
#include <string>
#include <functional>
#include <chrono>

namespace rng {
namespace bench {

// RNG benchmark suite
class RngBenchmarkSuite {
public:
    RngBenchmarkSuite() = default;
    
    // Add a new RNG implementation to benchmark
    template<typename RngType>
    void add_rng(const std::string& name, std::function<RngType()> factory,
                 std::function<uint64_t(RngType&)> next_u64_func) {
        m_benchmark_funcs.push_back([name, factory, next_u64_func, this](uint64_t iterations) {
            auto rng = factory();
            auto start = std::chrono::high_resolution_clock::now();
            
            uint64_t sum = 0;
            for(uint64_t i = 0; i < iterations; i++) {
                sum ^= next_u64_func(rng);
            }
            
            auto end = std::chrono::high_resolution_clock::now();
            std::chrono::duration<double> duration = end - start;
            
            // Anti-optimization trick
            if(sum == 1) std::cout << "Won't happen: " << sum << std::endl;
            
            m_results[name] = duration.count();
            return duration.count();
        });
        
        m_rng_names.push_back(name);
    }
    
    // Run all benchmarks
    void run_all(uint64_t iterations) {
        std::cout << "\n=== COMPREHENSIVE RNG BENCHMARK ===\n\n";
        std::cout << "SIMD Support:\n";
        std::cout << "-------------\n";
        rng::print_simd_support();
        std::cout << "\n";
        
        std::cout << "Running benchmarks with " << iterations << " iterations each...\n\n";
        
        // Run all benchmarks
        for (size_t i = 0; i < m_benchmark_funcs.size(); ++i) {
            const auto& name = m_rng_names[i];
            std::cout << "Benchmarking " << name << "... ";
            std::cout.flush();
            
            double time = m_benchmark_funcs[i](iterations);
            
            std::cout << "done. Time: " << std::fixed << std::setprecision(4) << time 
                      << " s (" << std::fixed << std::setprecision(2) << (iterations/time)/1e6 << " M/s)\n";
        }
        
        // Print summary
        std::cout << "\nSummary:\n";
        std::cout << "--------\n";
        
        // Find the fastest implementation
        std::string fastest_name;
        double fastest_time = std::numeric_limits<double>::max();
        
        for (const auto& name : m_rng_names) {
            double time = m_results[name];
            if (time < fastest_time) {
                fastest_time = time;
                fastest_name = name;
            }
        }
        
        // Print results
        std::cout << std::left << std::setw(30) << "RNG Implementation" 
                  << std::setw(12) << "Time (s)" 
                  << std::setw(12) << "Speed (M/s)"
                  << std::setw(12) << "Relative"
                  << "\n";
        
        std::cout << std::string(70, '-') << "\n";
        
        for (const auto& name : m_rng_names) {
            double time = m_results[name];
            double speed = (iterations/time)/1e6;
            double relative = fastest_time / time; // 1.0 means fastest, < 1.0 means slower
            
            std::cout << std::left << std::setw(30) << name
                      << std::fixed << std::setprecision(4) << std::setw(12) << time
                      << std::fixed << std::setprecision(2) << std::setw(12) << speed
                      << std::fixed << std::setprecision(2) << std::setw(12) << relative
                      << "\n";
        }
        
        std::cout << "\nFastest implementation: " << fastest_name << "\n";
    }
    
    // Static convenience method
    static void run_comprehensive_benchmark(uint64_t iterations = 100000000ULL) {
        RngBenchmarkSuite suite;
        
        // Add original Xoroshiro128+
        suite.add_rng<Xoroshiro128Plus>(
            "Xoroshiro128+ (original)",
            []() { return Xoroshiro128Plus(42); },
            [](Xoroshiro128Plus& rng) { return rng.next_u64(); }
        );
        
        // Add Xoroshiro128++ (stack)
        suite.add_rng<Xoroshiro128PlusPlus>(
            "Xoroshiro128++ (stack)",
            []() { return Xoroshiro128PlusPlus(42); },
            [](Xoroshiro128PlusPlus& rng) { return rng.next_u64(); }
        );
        
        // Add Xoroshiro128++ (SIMD)
        suite.add_rng<Xoroshiro128PpSimd>(
            "Xoroshiro128++ (SIMD)",
            []() { return Xoroshiro128PpSimd(42); },
            [](Xoroshiro128PpSimd& rng) { return rng.next_u64(); }
        );
        
        // Add WyRand (stack)
        suite.add_rng<WyRand>(
            "WyRand (stack)",
            []() { return WyRand(42); },
            [](WyRand& rng) { return rng.next_u64(); }
        );
        
        // Add WyRand (SIMD)
        suite.add_rng<WyRandSimd>(
            "WyRand (SIMD)",
            []() { return WyRandSimd(42); },
            [](WyRandSimd& rng) { return rng.next_u64(); }
        );
        
        // Run all benchmarks
        suite.run_all(iterations);
    }
    
private:
    std::vector<std::function<double(uint64_t)>> m_benchmark_funcs;
    std::vector<std::string> m_rng_names;
    std::unordered_map<std::string, double> m_results;
};

} // namespace bench
} // namespace rng

// C-style function for backwards compatibility
inline void run_comprehensive_bench() {
    rng::bench::RngBenchmarkSuite::run_comprehensive_benchmark();
}

#endif // RNG_COMPREHENSIVE_BENCH_H