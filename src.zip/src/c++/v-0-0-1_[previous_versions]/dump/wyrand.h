#ifndef WYRAND_H
#define WYRAND_H

#include "rng_common.h"

namespace rng {

// WyRand RNG implementation
class WyRand {
public:
    explicit WyRand(uint64_t seed = 0) {
        seed_state(seed);
    }
    
    // Copy operations
    WyRand(const WyRand&) = default;
    WyRand& operator=(const WyRand&) = default;
    
    // Move operations
    WyRand(WyRand&&) noexcept = default;
    WyRand& operator=(WyRand&&) noexcept = default;
    
    // Default destructor is fine - no resources
    ~WyRand() = default;
    
    // Generate next 64-bit unsigned integer
    uint64_t next_u64() {
        m_state += 0x9e3779b97f4a7c55ULL;
        uint64_t result = m_state;
        result = (result ^ (result >> 30)) * 0xbf58476d1ce4e5b9ULL;
        result = (result ^ (result >> 27)) * 0x94d049bb133111ebULL;
        return result ^ (result >> 31);
    }
    
    // Generate a random double in range [0, 1)
    double next_double() {
        return static_cast<double>(next_u64() >> 11) * (1.0 / (1ULL << 53));
    }
    
    // Seed the generator
    void seed_state(uint64_t seed) {
        m_state = seed;
    }
    
private:
    uint64_t m_state;
};

// SIMD-optimized implementation of WyRand
class WyRandSimd {
public:
    explicit WyRandSimd(uint64_t seed = 0) 
        : m_state(std::make_unique<uint64_t>(seed)) {
    }
    
    // Rule of five implementation
    ~WyRandSimd() = default;
    
    WyRandSimd(const WyRandSimd& other) 
        : m_state(std::make_unique<uint64_t>(*other.m_state)) {
    }
    
    WyRandSimd& operator=(const WyRandSimd& other) {
        if (this != &other) {
            *m_state = *other.m_state;
        }
        return *this;
    }
    
    WyRandSimd(WyRandSimd&&) noexcept = default;
    WyRandSimd& operator=(WyRandSimd&&) noexcept = default;
    
    // Generate next 64-bit unsigned integer
    uint64_t next_u64() {
        *m_state += 0x9e3779b97f4a7c55ULL;
        uint64_t result = *m_state;
        result = (result ^ (result >> 30)) * 0xbf58476d1ce4e5b9ULL;
        result = (result ^ (result >> 27)) * 0x94d049bb133111ebULL;
        return result ^ (result >> 31);
    }
    
    // Generate a random double in range [0, 1)
    double next_double() {
        return static_cast<double>(next_u64() >> 11) * (1.0 / (1ULL << 53));
    }
    
    // Seed the generator
    void seed_state(uint64_t seed) {
        *m_state = seed;
    }
    
private:
    std::unique_ptr<uint64_t> m_state;
};

} // namespace rng

// C API compatibility layer
extern "C" {
    // Opaque struct type for the C API
    struct wyrand_simd_rng {
        std::shared_ptr<rng::WyRandSimd> impl;
    };
    
    // Create a new RNG instance
    wyrand_simd_rng* wyrand_simd_new(uint64_t seed) {
        auto rng = new wyrand_simd_rng;
        rng->impl = std::make_shared<rng::WyRandSimd>(seed);
        return rng;
    }
    
    // Free the RNG instance
    void wyrand_simd_free(wyrand_simd_rng* rng) {
        if (rng) {
            delete rng;
        }
    }
    
    // Get next 64-bit unsigned integer
    uint64_t wyrand_simd_next_u64(wyrand_simd_rng* rng) {
        return rng->impl->next_u64();
    }
    
    // Get next double in range [0, 1)
    double wyrand_simd_next_double(wyrand_simd_rng* rng) {
        return rng->impl->next_double();
    }
}

#endif // WYRAND_H