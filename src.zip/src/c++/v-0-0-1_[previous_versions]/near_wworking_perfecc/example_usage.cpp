// Run benchmark with 100 million iterations
size_t iterations = 100000000;
RNGBenchmarkConfig* benchmark = run_rng_benchmark(
    iterations, 
    RNG_ALGORITHM_XOROSHIRO, 
    RNG_PRECISION_DOUBLE
);

// Export results to CSV
benchmark->csv_output_path = "xoroshiro_performance.csv";
export_benchmark_to_csv(benchmark);

// Get GPU optimization insights
GPUDeviceCapabilities gpu_caps;
detect_gpu_capabilities(&gpu_caps);
recommend_gpu_optimizations(&gpu_caps);

// Cleanup
free_benchmark_results(benchmark);
