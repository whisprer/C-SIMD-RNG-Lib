#ifndef UNIVERSAL_RNG_H
#define UNIVERSAL_RNG_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>
#include <stddef.h>

// Explicit opaque struct declaration
typedef struct universal_rng_t universal_rng_t;

universal_rng_t* universal_rng_new(uint64_t seed, int algorithm_type, int precision_mode);
uint64_t universal_rng_next_u64(universal_rng_t* rng);
double universal_rng_next_double(universal_rng_t* rng);
void universal_rng_generate_batch(universal_rng_t* rng, uint64_t* results, size_t count);
const char* universal_rng_get_implementation(universal_rng_t* rng);
void universal_rng_free_string(const char* str);  // Add this line
void universal_rng_free(universal_rng_t* rng);

#ifdef __cplusplus
}
#endif

#endif // UNIVERSAL_RNG_H
