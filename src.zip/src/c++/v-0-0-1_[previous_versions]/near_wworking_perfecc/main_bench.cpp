/ main_bench.cpp
#include <stdio.h>

// Include the four bench headers
// (non-optimized vs. optimized, WyRand vs. xoroshiro128++)
#include "wyrand_rng_bench.h"
#include "wyrand_rng_bench_optimized.h"
#include "xoroshiro128pp_rng_bench.h"
#include "xoroshiro128pp_rng_bench_optimized.h"

int main() {
    // Call each bench in turn, to produce 4 sets of timing results:
    run_wyrand_bench();
    run_wyrand_bench_optimized();
    run_xoroshiro_bench();
    run_xoroshiro_bench_optimized();

    return 0;
}