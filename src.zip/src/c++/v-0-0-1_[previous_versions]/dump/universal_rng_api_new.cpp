#include "rng_includes.h"
#include "universal_rng_types.h"

// Include scalar implementation only for now
#include "scalar_impl.h"

extern "C" {

universal_rng_t* universal_rng_new(uint64_t seed, int algorithm_type, int precision_mode) {
    std::cout << "Creating RNG...\n";
    
    // Create a new universal RNG - CRITICAL: Avoid initializer list
    universal_rng_t* rng = new universal_rng_t;
    
    // Initialize all fields explicitly one by one
    rng->state = nullptr;
    rng->next_u64 = nullptr;
    rng->next_double = nullptr;
    rng->generate_batch = nullptr;
    rng->free_func = nullptr;
    rng->implementation_type = RNG_IMPL_SCALAR; // Default to scalar
    rng->algorithm_type = static_cast<RNGAlgorithmType>(algorithm_type);
    rng->precision_mode = static_cast<RNGPrecisionMode>(precision_mode);
    
    // REMOVED: All AVX512, AVX2, and SSE2 implementations
    
    // Use scalar implementation directly
    std::cout << "Using scalar implementation\n";
    void* state = scalar_new(seed);
    if (state) {
        rng->implementation_type = RNG_IMPL_SCALAR;
        rng->next_u64 = scalar_next_u64;
        rng->next_double = scalar_next_double;
        rng->generate_batch = scalar_next_batch;
        rng->free_func = scalar_free;
    }
    
    // If all implementations failed, clean up and return nullptr
    if (!state) {
        std::cout << "Failed to create any RNG implementation\n";
        delete rng;
        return nullptr;
    }
    
    // Set the state last
    rng->state = state;
    std::cout << "RNG created successfully\n";
    return rng;
}


uint64_t universal_rng_next_u64(universal_rng_t* rng) {
    if (rng && rng->next_u64 && rng->state) {
        return rng->next_u64(rng->state);
    }
    return 0;
}

double universal_rng_next_double(universal_rng_t* rng) {
    if (rng && rng->next_double && rng->state) {
        return rng->next_double(rng->state);
    }
    return 0.0;
}

void universal_rng_generate_batch(universal_rng_t* rng, uint64_t* results, size_t count) {
    if (rng && rng->generate_batch && rng->state && results) {
        rng->generate_batch(rng->state, results, count);
    }
}

const char* universal_rng_get_implementation(universal_rng_t* rng) {
    if (!rng) return "Invalid RNG";
    
    std::string impl_name;
    
    // Get implementation name
    switch (rng->implementation_type) {
        case RNG_IMPL_SCALAR:
            impl_name = "Scalar";
            break;
        case RNG_IMPL_SSE2:
            impl_name = "SSE2";
            break;
        case RNG_IMPL_AVX2:
            impl_name = "AVX2";
            break;
        case RNG_IMPL_AVX512:
            impl_name = "AVX-512";
            break;
        default:
            impl_name = "Unknown";
            break;
    }
    
    // Get algorithm name
    switch (rng->algorithm_type) {
        case RNG_ALGORITHM_XOROSHIRO:
            impl_name += " Xoroshiro128++";
            break;
        case RNG_ALGORITHM_WYRAND:
            impl_name += " WyRand";
            break;
        default:
            impl_name += " Unknown Algorithm";
            break;
    }
    
    // Allocate and return string
    char* result = new char[impl_name.length() + 1];
    strcpy(result, impl_name.c_str());
    return result;
}

void universal_rng_free_string(const char* str) {
    delete[] str;
}

void universal_rng_free(universal_rng_t* rng) {
    if (rng) {
        if (rng->free_func && rng->state) {
            rng->free_func(rng->state);
        }
        delete rng;
    }
}

}  // extern "C"