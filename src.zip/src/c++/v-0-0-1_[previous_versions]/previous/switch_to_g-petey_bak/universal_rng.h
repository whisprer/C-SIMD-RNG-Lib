#ifndef UNIVERSAL_RNG_H
#define UNIVERSAL_RNG_H

#include <cstdint>
#include <cstdlib>

// Enums for algorithm + precision
typedef enum {
    RNG_ALGORITHM_XOROSHIRO,
    RNG_ALGORITHM_WYRAND
} RNGAlgorithmType;

typedef enum {
    RNG_PRECISION_SINGLE,
    RNG_PRECISION_DOUBLE
} RNGPrecisionMode;

// Single, clean definition
typedef struct universal_rng_t {
    void* state;
    RNGAlgorithmType algorithm_type;
    RNGPrecisionMode precision_mode;
    int implementation_type;

    // If you need a string describing the chosen implementation
    const char* impl_name;

    // Function pointers for RNG ops
    uint64_t (*next_u64)(void* state);
    double   (*next_double)(void* state);
    void     (*next_batch)(void* state, uint64_t* results, size_t count);
    void     (*free_func)(void* state);
} universal_rng_t;

// Declarations for the functions you implement in universal_rng.cpp
#ifdef __cplusplus
extern "C" {
#endif

universal_rng_t* universal_rng_new(uint64_t seed, 
                                   RNGAlgorithmType algo_type, 
                                   RNGPrecisionMode precision);

uint64_t universal_rng_next_u64(universal_rng_t* rng);
double   universal_rng_next_double(universal_rng_t* rng);
void     universal_rng_next_batch(universal_rng_t* rng, 
                                  uint64_t* results, size_t count);
void     universal_rng_free(universal_rng_t* rng);
const char* universal_rng_get_impl_name(universal_rng_t* rng);

#ifdef __cplusplus
}
#endif

#endif // UNIVERSAL_RNG_H
