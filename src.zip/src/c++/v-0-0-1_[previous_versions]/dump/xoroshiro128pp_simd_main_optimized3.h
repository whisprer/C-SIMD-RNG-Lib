#ifndef XOROSHIRO128PP_SIMD_MAIN_OPTIMIZED_H
#define XOROSHIRO128PP_SIMD_MAIN_OPTIMIZED_H

#include <cstdint>
#include <memory>
#include <array>
#include <random>
#include <type_traits>
#include <algorithm>

// CPU feature detection
#if defined(__AVX512F__) && defined(__AVX512DQ__)
    #define USE_AVX512 1
    #include <immintrin.h>
#elif defined(__AVX2__)
    #define USE_AVX2 1
    #include <immintrin.h>
#elif defined(__AVX__)
    #define USE_AVX 1
    #include <immintrin.h>
#elif defined(__SSE2__) || (defined(_MSC_VER) && (defined(_M_X64) || (defined(_M_IX86_FP) && _M_IX86_FP >= 2)))
    #define USE_SSE2 1
    #include <emmintrin.h>
#elif defined(__ARM_NEON) || defined(__ARM_NEON__)
    #define USE_NEON 1
    #include <arm_neon.h>
#endif

// Implementation type identifiers
enum RngImplType {
    RNG_IMPL_SCALAR = 0,
    RNG_IMPL_SSE2,
    RNG_IMPL_AVX,
    RNG_IMPL_AVX2,
    RNG_IMPL_AVX512,
    RNG_IMPL_NEON,
    RNG_IMPL_OPENCL
};

// Algorithm types
enum RngAlgorithmType {
    RNG_ALGORITHM_XOROSHIRO = 0,
    RNG_ALGORITHM_WYRAND
};

// Precision modes
enum RngPrecisionMode {
    RNG_PRECISION_SINGLE = 0,
    RNG_PRECISION_DOUBLE
};

namespace rng {

// Aligned allocation wrapper with RAII
template<typename T>
class AlignedMemory {
public:
    AlignedMemory(size_t size, size_t alignment = 64) : size_(size), alignment_(alignment) {
        #if defined(_MSC_VER)
            data_ = static_cast<T*>(_aligned_malloc(size * sizeof(T), alignment));
        #else
            if (posix_memalign(reinterpret_cast<void**>(&data_), alignment, size * sizeof(T)) != 0) {
                data_ = nullptr;
            }
        #endif
    }

    ~AlignedMemory() {
        if (data_) {
            #if defined(_MSC_VER)
                _aligned_free(data_);
            #else
                free(data_);
            #endif
            data_ = nullptr;
        }
    }

    // Prevent copying
    AlignedMemory(const AlignedMemory&) = delete;
    AlignedMemory& operator=(const AlignedMemory&) = delete;

    // Allow moving
    AlignedMemory(AlignedMemory&& other) noexcept 
        : data_(other.data_), size_(other.size_), alignment_(other.alignment_) {
        other.data_ = nullptr;
    }

    AlignedMemory& operator=(AlignedMemory&& other) noexcept {
        if (this != &other) {
            // Free current resource
            if (data_) {
                #if defined(_MSC_VER)
                    _aligned_free(data_);
                #else
                    free(data_);
                #endif
            }
            
            // Take other's resource
            data_ = other.data_;
            size_ = other.size_;
            alignment_ = other.alignment_;
            other.data_ = nullptr;
        }
        return *this;
    }

    T* get() const { return data_; }
    T& operator[](size_t index) { return data_[index]; }
    const T& operator[](size_t index) const { return data_[index]; }
    size_t size() const { return size_; }

private:
    T* data_ = nullptr;
    size_t size_ = 0;
    size_t alignment_ = 64;
};

// Helpful utility for rotation
template<typename T>
constexpr T rotl(T x, int k) {
    static_assert(std::is_unsigned<T>::value, "rotl requires unsigned types");
    return (x << k) | (x >> (std::numeric_limits<T>::digits - k));
}

// Base class for RNG implementations
class RandomGenerator {
public:
    virtual ~RandomGenerator() = default;
    
    virtual uint64_t next_u64() = 0;
    
    virtual double next_double() {
        // Convert to double in [0,1)
        return static_cast<double>(next_u64() >> 11) * (1.0 / (1ull << 53));
    }
    
    virtual float next_float() {
        // Convert to float in [0,1)
        return static_cast<float>(next_u64() >> 40) * (1.0f / (1ull << 24));
    }
    
    virtual void jump() = 0;
    virtual void long_jump() = 0;
    
    // Helper to get multiple random values at once
    template<typename T, size_t N>
    void fill_array(std::array<T, N>& arr) {
        for (auto& val : arr) {
            if constexpr (std::is_same_v<T, uint64_t>) {
                val = next_u64();
            } else if constexpr (std::is_same_v<T, double>) {
                val = next_double();
            } else if constexpr (std::is_same_v<T, float>) {
                val = next_float();
            } else {
                static_assert(std::is_convertible_v<uint64_t, T>, "Unsupported type for fill_array");
                val = static_cast<T>(next_u64());
            }
        }
    }
    
    virtual RngImplType get_implementation_type() const = 0;
};

// Splitmix64 for seed initialization
class SplitMix64 {
public:
    explicit SplitMix64(uint64_t seed) : state_(seed) {}
    
    uint64_t next() {
        uint64_t z = (state_ += 0x9e3779b97f4a7c15ull);
        z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ull;
        z = (z ^ (z >> 27)) * 0x94d049bb133111ebull;
        return z ^ (z >> 31);
    }
    
private:
    uint64_t state_;
};

// Scalar implementation of Xoroshiro128++
class Xoroshiro128pp_Scalar final : public RandomGenerator {
public:
    explicit Xoroshiro128pp_Scalar(uint64_t seed) {
        SplitMix64 sm(seed);
        state_[0] = sm.next();
        state_[1] = sm.next();
    }
    
    uint64_t next_u64() override {
        const uint64_t s0 = state_[0];
        uint64_t s1 = state_[1];
        const uint64_t result = rotl(s0 + s1, 17) + s0;

        s1 ^= s0;
        state_[0] = rotl(s0, 49) ^ s1 ^ (s1 << 21);
        state_[1] = rotl(s1, 28);

        return result;
    }
    
    void jump() override {
        static constexpr std::array<uint64_t, 2> JUMP_CONST = {
            0x2bd7a6a6e99c2ddc, 0x0992ccaf6a6fca05
        };
        
        uint64_t s0 = 0;
        uint64_t s1 = 0;
        
        for (const auto& jconst : JUMP_CONST) {
            for (int b = 0; b < 64; b++) {
                if (jconst & (1ULL << b)) {
                    s0 ^= state_[0];
                    s1 ^= state_[1];
                }
                next_u64();
            }
        }
        
        state_[0] = s0;
        state_[1] = s1;
    }
    
    void long_jump() override {
        static constexpr std::array<uint64_t, 2> LONG_JUMP_CONST = {
            0x360fd5f2cf8d5d99, 0x9c6e6877736c46e3
        };
        
        uint64_t s0 = 0;
        uint64_t s1 = 0;
        
        for (const auto& jconst : LONG_JUMP_CONST) {
            for (int b = 0; b < 64; b++) {
                if (jconst & (1ULL << b)) {
                    s0 ^= state_[0];
                    s1 ^= state_[1];
                }
                next_u64();
            }
        }
        
        state_[0] = s0;
        state_[1] = s1;
    }
    
    RngImplType get_implementation_type() const override {
        return RNG_IMPL_SCALAR;
    }
    
private:
    std::array<uint64_t, 2> state_;
};

#ifdef USE_SSE2
// SSE2 implementation of Xoroshiro128++
class Xoroshiro128pp_SSE2 final : public RandomGenerator {
public:
    explicit Xoroshiro128pp_SSE2(uint64_t seed) {
        SplitMix64 sm(seed);
        state_mem_ = std::make_unique<AlignedMemory<uint64_t>>(4, 16);
        state_mem_->get()[0] = sm.next();
        state_mem_->get()[1] = sm.next();
        state_mem_->get()[2] = sm.next();
        state_mem_->get()[3] = sm.next();
        state_ = reinterpret_cast<__m128i*>(state_mem_->get());
    }
    
    uint64_t next_u64() override {
        const __m128i s0 = _mm_load_si128(&state_[0]);
        __m128i s1 = _mm_load_si128(&state_[1]);
        
        // result = rotl(s0 + s1, 17) + s0
        const __m128i sum = _mm_add_epi64(s0, s1);
        const __m128i rot_sum = _mm_or_si128(
            _mm_slli_epi64(sum, 17),
            _mm_srli_epi64(sum, 47)
        );
        const __m128i result = _mm_add_epi64(rot_sum, s0);
        
        // Update state
        s1 = _mm_xor_si128(s1, s0);
        
        // s0 = rotl(s0, 49) ^ s1 ^ (s1 << 21)
        const __m128i rot_s0 = _mm_or_si128(
            _mm_slli_epi64(s0, 49),
            _mm_srli_epi64(s0, 15)
        );
        const __m128i s1_shift = _mm_slli_epi64(s1, 21);
        const __m128i new_s0 = _mm_xor_si128(_mm_xor_si128(rot_s0, s1), s1_shift);
        
        // s1 = rotl(s1, 28)
        const __m128i new_s1 = _mm_or_si128(
            _mm_slli_epi64(s1, 28),
            _mm_srli_epi64(s1, 36)
        );
        
        _mm_store_si128(&state_[0], new_s0);
        _mm_store_si128(&state_[1], new_s1);
        
        // Extract 64-bit result from lower part of result vector
        alignas(16) uint64_t res[2];
        _mm_store_si128(reinterpret_cast<__m128i*>(res), result);
        return res[0];
    }
    
    void jump() override {
        static constexpr std::array<uint64_t, 2> JUMP_CONST = {
            0x2bd7a6a6e99c2ddc, 0x0992ccaf6a6fca05
        };
        
        __m128i s0 = _mm_setzero_si128();
        __m128i s1 = _mm_setzero_si128();
        
        for (const auto& jconst : JUMP_CONST) {
            for (int b = 0; b < 64; b++) {
                if (jconst & (1ULL << b)) {
                    s0 = _mm_xor_si128(s0, state_[0]);
                    s1 = _mm_xor_si128(s1, state_[1]);
                }
                next_u64();
            }
        }
        
        _mm_store_si128(&state_[0], s0);
        _mm_store_si128(&state_[1], s1);
    }
    
    void long_jump() override {
        static constexpr std::array<uint64_t, 2> LONG_JUMP_CONST = {
            0x360fd5f2cf8d5d99, 0x9c6e6877736c46e3
        };
        
        __m128i s0 = _mm_setzero_si128();
        __m128i s1 = _mm_setzero_si128();
        
        for (const auto& jconst : LONG_JUMP_CONST) {
            for (int b = 0; b < 64; b++) {
                if (jconst & (1ULL << b)) {
                    s0 = _mm_xor_si128(s0, state_[0]);
                    s1 = _mm_xor_si128(s1, state_[1]);
                }
                next_u64();
            }
        }
        
        _mm_store_si128(&state_[0], s0);
        _mm_store_si128(&state_[1], s1);
    }
    
    RngImplType get_implementation_type() const override {
        return RNG_IMPL_SSE2;
    }
    
private:
    std::unique_ptr<AlignedMemory<uint64_t>> state_mem_;
    __m128i* state_ = nullptr;
};
#endif

#ifdef USE_AVX2
// AVX2 implementation of Xoroshiro128++
class Xoroshiro128pp_AVX2 final : public RandomGenerator {
public:
    explicit Xoroshiro128pp_AVX2(uint64_t seed) {
        SplitMix64 sm(seed);
        state_mem_ = std::make_unique<AlignedMemory<uint64_t>>(8, 32);
        
        for (int i = 0; i < 8; i++) {
            state_mem_->get()[i] = sm.next();
        }
        
        state_ = reinterpret_cast<__m256i*>(state_mem_->get());
    }
    
    uint64_t next_u64() override {
        const __m256i s0 = _mm256_load_si256(&state_[0]);
        __m256i s1 = _mm256_load_si256(&state_[1]);
        
        // result = rotl(s0 + s1, 17) + s0
        const __m256i sum = _mm256_add_epi64(s0, s1);
        const __m256i rot_sum = _mm256_or_si256(
            _mm256_slli_epi64(sum, 17),
            _mm256_srli_epi64(sum, 47)
        );
        const __m256i result = _mm256_add_epi64(rot_sum, s0);
        
        // Update state
        s1 = _mm256_xor_si256(s1, s0);
        
        // s0 = rotl(s0, 49) ^ s1 ^ (s1 << 21)
        const __m256i rot_s0 = _mm256_or_si256(
            _mm256_slli_epi64(s0, 49),
            _mm256_srli_epi64(s0, 15)
        );
        const __m256i s1_shift = _mm256_slli_epi64(s1, 21);
        const __m256i new_s0 = _mm256_xor_si256(_mm256_xor_si256(rot_s0, s1), s1_shift);
        
        // s1 = rotl(s1, 28)
        const __m256i new_s1 = _mm256_or_si256(
            _mm256_slli_epi64(s1, 28),
            _mm256_srli_epi64(s1, 36)
        );
        
        _mm256_store_si256(&state_[0], new_s0);
        _mm256_store_si256(&state_[1], new_s1);
        
        // Extract 64-bit result from lower part of result vector
        alignas(32) uint64_t res[4];
        _mm256_store_si256(reinterpret_cast<__m256i*>(res), result);
        return res[0];
    }
    
    void jump() override {
        static constexpr std::array<uint64_t, 2> JUMP_CONST = {
            0x2bd7a6a6e99c2ddc, 0x0992ccaf6a6fca05
        };
        
        __m256i s0 = _mm256_setzero_si256();
        __m256i s1 = _mm256_setzero_si256();
        
        for (const auto& jconst : JUMP_CONST) {
            for (int b = 0; b < 64; b++) {
                if (jconst & (1ULL << b)) {
                    s0 = _mm256_xor_si256(s0, state_[0]);
                    s1 = _mm256_xor_si256(s1, state_[1]);
                }
                next_u64();
            }
        }
        
        _mm256_store_si256(&state_[0], s0);
        _mm256_store_si256(&state_[1], s1);
    }
    
    void long_jump() override {
        static constexpr std::array<uint64_t, 2> LONG_JUMP_CONST = {
            0x360fd5f2cf8d5d99, 0x9c6e6877736c46e3
        };
        
        __m256i s0 = _mm256_setzero_si256();
        __m256i s1 = _mm256_setzero_si256();
        
        for (const auto& jconst : LONG_JUMP_CONST) {
            for (int b = 0; b < 64; b++) {
                if (jconst & (1ULL << b)) {
                    s0 = _mm256_xor_si256(s0, state_[0]);
                    s1 = _mm256_xor_si256(s1, state_[1]);
                }
                next_u64();
            }
        }
        
        _mm256_store_si256(&state_[0], s0);
        _mm256_store_si256(&state_[1], s1);
    }
    
    RngImplType get_implementation_type() const override {
        return RNG_IMPL_AVX2;
    }
    
private:
    std::unique_ptr<AlignedMemory<uint64_t>> state_mem_;
    __m256i* state_ = nullptr;
};
#endif

#ifdef USE_AVX512
// AVX-512 implementation of Xoroshiro128++
class Xoroshiro128pp_AVX512 final : public RandomGenerator {
public:
    explicit Xoroshiro128pp_AVX512(uint64_t seed) {
        SplitMix64 sm(seed);
        state_mem_ = std::make_unique<AlignedMemory<uint64_t>>(16, 64);
        
        for (int i = 0; i < 16; i++) {
            state_mem_->get()[i] = sm.next();
        }
        
        state_ = reinterpret_cast<__m512i*>(state_mem_->get());
    }
    
    uint64_t next_u64() override {
        const __m512i s0 = _mm512_load_si512(&state_[0]);
        __m512i s1 = _mm512_load_si512(&state_[1]);
        
        // result = rotl(s0 + s1, 17) + s0
        const __m512i sum = _mm512_add_epi64(s0, s1);
        const __m512i rot_sum = _mm512_or_si512(
            _mm512_slli_epi64(sum, 17),
            _mm512_srli_epi64(sum, 47)
        );
        const __m512i result = _mm512_add_epi64(rot_sum, s0);
        
        // Update state
        s1 = _mm512_xor_si512(s1, s0);
        
        // s0 = rotl(s0, 49) ^ s1 ^ (s1 << 21)
        const __m512i rot_s0 = _mm512_or_si512(
            _mm512_slli_epi64(s0, 49),
            _mm512_srli_epi64(s0, 15)
        );
        const __m512i s1_shift = _mm512_slli_epi64(s1, 21);
        const __m512i new_s0 = _mm512_xor_si512(_mm512_xor_si512(rot_s0, s1), s1_shift);
        
        // s1 = rotl(s1, 28)
        const __m512i new_s1 = _mm512_or_si512(
            _mm512_slli_epi64(s1, 28),
            _mm512_srli_epi64(s1, 36)
        );
        
        _mm512_store_si512(&state_[0], new_s0);
        _mm512_store_si512(&state_[1], new_s1);
        
        // Extract 64-bit result from lower part of result vector
        alignas(64) uint64_t res[8];
        _mm512_store_si512(reinterpret_cast<__m512i*>(res), result);
        return res[0];
    }
    
    void jump() override {
        static constexpr std::array<uint64_t, 2> JUMP_CONST = {
            0x2bd7a6a6e99c2ddc, 0x0992ccaf6a6fca05
        };
        
        __m512i s0 = _mm512_setzero_si512();
        __m512i s1 = _mm512_setzero_si512();
        
        for (const auto& jconst : JUMP_CONST) {
            for (int b = 0; b < 64; b++) {
                if (jconst & (1ULL << b)) {
                    s0 = _mm512_xor_si512(s0, state_[0]);
                    s1 = _mm512_xor_si512(s1, state_[1]);
                }
                next_u64();
            }
        }
        
        _mm512_store_si512(&state_[0], s0);
        _mm512_store_si512(&state_[1], s1);
    }
    
    void long_jump() override {
        static constexpr std::array<uint64_t, 2> LONG_JUMP_CONST = {
            0x360fd5f2cf8d5d99, 0x9c6e6877736c46e3
        };
        
        __m512i s0 = _mm512_setzero_si512();
        __m512i s1 = _mm512_setzero_si512();
        
        for (const auto& jconst : LONG_JUMP_CONST) {
            for (int b = 0; b < 64; b++) {
                if (jconst & (1ULL << b)) {
                    s0 = _mm512_xor_si512(s0, state_[0]);
                    s1 = _mm512_xor_si512(s1, state_[1]);
                }
                next_u64();
            }
        }
        
        _mm512_store_si512(&state_[0], s0);
        _mm512_store_si512(&state_[1], s1);
    }
    
    RngImplType get_implementation_type() const override {
        return RNG_IMPL_AVX512;
    }
    
private:
    std::unique_ptr<AlignedMemory<uint64_t>> state_mem_;
    __m512i* state_ = nullptr;
};
#endif

#ifdef USE_NEON
// NEON implementation of Xoroshiro128++
class Xoroshiro128pp_NEON final : public RandomGenerator {
public:
    explicit Xoroshiro128pp_NEON(uint64_t seed) {
        SplitMix64 sm(seed);
        state_mem_ = std::make_unique<AlignedMemory<uint64_t>>(4, 16);
        state_mem_->get()[0] = sm.next();
        state_mem_->get()[1] = sm.next();
        state_mem_->get()[2] = sm.next();
        state_mem_->get()[3] = sm.next();
        state_ = reinterpret_cast<uint64x2_t*>(state_mem_->get());
    }
    
    uint64_t next_u64() override {
        const uint64x2_t s0 = vld1q_u64(reinterpret_cast<uint64_t*>(&state_[0]));
        uint64x2_t s1 = vld1q_u64(reinterpret_cast<uint64_t*>(&state_[1]));
        
        // result = rotl(s0 + s1, 17) + s0
        const uint64x2_t sum = vaddq_u64(s0, s1);
        const uint64x2_t rot_sum = vorrq_u64(
            vshlq_n_u64(sum, 17),
            vshrq_n_u64(sum, 47)
        );
        const uint64x2_t result = vaddq_u64(rot_sum, s0);
        
        // Update state
        s1 = veorq_u64(s1, s0);
        
        // s0 = rotl(s0, 49) ^ s1 ^ (s1 << 21)
        const uint64x2_t rot_s0 = vorrq_u64(
            vshlq_n_u64(s0, 49),
            vshrq_n_u64(s0, 15)
        );
        const uint64x2_t s1_shift = vshlq_n_u64(s1, 21);
        const uint64x2_t new_s0 = veorq_u64(veorq_u64(rot_s0, s1), s1_shift);
        
        // s1 = rotl(s1, 28)
        const uint64x2_t new_s1 = vorrq_u64(
            vshlq_n_u64(s1, 28),
            vshrq_n_u64(s1, 36)
        );
        
        vst1q_u64(reinterpret_cast<uint64_t*>(&state_[0]), new_s0);
        vst1q_u64(reinterpret_cast<uint64_t*>(&state_[1]), new_s1);
        
        // Extract 64-bit result from lower part of result vector
        alignas(16) uint64_t res[2];
        vst1q_u64(res, result);
        return res[0];
    }
    
    void jump() override {
        static constexpr std::array<uint64_t, 2> JUMP_CONST = {
            0x2bd7a6a6e99c2ddc, 0x0992ccaf6a6fca05
        };
        
        uint64x2_t s0 = vdupq_n_u64(0);
        uint64x2_t s1 = vdupq_n_u64(0);
        
        for (const auto& jconst : JUMP_CONST) {
            for (int b = 0; b < 64; b++) {
                if (jconst & (1ULL << b)) {
                    s0 = veorq_u64(s0, state_[0]);
                    s1 = veorq_u64(s1, state_[1]);
                }
                next_u64();
            }
        }
        
        vst1q_u64(reinterpret_cast<uint64_t*>(&state_[0]), s0);
        vst1q_u64(reinterpret_cast<uint64_t*>(&state_[1]), s1);
    }
    
    void long_jump() override {
        static constexpr std::array<uint64_t, 2> LONG_JUMP_CONST = {
            0x360fd5f2cf8d5d99, 0x9c6e6877736c46e3
        };
        
        uint64x2_t s0 = vdupq_n_u64(0);
        uint64x2_t s1 = vdupq_n_u64(0);
        
        for (const auto& jconst : LONG_JUMP_CONST) {
            for (int b =

                