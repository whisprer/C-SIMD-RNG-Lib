// wyrand_test.cpp
#include <stdio.h>
#include "wyrand_rng_bench.h"

int main() {
    printf("=== WyRand Benchmark (Non-Optimized) ===\n\n");
    run_wyrand_bench();
    return 0;
}