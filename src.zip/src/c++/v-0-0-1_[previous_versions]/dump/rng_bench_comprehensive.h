#ifndef RNG_COMPREHENSIVE_BENCH_H
#define RNG_COMPREHENSIVE_BENCH_H

#include "rng_common.h"
#include "wyrand.h"
#include "xoroshiro128pp.h"
#include <iostream>
#include <iomanip>
#include <memory>
#include <vector>
#include <string>
#include <functional>
#include <chrono>
#include <fstream>

namespace rng {
namespace bench {

// Benchmark configuration
struct BenchmarkConfig {
    uint64_t iterations = 100'000'000; // 100 million by default
    uint64_t seed = 42;
    bool display_usage_examples = true;
    bool display_summary = true;
    bool export_csv = false;
    std::string csv_file = "rng_benchmark_results.csv";
    int num_runs = 1; // Number of runs for statistical significance
};

// Result of a single benchmark run
struct BenchmarkResult {
    std::string name;
    std::string implementation;
    double time_seconds;
    double millions_per_second;
    double speedup; // Relative to baseline
    std::vector<double> run_times; // For multiple runs
    
    // Statistics
    double min_time = 0.0;
    double max_time = 0.0;
    double avg_time = 0.0;
    double std_dev = 0.0;
    
    // Calculate statistics from run times
    void calculate_statistics() {
        if (run_times.empty()) {
            return;
        }
        
        min_time = *std::min_element(run_times.begin(), run_times.end());
        max_time = *std::max_element(run_times.begin(), run_times.end());
        avg_time = std::accumulate(run_times.begin(), run_times.end(), 0.0) / run_times.size();
        
        double variance = 0.0;
        for (const auto& time : run_times) {
            double diff = time - avg_time;
            variance += diff * diff;
        }
        std_dev = std::sqrt(variance / run_times.size());
        
        // Update primary time with average
        time_seconds = avg_time;
        millions_per_second = iterations / (time_seconds * 1'000'000);
    }
};

// RNG benchmark suite
class RngBenchmarkSuite {
public:
    RngBenchmarkSuite() = default;
    
    // Add a new RNG implementation to benchmark
    template<typename RngType>
    void add_rng(const std::string& name, std::function<RngType()> factory,
                 std::function<uint64_t(RngType&)> next_u64_func) {
        m_benchmark_funcs.push_back([name, factory, next_u64_func, this](uint64_t iterations) {
            auto rng = factory();
            auto start = std::chrono::high_resolution_clock::now();
            
            uint64_t sum = 0;
            for(uint64_t i = 0; i < iterations; i++) {
                sum ^= next_u64_func(rng);
            }
            
            auto end = std::chrono::high_resolution_clock::now();
            std::chrono::duration<double> duration = end - start;
            
            // Anti-optimization trick
            if(sum == 1) std::cout << "Won't happen: " << sum << std::endl;
            
            m_results[name] = duration.count();
            return duration.count();
        });
        
        m_rng_names.push_back(name);
    }
    
    // Run all benchmarks
    void run_all(const BenchmarkConfig& config) {
        std::cout << "\n=== COMPREHENSIVE RNG BENCHMARK ===\n\n";
        std::cout << "SIMD Support:\n";
        std::cout << "-------------\n";
        rng::print_simd_support();
        std::cout << "\n";
        
        std::cout << "Running benchmarks with " << config.iterations << " iterations each...\n\n";
        
        std::vector<BenchmarkResult> results;
        
        // Run all benchmarks
        for (size_t i = 0; i < m_benchmark_funcs.size(); ++i) {
            const auto& name = m_rng_names[i];
            std::cout << "Benchmarking " << name << "... ";
            std::cout.flush();
            
            BenchmarkResult result;
            result.name = name;
            
            // Run multiple times if configured
            for (int run = 0; run < config.num_runs; ++run) {
                double time = m_benchmark_funcs[i](config.iterations);
                result.run_times.push_back(time);
                
                if (config.num_runs > 1) {
                    std::cout << "Run " << (run + 1) << ": " << std::fixed << std::setprecision(4) 
                              << time << "s, ";
                    std::cout.flush();
                }
            }
            
            // Calculate statistics
            result.calculate_statistics();
            
            if (config.num_runs > 1) {
                std::cout << "Avg: " << std::fixed << std::setprecision(4) << result.avg_time 
                          << "s (" << std::fixed << std::setprecision(2) 
                          << (config.iterations/result.avg_time)/1e6 << " M/s)\n";
            } else {
                std::cout << "done. Time: " << std::fixed << std::setprecision(4) << result.time_seconds 
                          << " s (" << std::fixed << std::setprecision(2) 
                          << (config.iterations/result.time_seconds)/1e6 << " M/s)\n";
            }
            
            results.push_back(result);
        }
        
        // Print summary
        std::cout << "\nSummary:\n";
        std::cout << "--------\n";
        
        // Find the fastest implementation
        std::string fastest_name;
        double fastest_time = std::numeric_limits<double>::max();
        
        for (auto& result : results) {
            if (result.time_seconds < fastest_time) {
                fastest_time = result.time_seconds;
                fastest_name = result.name;
            }
        }
        
        // Calculate speedups relative to fastest
        for (auto& result : results) {
            result.speedup = fastest_time / result.time_seconds; // Now 1.0 means fastest, < 1.0 means slower
        }
        
        // Print results
        std::cout << std::left << std::setw(30) << "RNG Implementation" 
                  << std::setw(12) << "Time (s)" 
                  << std::setw(12) << "Speed (M/s)"
                  << std::setw(12) << "Relative"
                  << "\n";
        
        std::cout << std::string(70, '-') << "\n";
        
        for (const auto& result : results) {
            std::cout << std::left << std::setw(30) << result.name
                      << std::fixed << std::setprecision(4) << std::setw(12) << result.time_seconds
                      << std::fixed << std::setprecision(2) << std::setw(12) << result.millions_per_second
                      << std::fixed << std::setprecision(2) << std::setw(12) << result.speedup
                      << "\n";
        }
        
        std::cout << "\nFastest implementation: " << fastest_name << "\n";
        
        // Export to CSV if requested
        if (config.export_csv) {
            std::ofstream csv(config.csv_file);
            csv << "Algorithm,Time(s),M/sec,Relative";
            if (config.num_runs > 1) {
                csv << ",Min(s),Max(s),Avg(s),StdDev(s)";
            }
            csv << "\n";
            
            for (const auto& result : results) {
                csv << result.name << ","
                    << std::fixed << std::setprecision(6) << result.time_seconds << ","
                    << std::fixed << std::setprecision(2) << result.millions_per_second << ","
                    << std::fixed << std::setprecision(2) << result.speedup;
                    
                if (config.num_runs > 1) {
                    csv << "," << std::fixed << std::setprecision(6) << result.min_time
                        << "," << std::fixed << std::setprecision(6) << result.max_time
                        << "," << std::fixed << std::setprecision(6) << result.avg_time
                        << "," << std::fixed << std::setprecision(6) << result.std_dev;
                }
                
                csv << "\n";
            }
        }
        
        // Store in member variables
        m_benchmark_results = std::move(results);
    }
    
    // Run with default configuration
    void run_all(uint64_t iterations = 100000000ULL) {
        BenchmarkConfig config;
        config.iterations = iterations;
        run_all(config);
    }
    
    // Static convenience method
    static void run_comprehensive_benchmark(uint64_t iterations = 100000000ULL) {
        BenchmarkConfig config;
        config.iterations = iterations;
        
        RngBenchmarkSuite suite;
        
        // Add original Xoroshiro128+
        suite.add_rng<Xoroshiro128Plus>(
            "Xoroshiro128+ (original)",
            []() { return Xoroshiro128Plus(42); },
            [](Xoroshiro128Plus& rng) { return rng.next_u64(); }
        );
        
        // Add Xoroshiro128++ (stack)
        suite.add_rng<Xoroshiro128PlusPlus>(
            "Xoroshiro128++ (stack)",
            []() { return Xoroshiro128PlusPlus(42); },
            [](Xoroshiro128PlusPlus& rng) { return rng.next_u64(); }
        );
        
        // Add Xoroshiro128++ (SIMD)
        suite.add_rng<Xoroshiro128PpSimd>(
            "Xoroshiro128++ (SIMD)",
            []() { return Xoroshiro128PpSimd(42); },
            [](Xoroshiro128PpSimd& rng) { return rng.next_u64(); }
        );
        
        // Add WyRand (stack)
        suite.add_rng<WyRand>(
            "WyRand (stack)",
            []() { return WyRand(42); },
            [](WyRand& rng) { return rng.next_u64(); }
        );
        
        // Add WyRand (SIMD)
        suite.add_rng<WyRandSimd>(
            "WyRand (SIMD)",
            []() { return WyRandSimd(42); },
            [](WyRandSimd& rng) { return rng.next_u64(); }
        );
        
        // Run all benchmarks
        suite.run_all(config);
    }
    
    // Get benchmark results
    const std::vector<BenchmarkResult>& get_results() const {
        return m_benchmark_results;
    }
    
private:
    std::vector<std::function<double(uint64_t)>> m_benchmark_funcs;
    std::vector<std::string> m_rng_names;
    std::unordered_map<std::string, double> m_results;
    std::vector<BenchmarkResult> m_benchmark_results;
    uint64_t iterations = 100000000ULL;
};

} // namespace bench
} // namespace rng

// C-style function for backwards compatibility
inline void run_comprehensive_bench() {
    rng::bench::RngBenchmarkSuite::run_comprehensive_benchmark();
}

#endif // RNG_COMPREHENSIVE_BENCH_H