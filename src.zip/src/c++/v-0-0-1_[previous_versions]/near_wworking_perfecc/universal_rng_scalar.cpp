#include "universal_rng.h"

#ifdef __cplusplus
extern "C" {
#endif

void* scalar_new(uint64_t seed);
uint64_t scalar_next_u64(void* st);
double scalar_next_double(void* st);
void scalar_next_batch(void* st, uint64_t* results, size_t count);
void scalar_free(void* st);

#ifdef __cplusplus
}
#endif

// Define xoroshiro128pp_state if not already defined
typedef struct {
    uint64_t s[2];
} xoroshiro128pp_state;

uint64_t scalar_next_u64(void* state) {
    xoroshiro128pp_state* s = (xoroshiro128pp_state*)state;
    const uint64_t s0 = s->s[0];
    uint64_t s1 = s->s[1];
    
    const uint64_t result = rotl(s0 + s1, 17) + s0;
    
    s1 ^= s0;
    s->s[0] = rotl(s0, 49) ^ s1 ^ (s1 << 21);
    s->s[1] = rotl(s1, 28);
    
    return result;
}

double scalar_next_double(void* state) {
    uint64_t v = scalar_next_u64(state);
    return (v >> 11) * (1.0 / (1ULL << 53));
}

void* scalar_new(uint64_t seed) {
    xoroshiro128pp_state* rng_state = (xoroshiro128pp_state*)malloc(sizeof(xoroshiro128pp_state));
    
    uint64_t z = (seed + 0x9e3779b97f4a7c15ULL);
    z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
    z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
    rng_state->s[0] = z ^ (z >> 31);
    
    z = (rng_state->s[0] + 0x9e3779b97f4a7c15ULL);
    z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
    z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
    rng_state->s[1] = z ^ (z >> 31);
    
    return rng_state;
}

void scalar_free(void* state) {
    free(state);
}

void scalar_next_batch(void* state, uint64_t* results, size_t count) {
    for (size_t i = 0; i < count; i++) {
        results[i] = scalar_next_u64(state);
    }
}