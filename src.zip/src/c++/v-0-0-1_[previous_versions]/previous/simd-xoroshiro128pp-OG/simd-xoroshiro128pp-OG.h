// SIMD-Optimized xoroshiro128++ Implementation
//
// This code implements parallel versions of xoroshiro128++ using
// SIMD instructions for AVX2, AVX-512, and ARM Neon architectures.
//
// Based on the original xoroshiro128+ algorithm by David Blackman and Sebastiano Vigna
// Adapted to use the ++ scrambler for improved statistical properties

#include <stdint.h>
#include <string.h>
#include <stdlib.h>

#ifdef _MSC_VER
#include <intrin.h>
#else
#include <x86intrin.h>
#endif

// Platform detection
// First check for explicitly defined platforms (from command line)
#if defined(__AVX512F__) && defined(__AVX512DQ__)
  #ifndef USE_AVX512
    #define USE_AVX512
  #endif
#elif defined(__AVX2__)
  #ifndef USE_AVX2
    #define USE_AVX2
  #endif
#elif defined(__AVX__)
  #ifndef USE_AVX
    #define USE_AVX
  #endif
#elif defined(__ARM_NEON)
  #ifndef USE_NEON
    #define USE_NEON
  #endif
  #include <arm_neon.h>
#elif defined(__SSE2__)
  #ifndef USE_SSE2
    #define USE_SSE2
  #endif
#endif

// Aligned memory allocation
#if defined(_MSC_VER) || defined(_WIN32) || defined(__CYGWIN__) || defined(__MINGW32__)
  // Windows (MSVC, MinGW, Cygwin)
  #include <malloc.h>
  #define ALIGN_ALLOC(alignment, size) _aligned_malloc(size, alignment)
  #define ALIGN_FREE(ptr) _aligned_free(ptr)
#else
  // Unix-like (Linux, macOS)
  #define ALIGN_ALLOC(alignment, size) aligned_alloc(alignment, size)
  #define ALIGN_FREE(ptr) free(ptr)
#endif

// Helper function for scalar rotl
static inline uint64_t rotl(const uint64_t x, int k) {
    return (x << k) | (x >> (64 - k));
}

/////////////////////////////////////////////////////////////////////////////
// Scalar xoroshiro128++ implementation for reference and fallback
/////////////////////////////////////////////////////////////////////////////
typedef struct {
    uint64_t s[2];
} xoroshiro128pp_state;

static inline uint64_t xoroshiro128pp_next(xoroshiro128pp_state *state) {
    const uint64_t s0 = state->s[0];
    uint64_t s1 = state->s[1];
    
    // Calculate output with ++ scrambler (rotate-add)
    const uint64_t result = rotl(s0 + s1, 17) + s0;
    
    // Update state
    s1 ^= s0;
    state->s[0] = rotl(s0, 49) ^ s1 ^ (s1 << 21);
    state->s[1] = rotl(s1, 28);
    
    return result;
}

// Function to initialize a scalar state from a 64-bit seed
static void xoroshiro128pp_seed(xoroshiro128pp_state *state, uint64_t seed) {
    // Use SplitMix64 to initialize the state
    uint64_t z = (seed + 0x9e3779b97f4a7c15ULL);
    z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
    z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
    state->s[0] = z ^ (z >> 31);
    
    z = (state->s[0] + 0x9e3779b97f4a7c15ULL);
    z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
    z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
    state->s[1] = z ^ (z >> 31);
}


/////////////////////////////////////////////////////////////////////////////
// AVX2 implementation (4 parallel streams)
/////////////////////////////////////////////////////////////////////////////

#ifdef USE_AVX2

typedef struct {
    __m256i state0;  // 4 streams, first state component
    __m256i state1;  // 4 streams, second state component
    int aligned;     // Flag to track if we're using aligned memory
} xoroshiro128pp_avx2;

// Helper for AVX2 rotl
static inline __m256i rotl_avx2(__m256i x, int k) {
    return _mm256_or_si256(_mm256_slli_epi64(x, k), _mm256_srli_epi64(x, 64 - k));
}

// Initialize 4 parallel streams with different seeds
static void xoroshiro128pp_avx2_init(xoroshiro128pp_avx2 *state, const uint64_t seeds[4]) {
    // We'll use SplitMix64 to generate the actual initial states
    xoroshiro128pp_state tmp;
    uint64_t *s0_ptr = (uint64_t*)&state->state0;
    uint64_t *s1_ptr = (uint64_t*)&state->state1;
    
    for (int i = 0; i < 4; i++) {
        xoroshiro128pp_seed(&tmp, seeds[i]);
        s0_ptr[i] = tmp.s[0];
        s1_ptr[i] = tmp.s[1];
    }
    
    state->aligned = 1;
}

// Generate 4 random 64-bit values in parallel
static void xoroshiro128pp_avx2_next(xoroshiro128pp_avx2 *state, uint64_t results[4]) {
    // Calculate output - scrambler is: rotl(s0 + s1, 17) + s0
    __m256i sum = _mm256_add_epi64(state->state0, state->state1);
    __m256i rotated_sum = rotl_avx2(sum, 17);
    __m256i result = _mm256_add_epi64(rotated_sum, state->state0);
    
    // Store results
    _mm256_storeu_si256((__m256i*)results, result);
    
    // Update state
    __m256i s1 = _mm256_xor_si256(state->state0, state->state1);
    
    state->state0 = _mm256_xor_si256(
                      rotl_avx2(state->state0, 49),
                      _mm256_xor_si256(
                          s1,
                          _mm256_slli_epi64(s1, 21)
                      )
                    );
                    
    state->state1 = rotl_avx2(s1, 28);
}

// Initialize with a single seed (will create 4 different streams)
static xoroshiro128pp_avx2* xoroshiro128pp_avx2_new(uint64_t seed) {
    xoroshiro128pp_avx2* state = (xoroshiro128pp_avx2*)ALIGN_ALLOC(32, sizeof(xoroshiro128pp_avx2));
    
    // Create 4 different seeds from the master seed
    uint64_t seeds[4];
    xoroshiro128pp_state tmp;
    xoroshiro128pp_seed(&tmp, seed);
    
    seeds[0] = tmp.s[0];
    seeds[1] = tmp.s[1];
    
    xoroshiro128pp_seed(&tmp, seeds[0]);
    seeds[2] = tmp.s[0];
    seeds[3] = tmp.s[1];
    
    xoroshiro128pp_avx2_init(state, seeds);
    return state;
}

static void xoroshiro128pp_avx2_free(xoroshiro128pp_avx2* state) {
    ALIGN_FREE(state);
}

#endif // USE_AVX2


/////////////////////////////////////////////////////////////////////////////
// AVX-512 implementation (8 parallel streams)
/////////////////////////////////////////////////////////////////////////////

#ifdef USE_AVX512

typedef struct {
    __m512i state0;  // 8 streams, first state component
    __m512i state1;  // 8 streams, second state component
    int aligned;     // Flag to track if we're using aligned memory
} xoroshiro128pp_avx512;

// Helper for AVX-512 rotl
static inline __m512i rotl_avx512(__m512i x, int k) {
    return _mm512_or_si512(_mm512_slli_epi64(x, k), _mm512_srli_epi64(x, 64 - k));
}

// Initialize 8 parallel streams with different seeds
static void xoroshiro128pp_avx512_init(xoroshiro128pp_avx512 *state, const uint64_t seeds[8]) {
    // We'll use SplitMix64 to generate the actual initial states
    xoroshiro128pp_state tmp;
    uint64_t *s0_ptr = (uint64_t*)&state->state0;
    uint64_t *s1_ptr = (uint64_t*)&state->state1;
    
    for (int i = 0; i < 8; i++) {
        xoroshiro128pp_seed(&tmp, seeds[i]);
        s0_ptr[i] = tmp.s[0];
        s1_ptr[i] = tmp.s[1];
    }
    
    state->aligned = 1;
}

// Generate 8 random 64-bit values in parallel
static void xoroshiro128pp_avx512_next(xoroshiro128pp_avx512 *state, uint64_t results[8]) {
    // Calculate output - scrambler is: rotl(s0 + s1, 17) + s0
    __m512i sum = _mm512_add_epi64(state->state0, state->state1);
    __m512i rotated_sum = rotl_avx512(sum, 17);
    __m512i result = _mm512_add_epi64(rotated_sum, state->state0);
    
    // Store results
    _mm512_storeu_si512((__m512i*)results, result);
    
    // Update state
    __m512i s1 = _mm512_xor_si512(state->state0, state->state1);
    
    state->state0 = _mm512_xor_si512(
                      rotl_avx512(state->state0, 49),
                      _mm512_xor_si512(
                          s1,
                          _mm512_slli_epi64(s1, 21)
                      )
                    );
                    
    state->state1 = rotl_avx512(s1, 28);
}

// Initialize with a single seed (will create 8 different streams)
static xoroshiro128pp_avx512* xoroshiro128pp_avx512_new(uint64_t seed) {
    xoroshiro128pp_avx512* state = (xoroshiro128pp_avx512*)ALIGN_ALLOC(64, sizeof(xoroshiro128pp_avx512));
    
    // Create 8 different seeds from the master seed
    uint64_t seeds[8];
    xoroshiro128pp_state tmp;
    xoroshiro128pp_seed(&tmp, seed);
    
    // Generate 8 different seeds
    seeds[0] = tmp.s[0];
    seeds[1] = tmp.s[1];
    
    for (int i = 1; i < 4; i++) {
        xoroshiro128pp_next(&tmp);
        seeds[i*2] = tmp.s[0];
        seeds[i*2+1] = tmp.s[1];
    }
    
    xoroshiro128pp_avx512_init(state, seeds);
    return state;
}

static void xoroshiro128pp_avx512_free(xoroshiro128pp_avx512* state) {
    ALIGN_FREE(state);
}

#endif // USE_AVX512


/////////////////////////////////////////////////////////////////////////////
// ARM Neon implementation (2 parallel streams)
/////////////////////////////////////////////////////////////////////////////

#ifdef USE_NEON

typedef struct {
    uint64x2_t state0;  // 2 streams, first state component
    uint64x2_t state1;  // 2 streams, second state component
    int aligned;        // Flag to track if we're using aligned memory
} xoroshiro128pp_neon;

// Helper for NEON rotl
static inline uint64x2_t rotl_neon(uint64x2_t x, int k) {
    return vsriq_n_u64(vshlq_n_u64(x, k), x, 64 - k);
}

// Initialize 2 parallel streams with different seeds
static void xoroshiro128pp_neon_init(xoroshiro128pp_neon *state, const uint64_t seeds[2]) {
    // We'll use SplitMix64 to generate the actual initial states
    xoroshiro128pp_state tmp;
    uint64_t s0_vals[2];
    uint64_t s1_vals[2];
    
    for (int i = 0; i < 2; i++) {
        xoroshiro128pp_seed(&tmp, seeds[i]);
        s0_vals[i] = tmp.s[0];
        s1_vals[i] = tmp.s[1];
    }
    
    state->state0 = vld1q_u64(s0_vals);
    state->state1 = vld1q_u64(s1_vals);
    state->aligned = 1;
}

// Generate 2 random 64-bit values in parallel
static void xoroshiro128pp_neon_next(xoroshiro128pp_neon *state, uint64_t results[2]) {
    // Calculate output - scrambler is: rotl(s0 + s1, 17) + s0
    uint64x2_t sum = vaddq_u64(state->state0, state->state1);
    uint64x2_t rotated_sum = rotl_neon(sum, 17);
    uint64x2_t result = vaddq_u64(rotated_sum, state->state0);
    
    // Store results
    vst1q_u64(results, result);
    
    // Update state
    uint64x2_t s1 = veorq_u64(state->state0, state->state1);
    
    state->state0 = veorq_u64(
                      rotl_neon(state->state0, 49),
                      veorq_u64(
                          s1,
                          vshlq_n_u64(s1, 21)
                      )
                    );
                    
    state->state1 = rotl_neon(s1, 28);
}

// Initialize with a single seed (will create 2 different streams)
static xoroshiro128pp_neon* xoroshiro128pp_neon_new(uint64_t seed) {
    xoroshiro128pp_neon* state = (xoroshiro128pp_neon*)ALIGN_ALLOC(16, sizeof(xoroshiro128pp_neon));
    
    // Create 2 different seeds from the master seed
    uint64_t seeds[2];
    xoroshiro128pp_state tmp;
    xoroshiro128pp_seed(&tmp, seed);
    
    seeds[0] = tmp.s[0];
    seeds[1] = tmp.s[1];
    
    xoroshiro128pp_neon_init(state, seeds);
    return state;
}

static void xoroshiro128pp_neon_free(xoroshiro128pp_neon* state) {
    ALIGN_FREE(state);
}

#endif // USE_NEON


/////////////////////////////////////////////////////////////////////////////
// SSE2 implementation (2 parallel streams)
/////////////////////////////////////////////////////////////////////////////

#ifdef __SSE2__

typedef struct {
    __m128i state0;  // 2 streams, first state component
    __m128i state1;  // 2 streams, second state component
    int aligned;     // Flag to track if we're using aligned memory
} xoroshiro128pp_sse2;

// Helper for SSE2 rotl
static inline __m128i rotl_sse2(__m128i x, int k) {
    return _mm_or_si128(_mm_slli_epi64(x, k), _mm_srli_epi64(x, 64 - k));
}

// Initialize 2 parallel streams with different seeds
static void xoroshiro128pp_sse2_init(xoroshiro128pp_sse2 *state, const uint64_t seeds[2]) {
    // We'll use SplitMix64 to generate the actual initial states
    xoroshiro128pp_state tmp;
    uint64_t s0_vals[2];
    uint64_t s1_vals[2];
    
    for (int i = 0; i < 2; i++) {
        xoroshiro128pp_seed(&tmp, seeds[i]);
        s0_vals[i] = tmp.s[0];
        s1_vals[i] = tmp.s[1];
    }
    
    state->state0 = _mm_loadu_si128((__m128i*)s0_vals);
    state->state1 = _mm_loadu_si128((__m128i*)s1_vals);
    state->aligned = 1;
}

// Generate 2 random 64-bit values in parallel
static void xoroshiro128pp_sse2_next(xoroshiro128pp_sse2 *state, uint64_t results[2]) {
    // Calculate output - scrambler is: rotl(s0 + s1, 17) + s0
    __m128i sum = _mm_add_epi64(state->state0, state->state1);
    __m128i rotated_sum = rotl_sse2(sum, 17);
    __m128i result = _mm_add_epi64(rotated_sum, state->state0);
    
    // Store results
    _mm_storeu_si128((__m128i*)results, result);
    
    // Update state
    __m128i s1 = _mm_xor_si128(state->state0, state->state1);
    
    state->state0 = _mm_xor_si128(
                      rotl_sse2(state->state0, 49),
                      _mm_xor_si128(
                          s1,
                          _mm_slli_epi64(s1, 21)
                      )
                    );
                    
    state->state1 = rotl_sse2(s1, 28);
}

// Initialize with a single seed (will create 2 different streams)
static xoroshiro128pp_sse2* xoroshiro128pp_sse2_new(uint64_t seed) {
    xoroshiro128pp_sse2* state = (xoroshiro128pp_sse2*)ALIGN_ALLOC(16, sizeof(xoroshiro128pp_sse2));
    
    // Create 2 different seeds from the master seed
    uint64_t seeds[2];
    xoroshiro128pp_state tmp;
    xoroshiro128pp_seed(&tmp, seed);
    
    seeds[0] = tmp.s[0];
    seeds[1] = tmp.s[1];
    
    xoroshiro128pp_sse2_init(state, seeds);
    return state;
}

static void xoroshiro128pp_sse2_free(xoroshiro128pp_sse2* state) {
    ALIGN_FREE(state);
}

#endif // __SSE2__


/////////////////////////////////////////////////////////////////////////////
// Basic AVX implementation (4 parallel streams)
/////////////////////////////////////////////////////////////////////////////

#if defined(__AVX__) && !defined(__AVX2__)

typedef struct {
    __m256i state0;  // 4 streams, first state component
    __m256i state1;  // 4 streams, second state component
    int aligned;     // Flag to track if we're using aligned memory
} xoroshiro128pp_avx;

// Helper for basic AVX rotl
// Note: Basic AVX has limited integer operations, so we use __m128i ops and combine
static inline __m256i rotl_avx(__m256i x, int k) {
    __m128i x_lo = _mm256_extractf128_si256(x, 0);
    __m128i x_hi = _mm256_extractf128_si256(x, 1);
    
    __m128i rotl_lo = _mm_or_si128(_mm_slli_epi64(x_lo, k), _mm_srli_epi64(x_lo, 64 - k));
    __m128i rotl_hi = _mm_or_si128(_mm_slli_epi64(x_hi, k), _mm_srli_epi64(x_hi, 64 - k));
    
    return _mm256_insertf128_si256(_mm256_castsi128_si256(rotl_lo), rotl_hi, 1);
}

// Initialize 4 parallel streams with different seeds
static void xoroshiro128pp_avx_init(xoroshiro128pp_avx *state, const uint64_t seeds[4]) {
    // We'll use SplitMix64 to generate the actual initial states
    xoroshiro128pp_state tmp;
    uint64_t s0_vals[4];
    uint64_t s1_vals[4];
    
    for (int i = 0; i < 4; i++) {
        xoroshiro128pp_seed(&tmp, seeds[i]);
        s0_vals[i] = tmp.s[0];
        s1_vals[i] = tmp.s[1];
    }
    
    state->state0 = _mm256_loadu_si256((__m256i*)s0_vals);
    state->state1 = _mm256_loadu_si256((__m256i*)s1_vals);
    state->aligned = 1;
}

// Vector add for AVX (basic AVX lacks _mm256_add_epi64, so we use 128-bit ops)
static inline __m256i avx_add_epi64(__m256i a, __m256i b) {
    __m128i a_lo = _mm256_extractf128_si256(a, 0);
    __m128i a_hi = _mm256_extractf128_si256(a, 1);
    __m128i b_lo = _mm256_extractf128_si256(b, 0);
    __m128i b_hi = _mm256_extractf128_si256(b, 1);
    
    __m128i sum_lo = _mm_add_epi64(a_lo, b_lo);
    __m128i sum_hi = _mm_add_epi64(a_hi, b_hi);
    
    return _mm256_insertf128_si256(_mm256_castsi128_si256(sum_lo), sum_hi, 1);
}

// Vector xor for AVX
static inline __m256i avx_xor_si256(__m256i a, __m256i b) {
    __m128i a_lo = _mm256_extractf128_si256(a, 0);
    __m128i a_hi = _mm256_extractf128_si256(a, 1);
    __m128i b_lo = _mm256_extractf128_si256(b, 0);
    __m128i b_hi = _mm256_extractf128_si256(b, 1);
    
    __m128i xor_lo = _mm_xor_si128(a_lo, b_lo);
    __m128i xor_hi = _mm_xor_si128(a_hi, b_hi);
    
    return _mm256_insertf128_si256(_mm256_castsi128_si256(xor_lo), xor_hi, 1);
}

// Vector shift left for AVX
static inline __m256i avx_slli_epi64(__m256i a, int count) {
    __m128i a_lo = _mm256_extractf128_si256(a, 0);
    __m128i a_hi = _mm256_extractf128_si256(a, 1);
    
    __m128i shift_lo = _mm_slli_epi64(a_lo, count);
    __m128i shift_hi = _mm_slli_epi64(a_hi, count);
    
    return _mm256_insertf128_si256(_mm256_castsi128_si256(shift_lo), shift_hi, 1);
}

// Generate 4 random 64-bit values in parallel
static void xoroshiro128pp_avx_next(xoroshiro128pp_avx *state, uint64_t results[4]) {
    // Calculate output - scrambler is: rotl(s0 + s1, 17) + s0
    __m256i sum = avx_add_epi64(state->state0, state->state1);
    __m256i rotated_sum = rotl_avx(sum, 17);
    __m256i result = avx_add_epi64(rotated_sum, state->state0);
    
    // Store results
    _mm256_storeu_si256((__m256i*)results, result);
    
    // Update state
    __m256i s1 = avx_xor_si256(state->state0, state->state1);
    
    state->state0 = avx_xor_si256(
                      rotl_avx(state->state0, 49),
                      avx_xor_si256(
                          s1,
                          avx_slli_epi64(s1, 21)
                      )
                    );
                    
    state->state1 = rotl_avx(s1, 28);
}

// Initialize with a single seed (will create 4 different streams)
static xoroshiro128pp_avx* xoroshiro128pp_avx_new(uint64_t seed) {
    xoroshiro128pp_avx* state = (xoroshiro128pp_avx*)ALIGN_ALLOC(32, sizeof(xoroshiro128pp_avx));
    
    // Create 4 different seeds from the master seed
    uint64_t seeds[4];
    xoroshiro128pp_state tmp;
    xoroshiro128pp_seed(&tmp, seed);
    
    seeds[0] = tmp.s[0];
    seeds[1] = tmp.s[1];
    
    xoroshiro128pp_next(&tmp);
    seeds[2] = tmp.s[0];
    seeds[3] = tmp.s[1];
    
    xoroshiro128pp_avx_init(state, seeds);
    return state;
}

static void xoroshiro128pp_avx_free(xoroshiro128pp_avx* state) {
    ALIGN_FREE(state);
}

#endif // defined(__AVX__) && !defined(__AVX2__)


/////////////////////////////////////////////////////////////////////////////
// OpenCL/GPU implementation (massively parallel streams)
/////////////////////////////////////////////////////////////////////////////

#ifdef USE_OPENCL

#ifdef _WIN32
#include <CL/cl.h>
#else
#include <OpenCL/opencl.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// OpenCL kernel for xoroshiro128++
const char* xoroshiro128pp_opencl_kernel = R"(
// Helper function for rotl
inline ulong rotl(const ulong x, int k) {
    return (x << k) | (x >> (64 - k));
}

// xoroshiro128++ next function for OpenCL
void xoroshiro128pp_next(ulong2 *state, ulong *result) {
    const ulong s0 = state->x;
    ulong s1 = state->y;
    
    // Calculate output with ++ scrambler (rotate-add)
    *result = rotl(s0 + s1, 17) + s0;
    
    // Update state
    s1 ^= s0;
    state->x = rotl(s0, 49) ^ s1 ^ (s1 << 21);
    state->y = rotl(s1, 28);
}

// Generate a batch of random numbers in parallel
__kernel void xoroshiro128pp_generate(
    __global ulong2* states,
    __global ulong* results,
    const uint count
) {
    uint id = get_global_id(0);
    if (id < count) {
        // Copy state to local memory for better performance
        ulong2 state;
        state.x = states[id].x;
        state.y = states[id].y;
        
        // Generate random number
        ulong result;
        xoroshiro128pp_next(&state, &result);
        
        // Write back state and result
        states[id] = state;
        results[id] = result;
    }
}

// Initialize state using SplitMix64
__kernel void initialize_states(
    __global ulong2* states,
    const ulong seed,
    const uint count
) {
    uint id = get_global_id(0);
    if (id < count) {
        // Use SplitMix64 to initialize the state
        ulong z = (seed + id * 0x9e3779b97f4a7c15UL);
        z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9UL;
        z = (z ^ (z >> 27)) * 0x94d049bb133111ebUL;
        ulong s0 = z ^ (z >> 31);
        
        z = (s0 + 0x9e3779b97f4a7c15UL);
        z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9UL;
        z = (z ^ (z >> 27)) * 0x94d049bb133111ebUL;
        ulong s1 = z ^ (z >> 31);
        
        // Store state
        states[id].x = s0;
        states[id].y = s1;
    }
}
)";

typedef struct {
    cl_context context;
    cl_command_queue queue;
    cl_program program;
    cl_kernel generate_kernel;
    cl_kernel init_kernel;
    cl_mem states_buffer;
    cl_mem results_buffer;
    size_t workgroup_size;
    size_t batch_size;
    uint64_t* host_results;
    size_t result_pos;
    int initialized;
} xoroshiro128pp_opencl;

// Create and initialize OpenCL implementation
static xoroshiro128pp_opencl* xoroshiro128pp_opencl_new(uint64_t seed) {
    xoroshiro128pp_opencl* opencl = (xoroshiro128pp_opencl*)malloc(sizeof(xoroshiro128pp_opencl));
    memset(opencl, 0, sizeof(xoroshiro128pp_opencl));
    
    cl_int err;
    cl_platform_id platform;
    cl_device_id device;
    
    // Get OpenCL platform
    err = clGetPlatformIDs(1, &platform, NULL);
    if (err != CL_SUCCESS) {
        fprintf(stderr, "Failed to find OpenCL platform\n");
        free(opencl);
        return NULL;
    }
    
    // Get GPU device
    err = clGetDeviceIDs(platform, CL_DEVICE_TYPE_GPU, 1, &device, NULL);
    if (err != CL_SUCCESS) {
        // If no GPU is available, try CPU
        err = clGetDeviceIDs(platform, CL_DEVICE_TYPE_CPU, 1, &device, NULL);
        if (err != CL_SUCCESS) {
            fprintf(stderr, "Failed to find OpenCL device\n");
            free(opencl);
            return NULL;
        }
    }
    
    // Create context
    opencl->context = clCreateContext(NULL, 1, &device, NULL, NULL, &err);
    if (err != CL_SUCCESS) {
        fprintf(stderr, "Failed to create OpenCL context\n");
        free(opencl);
        return NULL;
    }
    
    // Create command queue
    #ifdef CL_VERSION_2_0
    opencl->queue = clCreateCommandQueueWithProperties(opencl->context, device, NULL, &err);
    #else
    opencl->queue = clCreateCommandQueue(opencl->context, device, 0, &err);
    #endif
    if (err != CL_SUCCESS) {
        fprintf(stderr, "Failed to create OpenCL command queue\n");
        clReleaseContext(opencl->context);
        free(opencl);
        return NULL;
    }
    
    // Create and build program
    opencl->program = clCreateProgramWithSource(opencl->context, 1, 
                                             &xoroshiro128pp_opencl_kernel, NULL, &err);
    if (err != CL_SUCCESS) {
        fprintf(stderr, "Failed to create OpenCL program\n");
        clReleaseCommandQueue(opencl->queue);
        clReleaseContext(opencl->context);
        free(opencl);
        return NULL;
    }
    
    err = clBuildProgram(opencl->program, 1, &device, NULL, NULL, NULL);
    if (err != CL_SUCCESS) {
        size_t log_size;
        clGetProgramBuildInfo(opencl->program, device, CL_PROGRAM_BUILD_LOG, 0, NULL, &log_size);
        char* log = (char*)malloc(log_size);
        clGetProgramBuildInfo(opencl->program, device, CL_PROGRAM_BUILD_LOG, log_size, log, NULL);
        fprintf(stderr, "OpenCL build error: %s\n", log);
        free(log);
        clReleaseProgram(opencl->program);
        clReleaseCommandQueue(opencl->queue);
        clReleaseContext(opencl->context);
        free(opencl);
        return NULL;
    }
    
    // Create kernels
    opencl->generate_kernel = clCreateKernel(opencl->program, "xoroshiro128pp_generate", &err);
    if (err != CL_SUCCESS) {
        fprintf(stderr, "Failed to create generate kernel\n");
        clReleaseProgram(opencl->program);
        clReleaseCommandQueue(opencl->queue);
        clReleaseContext(opencl->context);
        free(opencl);
        return NULL;
    }
    
    opencl->init_kernel = clCreateKernel(opencl->program, "initialize_states", &err);
    if (err != CL_SUCCESS) {
        fprintf(stderr, "Failed to create init kernel\n");
        clReleaseKernel(opencl->generate_kernel);
        clReleaseProgram(opencl->program);
        clReleaseCommandQueue(opencl->queue);
        clReleaseContext(opencl->context);
        free(opencl);
        return NULL;
    }
    
    // Get workgroup size
    err = clGetKernelWorkGroupInfo(opencl->generate_kernel, device, CL_KERNEL_WORK_GROUP_SIZE, 
                                  sizeof(size_t), &opencl->workgroup_size, NULL);
    if (err != CL_SUCCESS) {
        fprintf(stderr, "Failed to get workgroup size\n");
        clReleaseKernel(opencl->init_kernel);
        clReleaseKernel(opencl->generate_kernel);
        clReleaseProgram(opencl->program);
        clReleaseCommandQueue(opencl->queue);
        clReleaseContext(opencl->context);
        free(opencl);
        return NULL;
    }
    
    // Determine batch size (multiple of workgroup size)
    opencl->batch_size = opencl->workgroup_size * 64;  // 64 workgroups
    
    // Create buffers
    opencl->states_buffer = clCreateBuffer(opencl->context, CL_MEM_READ_WRITE, 
                                         opencl->batch_size * sizeof(cl_ulong2), NULL, &err);
    if (err != CL_SUCCESS) {
        fprintf(stderr, "Failed to create states buffer\n");
        clReleaseKernel(opencl->init_kernel);
        clReleaseKernel(opencl->generate_kernel);
        clReleaseProgram(opencl->program);
        clReleaseCommandQueue(opencl->queue);
        clReleaseContext(opencl->context);
        free(opencl);
        return NULL;
    }
    
    opencl->results_buffer = clCreateBuffer(opencl->context, CL_MEM_READ_WRITE, 
                                          opencl->batch_size * sizeof(cl_ulong), NULL, &err);
    if (err != CL_SUCCESS) {
        fprintf(stderr, "Failed to create results buffer\n");
        clReleaseMemObject(opencl->states_buffer);
        clReleaseKernel(opencl->init_kernel);
        clReleaseKernel(opencl->generate_kernel);
        clReleaseProgram(opencl->program);
        clReleaseCommandQueue(opencl->queue);
        clReleaseContext(opencl->context);
        free(opencl);
        return NULL;
    }
    
    // Allocate host buffer for results
    opencl->host_results = (uint64_t*)malloc(opencl->batch_size * sizeof(uint64_t));
    if (!opencl->host_results) {
        fprintf(stderr, "Failed to allocate host results buffer\n");
        clReleaseMemObject(opencl->results_buffer);
        clReleaseMemObject(opencl->states_buffer);
        clReleaseKernel(opencl->init_kernel);
        clReleaseKernel(opencl->generate_kernel);
        clReleaseProgram(opencl->program);
        clReleaseCommandQueue(opencl->queue);
        clReleaseContext(opencl->context);
        free(opencl);
        return NULL;
    }
    
    // Initialize states
    err = clSetKernelArg(opencl->init_kernel, 0, sizeof(cl_mem), &opencl->states_buffer);
    err |= clSetKernelArg(opencl->init_kernel, 1, sizeof(cl_ulong), &seed);
    err |= clSetKernelArg(opencl->init_kernel, 2, sizeof(cl_uint), &opencl->batch_size);
    if (err != CL_SUCCESS) {
        fprintf(stderr, "Failed to set init kernel arguments\n");
        free(opencl->host_results);
        clReleaseMemObject(opencl->results_buffer);
        clReleaseMemObject(opencl->states_buffer);
        clReleaseKernel(opencl->init_kernel);
        clReleaseKernel(opencl->generate_kernel);
        clReleaseProgram(opencl->program);
        clReleaseCommandQueue(opencl->queue);
        clReleaseContext(opencl->context);
        free(opencl);
        return NULL;
    }
    
    // Launch init kernel
    size_t global_size = ((opencl->batch_size + opencl->workgroup_size - 1) / 
                          opencl->workgroup_size) * opencl->workgroup_size;
    err = clEnqueueNDRangeKernel(opencl->queue, opencl->init_kernel, 1, NULL, 
                                &global_size, &opencl->workgroup_size, 0, NULL, NULL);
    if (err != CL_SUCCESS) {
        fprintf(stderr, "Failed to launch init kernel\n");
        free(opencl->host_results);
        clReleaseMemObject(opencl->results_buffer);
        clReleaseMemObject(opencl->states_buffer);
        clReleaseKernel(opencl->init_kernel);
        clReleaseKernel(opencl->generate_kernel);
        clReleaseProgram(opencl->program);
        clReleaseCommandQueue(opencl->queue);
        clReleaseContext(opencl->context);
        free(opencl);
        return NULL;
    }
    
    // Set generate kernel arguments
    err = clSetKernelArg(opencl->generate_kernel, 0, sizeof(cl_mem), &opencl->states_buffer);
    err |= clSetKernelArg(opencl->generate_kernel, 1, sizeof(cl_mem), &opencl->results_buffer);
    err |= clSetKernelArg(opencl->generate_kernel, 2, sizeof(cl_uint), &opencl->batch_size);
    if (err != CL_SUCCESS) {
        fprintf(stderr, "Failed to set generate kernel arguments\n");
        free(opencl->host_results);
        clReleaseMemObject(opencl->results_buffer);
        clReleaseMemObject(opencl->states_buffer);
        clReleaseKernel(opencl->init_kernel);
        clReleaseKernel(opencl->generate_kernel);
        clReleaseProgram(opencl->program);
        clReleaseCommandQueue(opencl->queue);
        clReleaseContext(opencl->context);
        free(opencl);
        return NULL;
    }
    
    // Generate first batch
    err = clEnqueueNDRangeKernel(opencl->queue, opencl->generate_kernel, 1, NULL, 
                                &global_size, &opencl->workgroup_size, 0, NULL, NULL);
    if (err != CL_SUCCESS) {
        fprintf(stderr, "Failed to launch generate kernel\n");
        free(opencl->host_results);
        clReleaseMemObject(opencl->results_buffer);
        clReleaseMemObject(opencl->states_buffer);
        clReleaseKernel(opencl->init_kernel);
        clReleaseKernel(opencl->generate_kernel);
        clReleaseProgram(opencl->program);
        clReleaseCommandQueue(opencl->queue);
        clReleaseContext(opencl->context);
        free(opencl);
        return NULL;
    }
    
    // Read results
    err = clEnqueueReadBuffer(opencl->queue, opencl->results_buffer, CL_TRUE, 0, 
                            opencl->batch_size * sizeof(cl_ulong), opencl->host_results, 
                            0, NULL, NULL);
    if (err != CL_SUCCESS) {
        fprintf(stderr, "Failed to read results from device\n");
        free(opencl->host_results);
        clReleaseMemObject(opencl->results_buffer);
        clReleaseMemObject(opencl->states_buffer);
        clReleaseKernel(opencl->init_kernel);
        clReleaseKernel(opencl->generate_kernel);
        clReleaseProgram(opencl->program);
        clReleaseCommandQueue(opencl->queue);
        clReleaseContext(opencl->context);
        free(opencl);
        return NULL;
    }
    
    opencl->result_pos = 0;
    opencl->initialized = 1;
    
    return opencl;
}

// Get next batch of random numbers
static void xoroshiro128pp_opencl_refill(xoroshiro128pp_opencl* opencl) {
    cl_int err;
    
    // Run generate kernel
    size_t global_size = ((opencl->batch_size + opencl->workgroup_size - 1) / 
                          opencl->workgroup_size) * opencl->workgroup_size;
    err = clEnqueueNDRangeKernel(opencl->queue, opencl->generate_kernel, 1, NULL, 
                                &global_size, &opencl->workgroup_size, 0, NULL, NULL);
    if (err != CL_SUCCESS) {
        fprintf(stderr, "Failed to launch generate kernel\n");
        return;
    }
    
    // Read results
    err = clEnqueueReadBuffer(opencl->queue, opencl->results_buffer, CL_TRUE, 0, 
                            opencl->batch_size * sizeof(cl_ulong), opencl->host_results, 
                            0, NULL, NULL);
    if (err != CL_SUCCESS) {
        fprintf(stderr, "Failed to read results from device\n");
        return;
    }
    
    opencl->result_pos = 0;
}

// Get next random number
static uint64_t xoroshiro128pp_opencl_next(xoroshiro128pp_opencl* opencl) {
    if (opencl->result_pos >= opencl->batch_size) {
        xoroshiro128pp_opencl_refill(opencl);
    }
    
    return opencl->host_results[opencl->result_pos++];
}

// Free OpenCL implementation
static void xoroshiro128pp_opencl_free(xoroshiro128pp_opencl* opencl) {
    if (opencl) {
        free(opencl->host_results);
        clReleaseMemObject(opencl->results_buffer);
        clReleaseMemObject(opencl->states_buffer);
        clReleaseKernel(opencl->init_kernel);
        clReleaseKernel(opencl->generate_kernel);
        clReleaseProgram(opencl->program);
        clReleaseCommandQueue(opencl->queue);
        clReleaseContext(opencl->context);
        free(opencl);
    }
}

#endif // USE_OPENCL


/////////////////////////////////////////////////////////////////////////////
// Universal wrapper API with GPU/OpenCL support
/////////////////////////////////////////////////////////////////////////////

// The number of parallel streams depends on the architecture
#if defined(USE_OPENCL)
    #define XORO_PARALLEL_STREAMS 1024  // Large batch for GPU
#elif defined(USE_AVX512)
    #define XORO_PARALLEL_STREAMS 8
#elif defined(USE_AVX2)
    #define XORO_PARALLEL_STREAMS 4
#elif defined(USE_AVX)
    #define XORO_PARALLEL_STREAMS 4
#elif defined(USE_NEON)
    #define XORO_PARALLEL_STREAMS 2
#elif defined(USE_SSE2)
    #define XORO_PARALLEL_STREAMS 2
#else
    #define XORO_PARALLEL_STREAMS 1
#endif

typedef struct {
    void* state;
    int type;         // 0 = scalar, 1 = AVX2, 2 = AVX512, 3 = NEON, 4 = SSE2, 5 = AVX, 6 = OpenCL/GPU
    int buffer_pos;   // Position in the current buffer
    uint64_t buffer[XORO_PARALLEL_STREAMS]; // Buffer for random values
} xoroshiro_simd_rng;

// Create a new RNG state with the best available SIMD or GPU implementation
xoroshiro_simd_rng* xoroshiro_simd_new(uint64_t seed) {
    xoroshiro_simd_rng* rng = (xoroshiro_simd_rng*)malloc(sizeof(xoroshiro_simd_rng));
    rng->buffer_pos = XORO_PARALLEL_STREAMS; // Force buffer refill on first call
    
    #if defined(USE_OPENCL)
        // Try GPU implementation first
        rng->state = xoroshiro128pp_opencl_new(seed);
        if (rng->state) {
            rng->type = 6;
            return rng;
        }
        // If GPU fails, fall through to CPU implementations
        printf("OpenCL initialization failed, falling back to CPU implementation.\n");
    #endif
    
    #if defined(USE_AVX512)
        rng->state = xoroshiro128pp_avx512_new(seed);
        rng->type = 2;
    #elif defined(USE_AVX2)
        rng->state = xoroshiro128pp_avx2_new(seed);
        rng->type = 1;
    #elif defined(USE_AVX)
        rng->state = xoroshiro128pp_avx_new(seed);
        rng->type = 5;
    #elif defined(USE_NEON)
        rng->state = xoroshiro128pp_neon_new(seed);
        rng->type = 3;
    #elif defined(USE_SSE2)
        rng->state = xoroshiro128pp_sse2_new(seed);
        rng->type = 4;
    #else
        rng->state = malloc(sizeof(xoroshiro128pp_state));
        xoroshiro128pp_seed((xoroshiro128pp_state*)rng->state, seed);
        rng->type = 0;
    #endif
    
    return rng;
}

// Free RNG state
void xoroshiro_simd_free(xoroshiro_simd_rng* rng) {
    if (rng) {
        #if defined(USE_OPENCL)
            if (rng->type == 6) {
                xoroshiro128pp_opencl_free((xoroshiro128pp_opencl*)rng->state);
                free(rng);
                return;
            }
        #endif
        
        #if defined(USE_AVX512)
            if (rng->type == 2) {
                xoroshiro128pp_avx512_free((xoroshiro128pp_avx512*)rng->state);
            }
        #endif
        #if defined(USE_AVX2)
            if (rng->type == 1) {
                xoroshiro128pp_avx2_free((xoroshiro128pp_avx2*)rng->state);
            }
        #endif
        #if defined(USE_AVX)
            if (rng->type == 5) {
                xoroshiro128pp_avx_free((xoroshiro128pp_avx*)rng->state);
            }
        #endif
        #if defined(USE_NEON)
            if (rng->type == 3) {
                xoroshiro128pp_neon_free((xoroshiro128pp_neon*)rng->state);
            }
        #endif
        #if defined(USE_SSE2)
            if (rng->type == 4) {
                xoroshiro128pp_sse2_free((xoroshiro128pp_sse2*)rng->state);
            }
        #endif
        if (rng->type == 0) {
            free(rng->state);
        }
        free(rng);
    }
}

// Function declarations
uint64_t xoroshiro_simd_next_u64(xoroshiro_simd_rng* rng);
double xoroshiro_simd_next_double(xoroshiro_simd_rng* rng);

// Get next 64-bit random value
uint64_t xoroshiro_simd_next_u64(xoroshiro_simd_rng* rng) {
    #if defined(USE_OPENCL)
        if (rng->type == 6) {
            return xoroshiro128pp_opencl_next((xoroshiro128pp_opencl*)rng->state);
        }
    #endif
    
    // For non-GPU implementations, use buffering as before
    if (rng->buffer_pos >= XORO_PARALLEL_STREAMS) {
        #if defined(USE_AVX512)
            if (rng->type == 2) {
                xoroshiro128pp_avx512_next((xoroshiro128pp_avx512*)rng->state, rng->buffer);
            }
        #endif
        #if defined(USE_AVX2)
            if (rng->type == 1) {
                xoroshiro128pp_avx2_next((xoroshiro128pp_avx2*)rng->state, rng->buffer);
            }
        #endif
        #if defined(USE_AVX)
            if (rng->type == 5) {
                xoroshiro128pp_avx_next((xoroshiro128pp_avx*)rng->state, rng->buffer);
            }
        #endif
        #if defined(USE_NEON)
            if (rng->type == 3) {
                xoroshiro128pp_neon_next((xoroshiro128pp_neon*)rng->state, rng->buffer);
            }
        #endif
        #if defined(USE_SSE2)
            if (rng->type == 4) {
                xoroshiro128pp_sse2_next((xoroshiro128pp_sse2*)rng->state, rng->buffer);
            }
        #endif
        if (rng->type == 0) {
            rng->buffer[0] = xoroshiro128pp_next((xoroshiro128pp_state*)rng->state);
        }
        rng->buffer_pos = 0;
    }
    
    // Return the next value from the buffer
    return rng->buffer[rng->buffer_pos++];
}

// Get random double in [0, 1) range
double xoroshiro_simd_next_double(xoroshiro_simd_rng* rng) {
    // Convert to double in [0,1) using the high 53 bits
    const uint64_t value = xoroshiro_simd_next_u64(rng);
    return (value >> 11) * (1.0 / (1ULL << 53));
}

/////////////////////////////////////////////////////////////////////////////
// Jump Function
/////////////////////////////////////////////////////////////////////////////

// Jump ahead equivalent to 2^64 calls to next()
// Used for creating multiple independent streams
void xoroshiro_simd_jump(xoroshiro_simd_rng* rng) {
    // We can only jump the scalar version currently
    if (rng->type != 0) {
        // For SIMD versions, we need to extract states, jump them,
        // and then put them back. This is complex, so we'll only 
        // implement the scalar version for simplicity.
        return;
    }
    
    static const uint64_t JUMP[] = { 0xdf900294d8f554a5, 0x170865df4b3201fc };
    xoroshiro128pp_state* state = (xoroshiro128pp_state*)rng->state;
    
    uint64_t s0 = 0;
    uint64_t s1 = 0;
    for (size_t i = 0; i < sizeof JUMP / sizeof *JUMP; i++) {
        for (int b = 0; b < 64; b++) {
            if (JUMP[i] & (1ULL << b)) {
                s0 ^= state->s[0];
                s1 ^= state->s[1];
            }
            xoroshiro128pp_next(state);
        }
    }
    
    state->s[0] = s0;
    state->s[1] = s1;
}


/////////////////////////////////////////////////////////////////////////////
// Usage example
/////////////////////////////////////////////////////////////////////////////

/*
int main() {
    // Create a new RNG with auto-selected SIMD implementation
    xoroshiro_simd_rng* rng = xoroshiro_simd_new(12345);
    
    // Generate and print some random numbers
    for (int i = 0; i < 10; i++) {
        printf("Random uint64: %llu\n", (unsigned long long)xoroshiro_simd_next_u64(rng));
        printf("Random double: %f\n", xoroshiro_simd_next_double(rng));
    }
    
    // Clean up
    xoroshiro_simd_free(rng);
    return 0;
}
*/
