#include "rng_bench_xoroshiro128pp_optimized.h"
// Nothing else needed here, main() is in the header.