#include "rng_comprehensive_bench.h"

// Main function implementation
int main(int argc, char* argv[]) {
    // Default to 100 million iterations
    uint64_t iterations = 100000000ULL;
    
    // Parse command line arguments for custom iteration count
    if (argc > 1) {
        try {
            iterations = std::stoull(argv[1]);
        } catch (const std::exception& e) {
            std::cerr << "Error parsing iteration count: " << e.what() << "\n";
            std::cerr << "Using default: " << iterations << "\n";
        }
    }
    
    rng::bench::RngBenchmarkSuite::run_comprehensive_benchmark(iterations);
    return 0;
}