#ifndef XOROSHIRO128PP_RNG_BENCH_H
#define XOROSHIRO128PP_RNG_BENCH_H

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <string.h>

// Include the SIMD-optimized xoroshiro128++ implementation
// (Renamed from "simd-xoroshiro128pp.h" to "xoroshiro128pp-simd_main.h")
#include "xoroshiro128pp-simd_main.h"

// For a baseline comparison
static inline uint64_t rotl(const uint64_t x, int k) {
    return (x << k) | (x >> (64 - k));
}

// Original xoroshiro128+ for comparison
typedef struct {
    uint64_t s[2];
} xoroshiro128plus_state;

static inline uint64_t xoroshiro128plus_next(xoroshiro128plus_state *state) {
    const uint64_t s0 = state->s[0];
    uint64_t s1 = state->s[1];
    
    // Calculate output with + scrambler (just add)
    const uint64_t result = s0 + s1;
    
    // Update state
    s1 ^= s0;
    // Use the same rotl function declared above
    state->s[0] = rotl(s0, 24) ^ s1 ^ (s1 << 16);
    state->s[1] = rotl(s1, 37);
    
    return result;
}

static inline void xoroshiro128plus_seed(xoroshiro128plus_state *state, uint64_t seed) {
    // Use SplitMix64 to initialize the state
    uint64_t z = (seed + 0x9e3779b97f4a7c15ULL);
    z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
    z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
    state->s[0] = z ^ (z >> 31);
    
    z = (state->s[0] + 0x9e3779b97f4a7c15ULL);
    z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
    z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
    state->s[1] = z ^ (z >> 31);
}

// Function to measure performance of original xoroshiro128+
double benchmark_original(uint64_t iterations) {
    xoroshiro128plus_state state;
    xoroshiro128plus_seed(&state, 42);
    
    clock_t start = clock();
    
    uint64_t sum = 0;
    for (uint64_t i = 0; i < iterations; i++) {
        sum ^= xoroshiro128plus_next(&state);
    }
    
    clock_t end = clock();
    double time_taken = ((double)(end - start)) / CLOCKS_PER_SEC;
    
    // Prevent compiler from optimizing away the loop
    if (sum == 1) printf("This will never print: %llu\n", (unsigned long long)sum);
    
    return time_taken;
}

// Function to measure performance of SIMD xoroshiro128++
double benchmark_simd(uint64_t iterations) {
    xoroshiro_simd_rng* rng = xoroshiro_simd_new(42);
    
    clock_t start = clock();
    
    uint64_t sum = 0;
    for (uint64_t i = 0; i < iterations; i++) {
        sum ^= xoroshiro_simd_next_u64(rng);
    }
    
    clock_t end = clock();
    double time_taken = ((double)(end - start)) / CLOCKS_PER_SEC;
    
    // Prevent compiler from optimizing away the loop
    if (sum == 1) printf("This will never print: %llu\n", (unsigned long long)sum);
    
    xoroshiro_simd_free(rng);
    return time_taken;
}

// Simple example of how to use the SIMD implementation
void basic_usage_example() {
    printf("Basic Usage Example:\n");
    printf("--------------------\n");
    
    // Create a new RNG with auto-selected SIMD implementation
    xoroshiro_simd_rng* rng = xoroshiro_simd_new(12345);
    
    // Generate some integer values
    printf("First 5 random integers:\n");
    for (int i = 0; i < 5; i++) {
        printf("  %llu\n", (unsigned long long)xoroshiro_simd_next_u64(rng));
    }
    
    // Generate some double values
    printf("\nFirst 5 random doubles [0,1):\n");
    for (int i = 0; i < 5; i++) {
        printf("  %f\n", xoroshiro_simd_next_double(rng));
    }
    
    // Clean up
    xoroshiro_simd_free(rng);
    printf("\n");
}

// Performance comparison between original and SIMD implementations
void performance_comparison() {
  const uint64_t iterations = 100000000; // 100 million iterations
  
  printf("Performance Comparison:\n");
  printf("----------------------\n");
  
  // Detect available SIMD extensions
  printf("Available acceleration: ");
  #ifdef USE_OPENCL
      printf("GPU (OpenCL)\n");
  #elif defined(USE_AVX512)
      printf("AVX-512 (8-way parallelism)\n");
  #elif defined(USE_AVX2)
      printf("AVX2 (4-way parallelism)\n");
  #elif defined(USE_AVX)
      printf("AVX (4-way parallelism)\n");
  #elif defined(USE_NEON)
      printf("NEON (2-way parallelism)\n");
  #elif defined(USE_SSE2)
      printf("SSE2 (2-way parallelism)\n");
  #else
      printf("None (scalar fallback)\n");
  #endif
  
  printf("Generating %llu random numbers with each implementation...\n",
         (unsigned long long)iterations);
  
  // Benchmark original implementation
  double time_original = benchmark_original(iterations);
  printf("Original xoroshiro128+:  %.4f seconds (%.2f M numbers/sec)\n", 
         time_original, iterations / time_original / 1000000.0);
  
  // Benchmark SIMD/GPU implementation
  double time_simd = benchmark_simd(iterations);
  printf("Optimized xoroshiro128++: %.4f seconds (%.2f M numbers/sec)\n", 
         time_simd, iterations / time_simd / 1000000.0);
  
  // Calculate and show speedup
  double speedup = time_original / time_simd;
  printf("Speedup:                %.2fx\n", speedup);
}

int main() {
    // Show basic usage example
    basic_usage_example();
    
    // Run performance comparison
    performance_comparison();
    
    return 0;
}

#endif // XOROSHIRO128PP_RNG_BENCH_H
