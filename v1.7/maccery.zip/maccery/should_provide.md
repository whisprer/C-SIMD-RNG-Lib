dist-macos-universal/

&nbsp; include/ua/ua\_rng.h

&nbsp; lib/libua\_rng.dylib      # universal (arm64+x86\_64)

&nbsp; lib/libua\_rng.a          # universal static

&nbsp; lib/pkgconfig/ua\_rng.pc  # if your CMake generates it



