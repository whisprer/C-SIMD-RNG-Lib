#include <iostream>
#include <memory>
#include <string>
#include <vector>
#include <functional>
#include <chrono>

// Include our modernized benchmark headers
#include "wyrand_rng_bench_modern.h"
#include "xoroshiro128pp_rng_bench_modern.h"

// Modern C++ implementation of main function
int main(int argc, char* argv[]) {
    std::cout << "===================================" << std::endl;
    std::cout << "  Modern RNG Benchmark Comparison  " << std::endl;
    std::cout << "===================================" << std::endl;
    
    // Simple command-line argument parsing
    bool run_wyrand = true;
    bool run_xoroshiro = true;
    
    if (argc > 1) {
        std::string arg(argv[1]);
        if (arg == "wyrand") {
            run_xoroshiro = false;
        } else if (arg == "xoroshiro") {
            run_wyrand = false;
        }
    }
    
    // Use proper RAII and scoping
    {
        auto start_time = std::chrono::high_resolution_clock::now();
        
        if (run_wyrand) {
            bench::WyRandBenchSuite::run();
        }
        
        if (run_xoroshiro) {
            bench::XoroshiroBenchSuite::run();
        }
        
        auto end_time = std::chrono::high_resolution_clock::now();
        std::chrono::duration<double> elapsed = end_time - start_time;
        
        std::cout << "\nTotal benchmark time: " << elapsed.count() << " seconds" << std::endl;
    }
    
    std::cout << "\nBenchmarks completed successfully." << std::endl;
    return 0;
}