#ifndef XOROSHIRO128PP_SIMD_MAIN_H
#define XOROSHIRO128PP_SIMD_MAIN_H

// SIMD-Optimized xoroshiro128++ Implementation
//
// This code implements parallel versions of xoroshiro128++ using
// SIMD instructions for AVX2, AVX-512, and ARM Neon architectures.
//
// Based on the original xoroshiro128+ algorithm by David Blackman and Sebastiano Vigna
// Adapted to use the ++ scrambler for improved statistical properties

#include <stdint.h>
#include <string.h>
#include <stdlib.h>

#ifdef _MSC_VER
#include <intrin.h>
#else
#include <x86intrin.h>
#endif

// Platform detection
#if defined(__AVX512F__) && defined(__AVX512DQ__)
  #define USE_AVX512
#elif defined(__AVX2__)
  #define USE_AVX2
#elif defined(__ARM_NEON)
  #define USE_NEON
  #include <arm_neon.h>
#endif

// Aligned memory allocation
#if defined(_MSC_VER)
#define ALIGN_ALLOC(alignment, size) _aligned_malloc(size, alignment)
#define ALIGN_FREE(ptr) _aligned_free(ptr)
#else
#define ALIGN_ALLOC(alignment, size) aligned_alloc(alignment, size)
#define ALIGN_FREE(ptr) free(ptr)
#endif

// Helper function for scalar rotl
static inline uint64_t rotl(const uint64_t x, int k) {
    return (x << k) | (x >> (64 - k));
}

/////////////////////////////////////////////////////////////////////////////
// Scalar xoroshiro128++ implementation for reference and fallback
/////////////////////////////////////////////////////////////////////////////
typedef struct {
    uint64_t s[2];
} xoroshiro128pp_state;

static inline uint64_t xoroshiro128pp_next(xoroshiro128pp_state *state) {
    const uint64_t s0 = state->s[0];
    uint64_t s1 = state->s[1];
    
    // Calculate output with ++ scrambler (rotate-add)
    const uint64_t result = rotl(s0 + s1, 17) + s0;
    
    // Update state
    s1 ^= s0;
    state->s[0] = rotl(s0, 49) ^ s1 ^ (s1 << 21);
    state->s[1] = rotl(s1, 28);
    
    return result;
}

// Function to initialize a scalar state from a 64-bit seed
static void xoroshiro128pp_seed(xoroshiro128pp_state *state, uint64_t seed) {
    // Use SplitMix64 to initialize the state
    uint64_t z = (seed + 0x9e3779b97f4a7c15ULL);
    z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
    z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
    state->s[0] = z ^ (z >> 31);
    
    z = (state->s[0] + 0x9e3779b97f4a7c15ULL);
    z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
    z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
    state->s[1] = z ^ (z >> 31);
}

/////////////////////////////////////////////////////////////////////////////
// AVX2 implementation (4 parallel streams)
/////////////////////////////////////////////////////////////////////////////
#ifdef USE_AVX2

typedef struct {
    __m256i state0;  // 4 streams, first state component
    __m256i state1;  // 4 streams, second state component
    int aligned;     // Flag to track if we're using aligned memory
} xoroshiro128pp_avx2;

// Helper for AVX2 rotl
static inline __m256i rotl_avx2(__m256i x, int k) {
    return _mm256_or_si256(_mm256_slli_epi64(x, k), _mm256_srli_epi64(x, 64 - k));
}

// Initialize 4 parallel streams with different seeds
static void xoroshiro128pp_avx2_init(xoroshiro128pp_avx2 *state, const uint64_t seeds[4]) {
    // We'll use SplitMix64 to generate the actual initial states
    xoroshiro128pp_state tmp;
    uint64_t *s0_ptr = (uint64_t*)&state->state0;
    uint64_t *s1_ptr = (uint64_t*)&state->state1;
    
    for (int i = 0; i < 4; i++) {
        xoroshiro128pp_seed(&tmp, seeds[i]);
        s0_ptr[i] = tmp.s[0];
        s1_ptr[i] = tmp.s[1];
    }
    
    state->aligned = 1;
}

// Generate 4 random 64-bit values in parallel
static void xoroshiro128pp_avx2_next(xoroshiro128pp_avx2 *state, uint64_t results[4]) {
    // Calculate output - scrambler is: rotl(s0 + s1, 17) + s0
    __m256i sum = _mm256_add_epi64(state->state0, state->state1);
    __m256i rotated_sum = rotl_avx2(sum, 17);
    __m256i result = _mm256_add_epi64(rotated_sum, state->state0);
    
    // Store results
    _mm256_storeu_si256((__m256i*)results, result);
    
    // Update state
    __m256i s1 = _mm256_xor_si256(state->state0, state->state1);
    
    state->state0 = _mm256_xor_si256(
                      rotl_avx2(state->state0, 49),
                      _mm256_xor_si256(
                          s1,
                          _mm256_slli_epi64(s1, 21)
                      )
                    );
                    
    state->state1 = rotl_avx2(s1, 28);
}

// Initialize with a single seed (will create 4 different streams)
static xoroshiro128pp_avx2* xoroshiro128pp_avx2_new(uint64_t seed) {
    xoroshiro128pp_avx2* state = (xoroshiro128pp_avx2*)ALIGN_ALLOC(32, sizeof(xoroshiro128pp_avx2));
    
    // Create 4 different seeds from the master seed
    uint64_t seeds[4];
    xoroshiro128pp_state tmp;
    xoroshiro128pp_seed(&tmp, seed);
    
    seeds[0] = tmp.s[0];
    seeds[1] = tmp.s[1];
    
    xoroshiro128pp_seed(&tmp, seeds[0]);
    seeds[2] = tmp.s[0];
    seeds[3] = tmp.s[1];
    
    xoroshiro128pp_avx2_init(state, seeds);
    return state;
}

static void xoroshiro128pp_avx2_free(xoroshiro128pp_avx2* state) {
    ALIGN_FREE(state);
}

#endif // USE_AVX2

/////////////////////////////////////////////////////////////////////////////
// AVX-512 implementation (8 parallel streams)
/////////////////////////////////////////////////////////////////////////////
#ifdef USE_AVX512

typedef struct {
    __m512i state0;  // 8 streams, first state component
    __m512i state1;  // 8 streams, second state component
    int aligned;     // Flag to track if we're using aligned memory
} xoroshiro128pp_avx512;

// Helper for AVX-512 rotl
static inline __m512i rotl_avx512(__m512i x, int k) {
    return _mm512_or_si512(_mm512_slli_epi64(x, k), _mm512_srli_epi64(x, 64 - k));
}

// Initialize 8 parallel streams with different seeds
static void xoroshiro128pp_avx512_init(xoroshiro128pp_avx512 *state, const uint64_t seeds[8]) {
    // We'll use SplitMix64 to generate the actual initial states
    xoroshiro128pp_state tmp;
    uint64_t *s0_ptr = (uint64_t*)&state->state0;
    uint64_t *s1_ptr = (uint64_t*)&state->state1;
    
    for (int i = 0; i < 8; i++) {
        xoroshiro128pp_seed(&tmp, seeds[i]);
        s0_ptr[i] = tmp.s[0];
        s1_ptr[i] = tmp.s[1];
    }
    
    state->aligned = 1;
}

// Generate 8 random 64-bit values in parallel
static void xoroshiro128pp_avx512_next(xoroshiro128pp_avx512 *state, uint64_t results[8]) {
    // Calculate output - scrambler is: rotl(s0 + s1, 17) + s0
    __m512i sum = _mm512_add_epi64(state->state0, state->state1);
    __m512i rotated_sum = rotl_avx512(sum, 17);
    __m512i result = _mm512_add_epi64(rotated_sum, state->state0);
    
    // Store results
    _mm512_storeu_si512((__m512i*)results, result);
    
    // Update state
    __m512i s1 = _mm512_xor_si512(state->state0, state->state1);
    
    state->state0 = _mm512_xor_si512(
                      rotl_avx512(state->state0, 49),
                      _mm512_xor_si512(
                          s1,
                          _mm512_slli_epi64(s1, 21)
                      )
                    );
                    
    state->state1 = rotl_avx512(s1, 28);
}

// Initialize with a single seed (will create 8 different streams)
static xoroshiro128pp_avx512* xoroshiro128pp_avx512_new(uint64_t seed) {
    xoroshiro128pp_avx512* state = (xoroshiro128pp_avx512*)ALIGN_ALLOC(64, sizeof(xoroshiro128pp_avx512));
    
    // Create 8 different seeds from the master seed
    uint64_t seeds[8];
    xoroshiro128pp_state tmp;
    xoroshiro128pp_seed(&tmp, seed);
    
    // Generate 8 different seeds
    seeds[0] = tmp.s[0];
    seeds[1] = tmp.s[1];
    
    for (int i = 1; i < 4; i++) {
        xoroshiro128pp_next(&tmp);
        seeds[i*2]   = tmp.s[0];
        seeds[i*2+1] = tmp.s[1];
    }
    
    xoroshiro128pp_avx512_init(state, seeds);
    return state;
}

static void xoroshiro128pp_avx512_free(xoroshiro128pp_avx512* state) {
    ALIGN_FREE(state);
}

#endif // USE_AVX512

/////////////////////////////////////////////////////////////////////////////
// ARM Neon implementation (2 parallel streams)
/////////////////////////////////////////////////////////////////////////////
#ifdef USE_NEON

typedef struct {
    uint64x2_t state0;  // 2 streams, first state component
    uint64x2_t state1;  // 2 streams, second state component
    int aligned;        // Flag to track if we're using aligned memory
} xoroshiro128pp_neon;

// Helper for NEON rotl
static inline uint64x2_t rotl_neon(uint64x2_t x, int k) {
    return vsriq_n_u64(vshlq_n_u64(x, k), x, 64 - k);
}

// Initialize 2 parallel streams with different seeds
static void xoroshiro128pp_neon_init(xoroshiro128pp_neon *state, const uint64_t seeds[2]) {
    // We'll use SplitMix64 to generate the actual initial states
    xoroshiro128pp_state tmp;
    uint64_t s0_vals[2];
    uint64_t s1_vals[2];
    
    for (int i = 0; i < 2; i++) {
        xoroshiro128pp_seed(&tmp, seeds[i]);
        s0_vals[i] = tmp.s[0];
        s1_vals[i] = tmp.s[1];
    }
    
    state->state0 = vld1q_u64(s0_vals);
    state->state1 = vld1q_u64(s1_vals);
    state->aligned = 1;
}

// Generate 2 random 64-bit values in parallel
static void xoroshiro128pp_neon_next(xoroshiro128pp_neon *state, uint64_t results[2]) {
    // Calculate output - scrambler is: rotl(s0 + s1, 17) + s0
    uint64x2_t sum = vaddq_u64(state->state0, state->state1);
    uint64x2_t rotated_sum = rotl_neon(sum, 17);
    uint64x2_t result = vaddq_u64(rotated_sum, state->state0);
    
    // Store results
    vst1q_u64(results, result);
    
    // Update state
    uint64x2_t s1 = veorq_u64(state->state0, state->state1);
    
    state->state0 = veorq_u64(
                      rotl_neon(state->state0, 49),
                      veorq_u64(
                          s1,
                          vshlq_n_u64(s1, 21)
                      )
                    );
                    
    state->state1 = rotl_neon(s1, 28);
}

// Initialize with a single seed (will create 2 different streams)
static xoroshiro128pp_neon* xoroshiro128pp_neon_new(uint64_t seed) {
    xoroshiro128pp_neon* state = (xoroshiro128pp_neon*)ALIGN_ALLOC(16, sizeof(xoroshiro128pp_neon));
    
    // Create 2 different seeds from the master seed
    uint64_t seeds[2];
    xoroshiro128pp_state tmp;
    xoroshiro128pp_seed(&tmp, seed);
    
    seeds[0] = tmp.s[0];
    seeds[1] = tmp.s[1];
    
    xoroshiro128pp_neon_init(state, seeds);
    return state;
}

static void xoroshiro128pp_neon_free(xoroshiro128pp_neon* state) {
    ALIGN_FREE(state);
}

#endif // USE_NEON

/////////////////////////////////////////////////////////////////////////////
// Universal wrapper API
/////////////////////////////////////////////////////////////////////////////

#if defined(USE_AVX512)
    #define XORO_PARALLEL_STREAMS 8
#elif defined(USE_AVX2)
    #define XORO_PARALLEL_STREAMS 4
#elif defined(USE_NEON)
    #define XORO_PARALLEL_STREAMS 2
#else
    #define XORO_PARALLEL_STREAMS 1
#endif

typedef struct {
    void* state;
    int type;         // 0 = scalar, 1 = AVX2, 2 = AVX512, 3 = NEON
    int buffer_pos;   // Position in the current buffer
    uint64_t buffer[XORO_PARALLEL_STREAMS]; // Buffer for random values
} xoroshiro_simd_rng;

// Create a new RNG state with the best available SIMD implementation
xoroshiro_simd_rng* xoroshiro_simd_new(uint64_t seed) {
    xoroshiro_simd_rng* rng = (xoroshiro_simd_rng*)malloc(sizeof(xoroshiro_simd_rng));
    rng->buffer_pos = XORO_PARALLEL_STREAMS; // Force buffer refill on first call
    
    #if defined(USE_AVX512)
        rng->state = xoroshiro128pp_avx512_new(seed);
        rng->type = 2;
    #elif defined(USE_AVX2)
        rng->state = xoroshiro128pp_avx2_new(seed);
        rng->type = 1;
    #elif defined(USE_NEON)
        rng->state = xoroshiro128pp_neon_new(seed);
        rng->type = 3;
    #else
        rng->state = malloc(sizeof(xoroshiro128pp_state));
        xoroshiro128pp_seed((xoroshiro128pp_state*)rng->state, seed);
        rng->type = 0;
    #endif
    
    return rng;
}

// Free RNG state
void xoroshiro_simd_free(xoroshiro_simd_rng* rng) {
    if (rng) {
        #if defined(USE_AVX512)
            if (rng->type == 2) {
                xoroshiro128pp_avx512_free((xoroshiro128pp_avx512*)rng->state);
            }
        #endif
        #if defined(USE_AVX2)
            if (rng->type == 1) {
                xoroshiro128pp_avx2_free((xoroshiro128pp_avx2*)rng->state);
            }
        #endif
        #if defined(USE_NEON)
            if (rng->type == 3) {
                xoroshiro128pp_neon_free((xoroshiro128pp_neon*)rng->state);
            }
        #endif
        if (rng->type == 0) {
            free(rng->state);
        }
        free(rng);
    }
}

// Get next 64-bit random value
uint64_t xoroshiro_simd_next_u64(xoroshiro_simd_rng* rng) {
    // If we've used all values in the buffer, generate a new batch
    if (rng->buffer_pos >= XORO_PARALLEL_STREAMS) {
        #if defined(USE_AVX512)
            if (rng->type == 2) {
                xoroshiro128pp_avx512_next((xoroshiro128pp_avx512*)rng->state, rng->buffer);
            }
        #endif
        #if defined(USE_AVX2)
            if (rng->type == 1) {
                xoroshiro128pp_avx2_next((xoroshiro128pp_avx2*)rng->state, rng->buffer);
            }
        #endif
        #if defined(USE_NEON)
            if (rng->type == 3) {
                xoroshiro128pp_neon_next((xoroshiro128pp_neon*)rng->state, rng->buffer);
            }
        #endif
        if (rng->type == 0) {
            rng->buffer[0] = xoroshiro128pp_next((xoroshiro128pp_state*)rng->state);
        }
        rng->buffer_pos = 0;
    }
    
    // Return the next value from the buffer
    return rng->buffer[rng->buffer_pos++];
}

// Get random double in [0, 1) range
double xoroshiro_simd_next_double(xoroshiro_simd_rng* rng) {
    // Convert to double in [0,1) using the high 53 bits
    const uint64_t value = xoroshiro_simd_next_u64(rng);
    return (value >> 11) * (1.0 / (1ULL << 53));
}

// Jump ahead equivalent to 2^64 calls to next()
// Used for creating multiple independent streams
void xoroshiro_simd_jump(xoroshiro_simd_rng* rng) {
    // We can only jump the scalar version currently
    if (rng->type != 0) {
        // For SIMD versions, we need to extract states, jump them,
        // and then put them back. This is complex, so we'll only 
        // implement the scalar version for simplicity.
        return;
    }
    
    static const uint64_t JUMP[] = { 0xdf900294d8f554a5, 0x170865df4b3201fc };
    xoroshiro128pp_state* state = (xoroshiro128pp_state*)rng->state;
    
    uint64_t s0 = 0;
    uint64_t s1 = 0;
    for (int i = 0; i < (int)(sizeof JUMP / sizeof *JUMP); i++) {
        for (int b = 0; b < 64; b++) {
            if (JUMP[i] & (1ULL << b)) {
                s0 ^= state->s[0];
                s1 ^= state->s[1];
            }
            xoroshiro128pp_next(state);
        }
    }
    
    state->s[0] = s0;
    state->s[1] = s1;
}

#endif // XOROSHIRO128PP_SIMD_MAIN_H
