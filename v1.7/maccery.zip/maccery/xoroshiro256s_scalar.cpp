// D:/code/Universal-Architecture-RNG-Lib/v1.7/src/xoshiro256ss_scalar.cpp
#include "ua/ua_xoshiro256ss_scalar.h"
// Intentionally minimal TU to give CMake a concrete source file.
