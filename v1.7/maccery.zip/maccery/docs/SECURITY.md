# Security Policy

## Supported Versions

Use this section to tell people about which versions of your project are
currently being supported with security updates.

| Version | Supported          |
| ------- | ------------------ |
| 0.1.5   | :white_check_mark: |
| 0.1.4   | :x nonrelease-fail:|
| 0.1.3   | :white_check_mark: |
| < 1.2   | :x: never released |

## Reporting a Vulnerability

No current known ulnerabilities in release verison although this has yet to be
thoroughly investigated with tools that would really reveal any problems that
might be reuly worrying. it's o the todo list, anyone else fancies doing some
pentesting, be my guest!
