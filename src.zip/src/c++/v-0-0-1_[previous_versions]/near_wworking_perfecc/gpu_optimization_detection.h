// gpu_optimization_detection.h
#ifndef GPU_OPTIMIZATION_DETECTION_H
#define GPU_OPTIMIZATION_DETECTION_H

#include <CL/cl.h>

// GPU Device Capabilities Structure
typedef struct {
    // Basic Device Info
    char device_name[256];
    char vendor[128];
    
    // Computational Capabilities
    cl_ulong global_mem_size;     // Total global memory
    cl_ulong max_mem_alloc_size;  // Maximum memory allocation
    cl_uint max_compute_units;    // Number of compute units
    cl_ulong max_work_group_size; // Maximum work group size
    
    // Advanced Features
    cl_bool supports_double_precision;
    cl_bool supports_local_memory;
    cl_bool supports_unified_memory;
    
    // Performance Characteristics
    cl_ulong max_clock_frequency;
    
    // Multi-GPU Configuration
    cl_bool supports_multi_gpu;
    cl_uint num_available_devices;
} GPUDeviceCapabilities;

// Function to detect and log GPU capabilities
int detect_gpu_capabilities(GPUDeviceCapabilities* capabilities) {
    cl_platform_id platforms[10];
    cl_uint num_platforms;
    cl_int err;

    // Initialize capabilities
    memset(capabilities, 0, sizeof(GPUDeviceCapabilities));

    // Get platforms
    err = clGetPlatformIDs(10, platforms, &num_platforms);
    if (err != CL_SUCCESS || num_platforms == 0) {
        fprintf(stderr, "No OpenCL platforms found\n");
        return -1;
    }

    // Iterate through platforms to find GPUs
    for (cl_uint p = 0; p < num_platforms; p++) {
        char platform_vendor[128];
        clGetPlatformInfo(platforms[p], CL_PLATFORM_VENDOR, 
                          sizeof(platform_vendor), platform_vendor, NULL);

        cl_device_id devices[10];
        cl_uint num_devices;
        err = clGetDeviceIDs(platforms[p], CL_DEVICE_TYPE_GPU, 
                             10, devices, &num_devices);

        if (err == CL_SUCCESS && num_devices > 0) {
            // Use first GPU device
            cl_device_id device = devices[0];
            
            // Device Name
            clGetDeviceInfo(device, CL_DEVICE_NAME, 
                            sizeof(capabilities->device_name), 
                            capabilities->device_name, NULL);
            
            // Vendor
            clGetDeviceInfo(device, CL_DEVICE_VENDOR, 
                            sizeof(capabilities->vendor), 
                            capabilities->vendor, NULL);
            
            // Global Memory Size
            clGetDeviceInfo(device, CL_DEVICE_GLOBAL_MEM_SIZE, 
                            sizeof(capabilities->global_mem_size), 
                            &capabilities->global_mem_size, NULL);
            
            // Maximum Memory Allocation Size
            clGetDeviceInfo(device, CL_DEVICE_MAX_MEM_ALLOC_SIZE, 
                            sizeof(capabilities->max_mem_alloc_size), 
                            &capabilities->max_mem_alloc_size, NULL);
            
            // Compute Units
            clGetDeviceInfo(device, CL_DEVICE_MAX_COMPUTE_UNITS, 
                            sizeof(capabilities->max_compute_units), 
                            &capabilities->max_compute_units, NULL);
            
            // Maximum Work Group Size
            clGetDeviceInfo(device, CL_DEVICE_MAX_WORK_GROUP_SIZE, 
                            sizeof(capabilities->max_work_group_size), 
                            &capabilities->max_work_group_size, NULL);
            
            // Double Precision Support
            cl_device_fp_config fp_config;
            clGetDeviceInfo(device, CL_DEVICE_DOUBLE_FP_CONFIG, 
                            sizeof(fp_config), &fp_config, NULL);
            capabilities->supports_double_precision = 
                fp_config != 0;
            
            // Clock Frequency
            clGetDeviceInfo(device, CL_DEVICE_MAX_CLOCK_FREQUENCY, 
                            sizeof(capabilities->max_clock_frequency), 
                            &capabilities->max_clock_frequency, NULL);
            
            // Number of Devices
            capabilities->num_available_devices = num_devices;
            
            return 0;  // Successfully detected
        }
    }

    fprintf(stderr, "No GPU devices found\n");
    return -1;
}

// Optimization recommendation based on capabilities
void recommend_gpu_optimizations(GPUDeviceCapabilities* capabilities) {
    printf("GPU Optimization Recommendations:\n");
    printf("--------------------------------\n");
    
    printf("Device: %s (Vendor: %s)\n", 
           capabilities->device_name, 
           capabilities->vendor);
    
    printf("\nCompute Capabilities:\n");
    printf("- Compute Units:     %u\n", capabilities->max_compute_units);
    printf("- Max Work Group:    %lu\n", capabilities->max_work_group_size);
    printf("- Clock Frequency:   %lu MHz\n", capabilities->max_clock_frequency);
    
    printf("\nMemory Characteristics:\n");
    printf("- Global Memory:     %.2f GB\n", 
           capabilities->global_mem_size / (1024.0 * 1024.0 * 1024.0));
    printf("- Max Allocation:    %.2f GB\n", 
           capabilities->max_mem_alloc_size / (1024.0 * 1024.0 * 1024.0));
    
    printf("\nFeature Support:\n");
    printf("- Double Precision: %s\n", 
           capabilities->supports_double_precision ? "Yes" : "No");
    
    // Provide specific optimization hints
    if (capabilities->max_compute_units > 8) {
        printf("\nRecommendation: High parallelism detected. "
               "Consider increasing batch size for better GPU utilization.\n");
    }
    
    if (capabilities->global_mem_size > (16ULL * 1024 * 1024 * 1024)) {
        printf("\nRecommendation: Large GPU memory. "
               "Explore more memory-intensive random number generation techniques.\n");
    }
}

#endif // GPU_OPTIMIZATION_DETECTION_H
