#ifndef UNIVERSAL_RNG_H
#define UNIVERSAL_RNG_H

#include <memory>
#include <cstdint>
#include <vector>
#include <string>
#include <random>

#include "xoroshiro128pp_simd_main_optimized.h"
#include "wyrand_rng_bench_optimized.h"
#include "verbose_mode.h"

namespace rng {

// Universal RNG class that can use any implementation
class UniversalRng {
public:
    // Constructor with algorithm selection
    UniversalRng(RngAlgorithmType algorithm_type = RNG_ALGORITHM_XOROSHIRO,
                 RngPrecisionMode precision_mode = RNG_PRECISION_DOUBLE,
                 uint64_t seed = 0) 
        : algorithm_type_(algorithm_type),
          precision_mode_(precision_mode),
          seed_(seed ? seed : static_cast<uint64_t>(std::random_device{}()))
    {
        initialize();
    }
    
    // Rule of 5 implementation
    ~UniversalRng() = default;
    
    UniversalRng(const UniversalRng&) = delete;
    UniversalRng& operator=(const UniversalRng&) = delete;
    
    UniversalRng(UniversalRng&&) noexcept = default;
    UniversalRng& operator=(UniversalRng&&) noexcept = default;
    
    // Core random generation methods
    uint64_t next_u64() {
        switch (algorithm_type_) {
            case RNG_ALGORITHM_XOROSHIRO:
                return xoroshiro_rng_->next_u64();
            case RNG_ALGORITHM_WYRAND:
                return wyrand_rng_->next_u64();
            default:
                // Fallback to xoroshiro
                return xoroshiro_rng_->next_u64();
        }
    }
    
    double next_double() {
        if (precision_mode_ == RNG_PRECISION_DOUBLE) {
            switch (algorithm_type_) {
                case RNG_ALGORITHM_XOROSHIRO:
                    return xoroshiro_rng_->next_double();
                case RNG_ALGORITHM_WYRAND:
                    return wyrand_rng_->next_double();
                default:
                    // Fallback to xoroshiro
                    return xoroshiro_rng_->next_double();
            }
        } else {
            // For single precision mode, convert float to double
            return static_cast<double>(next_float());
        }
    }
    
    float next_float() {
        switch (algorithm_type_) {
            case RNG_ALGORITHM_XOROSHIRO:
                return xoroshiro_rng_->next_float();
            case RNG_ALGORITHM_WYRAND:
                return wyrand_rng_->next_float();
            default:
                // Fallback to xoroshiro
                return xoroshiro_rng_->next_float();
        }
    }
    
    // Fill an array with random values
    template<typename Container>
    void fill(Container& container) {
        for (auto& val : container) {
            using T = typename std::remove_reference<decltype(val)>::type;
            
            if constexpr (std::is_same_v<T, uint64_t>) {
                val = next_u64();
            } else if constexpr (std::is_same_v<T, double>) {
                val = next_double();
            } else if constexpr (std::is_same_v<T, float>) {
                val = next_float();
            } else if constexpr (std::is_integral_v<T>) {
                val = static_cast<T>(next_u64() % (std::numeric_limits<T>::max() + 1ULL));
            } else {
                static_assert(std::is_convertible_v<double, T>, "Unsupported type for fill");
                val = static_cast<T>(next_double());
            }
        }
    }
    
    // Get info about the RNG
    RngImplType get_implementation_type() const {
        if (algorithm_type_ == RNG_ALGORITHM_XOROSHIRO) {
            return xoroshiro_rng_->get_implementation_type();
        } else {
            return RNG_IMPL_SCALAR; // WyRand is always scalar for now
        }
    }
    
    // Get current algorithm type
    RngAlgorithmType get_algorithm_type() const {
        return algorithm_type_;
    }
    
    // Get current precision mode
    RngPrecisionMode get_precision_mode() const {
        return precision_mode_;
    }
    
private:
    RngAlgorithmType algorithm_type_;
    RngPrecisionMode precision_mode_;
    uint64_t seed_;
    
    // RNG implementations
    std::unique_ptr<Xoroshiro128pp> xoroshiro_rng_;
    std::unique_ptr<wyrand::WyRand> wyrand_rng_;
    
    // Initialize the appropriate RNG
    void initialize() {
        if (algorithm_type_ == RNG_ALGORITHM_XOROSHIRO || algorithm_type_ > RNG_ALGORITHM_WYRAND) {
            xoroshiro_rng_ = std::make_unique<Xoroshiro128pp>(seed_);
        }
        
        if (algorithm_type_ == RNG_ALGORITHM_WYRAND) {
            wyrand_rng_ = std::make_unique<wyrand::WyRand>(seed_);
        }
        
        // Log initialization if verbose mode is enabled
        verbose::VerboseMode::instance().log("Initialized Universal RNG:\n");
        verbose::VerboseMode::instance().log("- Algorithm: %s\n", 
            verbose::VerboseMode::algorithm_type_to_string(algorithm_type_).c_str());
        verbose::VerboseMode::instance().log("- Precision: %s\n", 
            verbose::VerboseMode::precision_mode_to_string(precision_mode_).c_str());
        verbose::VerboseMode::instance().log("- Implementation: %s\n", 
            verbose::VerboseMode::impl_type_to_string(get_implementation_type()).c_str());
    }
};

} // namespace rng

// C-compatible API for backward compatibility
extern "C" {

// Helper to convert C++ implementation to C struct
universal_rng_t* universal_rng_new(RngAlgorithmType algorithm_type, 
                                RngPrecisionMode precision_mode, 
                                uint64_t seed) {
    auto* rng = new universal_rng_t;
    rng->algorithm_type = algorithm_type;
    rng->precision_mode = precision_mode;
    
    try {
        auto cpp_rng = std::make_shared<rng::UniversalRng>(algorithm_type, precision_mode, seed);
        rng->implementation_type = cpp_rng->get_implementation_type();
        
        if (algorithm_type == RNG_ALGORITHM_XOROSHIRO) {
            // For xoroshiro, we need to create a RandomGenerator implementation
            auto xoroshiro_rng = std::make_shared<rng::Xoroshiro128pp>(seed);
            rng->impl = xoroshiro_rng->impl_;
        } else {
            // For other algorithms, we create a wrapper RandomGenerator
            class WyRandWrapper : public rng::RandomGenerator {
            public:
                explicit WyRandWrapper(uint64_t seed) : wy_rng_(seed) {}
                
                uint64_t next_u64() override { return wy_rng_.next_u64(); }
                double next_double() override { return wy_rng_.next_double(); }
                float next_float() override { return wy_rng_.next_float(); }
                void jump() override { /* WyRand doesn't support jump */ }
                void long_jump() override { /* WyRand doesn't support long jump */ }
                
                RngImplType get_implementation_type() const override {
                    return RNG_IMPL_SCALAR;
                }
                
            private:
                rng::wyrand::WyRand wy_rng_;
            };
            
            rng->impl = std::make_shared<WyRandWrapper>(seed);
        }
        
        // Log initialization if verbose mode is enabled
        log_rng_initialization(rng);
        
        return rng;
    } catch (...) {
        delete rng;
        return nullptr;
    }
}

void universal_rng_free(universal_rng_t* rng) {
    if (rng) {
        rng->impl.reset();
        delete rng;
    }
}

uint64_t universal_rng_next_u64(universal_rng_t* rng) {
    return rng->impl->next_u64();
}

double universal_rng_next_double(universal_rng_t* rng) {
    return rng->impl->next_double();
}

float universal_rng_next_float(universal_rng_t* rng) {
    return rng->impl->next_float();
}

} // extern "C"

#endif // UNIVERSAL_RNG_H