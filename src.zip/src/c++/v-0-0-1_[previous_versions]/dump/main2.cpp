#include <iostream>
#include <vector>
#include <memory>
#include <chrono>
#include <iomanip>
#include <string>
#include <functional>

#include "xoroshiro128pp_simd_main_optimized.h"
#include "wyrand_rng_bench_optimized.h"
#include "xoroshiro128pp_rng_bench_optimized.h"
#include "verbose_mode.h"
#include "universal_rng.h"

// Helper for comparing different RNG implementations
void compare_all_implementations() {
    constexpr uint64_t NUM_ITERATIONS = 10000000; // 10 million
    
    std::cout << "=================================================" << std::endl;
    std::cout << "Comparing all RNG implementations with " 
              << NUM_ITERATIONS << " iterations" << std::endl;
    std::cout << "=================================================" << std::endl;
    
    // Create a vector to store all timing results
    struct BenchResult {
        std::string name;
        double time_seconds;
        double throughput;
    };
    std::vector<BenchResult> results;
    
    // Lambda to run and time a benchmark function
    auto run_benchmark = [NUM_ITERATIONS](const std::string& name, std::function<uint64_t()> generator) {
        auto start = std::chrono::high_resolution_clock::now();
        uint64_t sum = 0;
        
        for (uint64_t i = 0; i < NUM_ITERATIONS; ++i) {
            sum ^= generator();
        }
        
        auto end = std::chrono::high_resolution_clock::now();
        std::chrono::duration<double> duration = end - start;
        
        // Prevent optimization
        if (sum == 1) {
            std::cout << "No-opt: " << sum << std::endl;
        }
        
        BenchResult result;
        result.name = name;
        result.time_seconds = duration.count();
        result.throughput = NUM_ITERATIONS / duration.count() / 1e6; // M/s
        
        return result;
    };
    
    // 1. Benchmark Xoroshiro128++ (Modern C++ implementation)
    {
        rng::Xoroshiro128pp rng(42);
        results.push_back(run_benchmark("Xoroshiro128++ (C++)", [&rng]() {
            return rng.next_u64();
        }));
    }
    
    // 2. Benchmark Xoroshiro128++ (C API)
    {
        auto rng = std::unique_ptr<xorshiro128pp_simd_rng, decltype(&xorshiro128pp_simd_free)>(
            xorshiro128pp_simd_new(42), xorshiro128pp_simd_free);
        
        results.push_back(run_benchmark("Xoroshiro128++ (C API)", [&rng]() {
            return xorshiro128pp_simd_next_u64(rng.get());
        }));
    }
    
    // 3. Benchmark WyRand (Modern C++ implementation)
    {
        rng::wyrand::WyRand rng(42);
        results.push_back(run_benchmark("WyRand (C++)", [&rng]() {
            return rng.next_u64();
        }));
    }
    
    // 4. Benchmark WyRand (C API)
    {
        auto rng = std::unique_ptr<wyrand_rng, decltype(&wyrand_free)>(
            wyrand_new(42), wyrand_free);
        
        results.push_back(run_benchmark("WyRand (C API)", [&rng]() {
            return wyrand_next_u64(rng.get());
        }));
    }
    
    // 5. Benchmark Universal RNG with Xoroshiro
    {
        rng::UniversalRng rng(RNG_ALGORITHM_XOROSHIRO, RNG_PRECISION_DOUBLE, 42);
        results.push_back(run_benchmark("Universal RNG (Xoroshiro)", [&rng]() {
            return rng.next_u64();
        }));
    }
    
    // 6. Benchmark Universal RNG with WyRand
    {
        rng::UniversalRng rng(RNG_ALGORITHM_WYRAND, RNG_PRECISION_DOUBLE, 42);
        results.push_back(run_benchmark("Universal RNG (WyRand)", [&rng]() {
            return rng.next_u64();
        }));
    }
    
    // 7. Benchmark std::mt19937_64 (for comparison)
    {
        std::mt19937_64 rng(42);
        results.push_back(run_benchmark("std::mt19937_64", [&rng]() {
            return rng();
        }));
    }
    
    // Print results table
    std::cout << "\nRESULTS:\n" << std::endl;
    std::cout << std::left << std::setw(30) << "Implementation" 
              << std::right << std::setw(12) << "Time (s)" 
              << std::setw(15) << "Speed (M/s)" << std::setw(10) << "Relative" << std::endl;
    std::cout << std::string(67, '-') << std::endl;
    
    // Find fastest implementation for relative comparison
    auto fastest = std::max_element(results.begin(), results.end(),
        [](const BenchResult& a, const BenchResult& b) {
            return a.throughput < b.throughput;
        });
    
    // Print table rows
    for (const auto& result : results) {
        std::cout << std::left << std::setw(30) << result.name 
                  << std::fixed << std::setprecision(4) << std::right << std::setw(12) << result.time_seconds 
                  << std::fixed << std::setprecision(2) << std::setw(15) << result.throughput
                  << std::setw(10) << result.throughput / fastest->throughput << "x" << std::endl;
    }
    std::cout << std::string(67, '-') << std::endl;
}

// Demonstrate filling arrays and vectors with random numbers
void demonstrate_container_filling() {
    rng::Xoroshiro128pp rng(12345);
    
    std::cout << "\n=================================================" << std::endl;
    std::cout << "Demonstrating container filling with random values" << std::endl;
    std::cout << "=================================================" << std::endl;
    
    // Fill a std::array with random doubles
    std::array<double, 5> random_doubles;
    rng.fill_array(random_doubles);
    
    std::cout << "Random doubles from array:" << std::endl;
    for (auto val : random_doubles) {
        std::cout << "  " << std::fixed << std::setprecision(6) << val << std::endl;
    }
    
    // Fill a std::vector with random integers
    std::vector<int> random_ints(5);
    for (auto& val : random_ints) {
        val = static_cast<int>(rng.next_u64() % 100);
    }
    
    std::cout << "\nRandom integers from vector:" << std::endl;
    for (auto val : random_ints) {
        std::cout << "  " << val << std::endl;
    }
    
    // Using UniversalRng with a vector
    rng::UniversalRng universal_rng(RNG_ALGORITHM_XOROSHIRO);
    std::vector<uint64_t> big_numbers(5);
    universal_rng.fill(big_numbers);
    
    std::cout << "\nRandom uint64_t values from UniversalRng:" << std::endl;
    for (auto val : big_numbers) {
        std::cout << "  " << val << std::endl;
    }
}

int main(int argc, char* argv[]) {
    // Enable verbose mode if requested
    if (argc > 1 && std::string(argv[1]) == "--verbose") {
        enable_verbose_mode();
    }
    
    std::cout << "======================================" << std::endl;
    std::cout << "Modern C++ RNG Implementations Demo" << std::endl;
    std::cout << "======================================" << std::endl;
    
    // Run original benchmark functions for backward compatibility
    run_xoroshiro_non_bench();
    run_wyrand_bench();
    
    // Run new demonstrations
    compare_all_implementations();
    demonstrate_container_filling();
    
    return 0;
}