// xoroshiro_test.cpp
#include <stdio.h>
#include "xoroshiro128pp_rng_bench.h"

int main() {
    printf("=== Xoroshiro128++ Benchmark (Non-Optimized) ===\n\n");
    run_xoroshiro_non_bench();
    return 0;
}