#ifndef ADVANCED_BENCHMARKING_H
#define ADVANCED_BENCHMARKING_H

#include "universal_rng.h"
#include <memory>
#include <vector>
#include <string>
#include <iostream>
#include <fstream>
#include <iomanip>
#include <chrono>

// High-precision timer for nanosecond-level measurements
#ifdef _WIN32
    #include <windows.h>
#elif defined(__APPLE__)
    #include <mach/mach_time.h>
#else
    #include <time.h>
#endif

// Enhanced BenchmarkResult with smart pointer management and RAII
class BenchmarkResult {
public:
    // Constructor
    BenchmarkResult(
        size_t num_iterations, 
        int algorithm_type, 
        int precision_mode
    ) : 
        num_iterations_(num_iterations),
        algorithm_type_(algorithm_type),
        precision_mode_(precision_mode) {}

    // Static factory method
    static std::unique_ptr<BenchmarkResult> create(
        size_t num_iterations, 
        int algorithm_type, 
        int precision_mode
    ) {
        return std::make_unique<BenchmarkResult>(
            num_iterations, 
            algorithm_type, 
            precision_mode
        );
    }

    // High-precision timer implementation
    static uint64_t get_nanosecond_timestamp() {
    #ifdef _WIN32
        LARGE_INTEGER frequency, timestamp;
        QueryPerformanceFrequency(&frequency);
        QueryPerformanceCounter(&timestamp);
        return (timestamp.QuadPart * 1000000000ULL) / frequency.QuadPart;
    #elif defined(__APPLE__)
        static mach_timebase_info_data_t timebase;
        static int initialized = 0;
        if (!initialized) {
            mach_timebase_info(&timebase);
            initialized = 1;
        }
        uint64_t timestamp = mach_absolute_time();
        return (timestamp * timebase.numer) / timebase.denom;
    #else
        struct timespec ts;
        clock_gettime(CLOCK_MONOTONIC, &ts);
        return ts.tv_sec * 1000000000ULL + ts.tv_nsec;
    #endif
    }

    // Perform benchmark
    bool run(const BenchmarkResult* previous_result = nullptr) {
        // Create RNG with smart pointer
        auto rng = universal_rng_new(
            std::chrono::system_clock::now().time_since_epoch().count(),
            static_cast<RNGAlgorithmType>(algorithm_type_),
            static_cast<RNGPrecisionMode>(precision_mode_)
        );

        if (!rng) {
            std::cerr << "Failed to create RNG for benchmarking\n";
            return false;
        }

        // Use vector instead of raw pointer
        std::vector<uint64_t> results(num_iterations_);
        
        // High-precision timing
        uint64_t start_time = get_nanosecond_timestamp();
        
        // Batch generation
        universal_rng_next_batch(rng.get(), results.data(), num_iterations_);
        
        // Calculate timing
        uint64_t end_time = get_nanosecond_timestamp();
        total_time_ns_ = end_time - start_time;
        generation_rate_ = static_cast<double>(num_iterations_) / 
            (total_time_ns_ / 1000000000.0);
        
        // Capture implementation type
        implementation_type_ = rng->impl_type;
        
        // Compare with previous if provided
        if (previous_result) {
            previous_time_ns_ = previous_result->total_time_ns_;
            performance_delta_ = 
                ((double)total_time_ns_ - previous_result->total_time_ns_) / 
                previous_result->total_time_ns_ * 100.0;
        }

        // Capture sample data
        for (int i = 0; i < 5 && i < num_iterations_; ++i) {
            last_integers_[i] = results[i];
            last_doubles_[i] = static_cast<double>(results[i]) / 
                std::numeric_limits<uint64_t>::max();
        }

        return true;
    }

    // Export to CSV
    bool export_to_csv(const std::string& filename) const {
        std::ofstream csv_file(filename);
        if (!csv_file) {
            std::cerr << "Failed to open CSV file for writing\n";
            return false;
        }
        
        // Write CSV header
        csv_file << "Iterations,Algorithm,Precision,Implementation,"
                 << "Total Time (ns),Generation Rate (numbers/sec),"
                 << "Previous Time (ns),Performance Delta (%)\n";
        
        // Write benchmark results
        csv_file << num_iterations_ << ","
                 << algorithm_type_ << ","
                 << precision_mode_ << ","
                 << implementation_type_ << ","
                 << total_time_ns_ << ","
                 << generation_rate_ << ","
                 << previous_time_ns_ << ","
                 << performance_delta_ << "\n";
        
        // Write sample data
        csv_file << "\nLast 5 Integers:\n";
        for (int i = 0; i < 5; i++) {
            csv_file << last_integers_[i] << "\n";
        }
        
        csv_file << "\nLast 5 Doubles:\n";
        for (int i = 0; i < 5; i++) {
            csv_file << std::fixed << std::setprecision(6) 
                     << last_doubles_[i] << "\n";
        }
        
        return true;
    }

    // Getters
    uint64_t get_total_time_ns() const { return total_time_ns_; }
    double get_generation_rate() const { return generation_rate_; }
    double get_performance_delta() const { return performance_delta_; }

private:
    // Timing information
    uint64_t total_time_ns_ = 0;
    double generation_rate_ = 0.0;
    
    // Comparison metrics
    uint64_t previous_time_ns_ = 0;
    double performance_delta_ = 0.0;
    
    // Randomness preview
    std::array<uint64_t, 5> last_integers_ = {};
    std::array<double, 5> last_doubles_ = {};
    
    // Configuration details
    size_t num_iterations_ = 0;
    int algorithm_type_ = 0;
    int precision_mode_ = 0;
    int implementation_type_ = 0;
};

#endif // ADVANCED_BENCHMARKING_H
