#ifndef WYRAND_RNG_BENCH_H
#define WYRAND_RNG_BENCH_H

#include "rng_common.h"
#include "wyrand.h"
#include <iostream>
#include <iomanip>
#include <memory>

namespace rng {
namespace bench {

class WyRandBench {
public:
    // Basic usage example
    static void basic_usage_example() {
        std::cout << "Basic Usage with WyRand:\n";
        std::cout << "--------------------------------------\n";

        auto rng = std::make_unique<rng::WyRandSimd>(12345ULL);

        std::cout << "First 5 random integers:\n";
        for(int i=0; i<5; i++) {
            std::cout << "  " << rng->next_u64() << "\n";
        }
        
        std::cout << "\nFirst 5 random doubles [0,1):\n";
        for(int i=0; i<5; i++) {
            std::cout << "  " << std::fixed << std::setprecision(6) << rng->next_double() << "\n";
        }
        
        std::cout << "\n";
    }

    // Performance comparison
    static void performance_comparison() {
        constexpr uint64_t iters = 100000000ULL; // 100 million
        
        std::cout << "Performance Comparison:\n";
        std::cout << "-----------------------\n";
        std::cout << "Generating " << iters << " numbers in each generator...\n";

        // Print SIMD support
        rng::print_simd_support();

        // Benchmark original xoroshiro128+
        Xoroshiro128Plus xoro_plus(42);
        double t1 = rng::benchmark_generator(iters, xoro_plus, 
            [](Xoroshiro128Plus& rng) { return rng.next_u64(); });

        // Benchmark WyRand
        WyRandSimd wyrand(42);
        double t2 = rng::benchmark_generator(iters, wyrand,
            [](WyRandSimd& rng) { return rng.next_u64(); });

        std::cout << "xoroshiro128+ time:  " << std::fixed << std::setprecision(4) << t1 
                  << " s (" << std::fixed << std::setprecision(2) << (iters/t1)/1e6 << " M/s)\n";
        
        std::cout << "WyRand Simd time:    " << std::fixed << std::setprecision(4) << t2
                  << " s (" << std::fixed << std::setprecision(2) << (iters/t2)/1e6 << " M/s)\n";
        
        std::cout << "Speedup: " << std::fixed << std::setprecision(2) << t1/t2 << "x\n";
    }

    // Main function to run the benchmark
    static void run() {
        std::cout << "\n=== WYRAND BENCH ===\n\n";
        basic_usage_example();
        performance_comparison();
    }
};

} // namespace bench
} // namespace rng

// C-style function for backwards compatibility
inline void run_wyrand_bench() {
    rng::bench::WyRandBench::run();
}

#endif // WYRAND_RNG_BENCH_H