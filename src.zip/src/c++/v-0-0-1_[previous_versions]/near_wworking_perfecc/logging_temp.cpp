typedef enum {
    LOG_DEBUG,
    LOG_INFO,
    LOG_WARNING,
    LOG_ERROR,
    LOG_CRITICAL
} LogLevel;

void log_message(LogLevel level, const char* format, ...) {
    va_list args;
    va_start(args, format);
    
    // Prefix log messages with level
    const char* level_strings[] = {
        "[DEBUG]   ", 
        "[INFO]    ", 
        "[WARNING] ", 
        "[ERROR]   ", 
        "[CRITICAL]"
    };
    
    // Basic console logging (we'll expand this later)
    fprintf(stderr, "%s", level_strings[level]);
    vfprintf(stderr, format, args);
    fprintf(stderr, "\n");
    
    va_end(args);
    
    // In future, we might add file logging or custom error handlers
}

// Usage example
log_message(LOG_WARNING, "OpenCL device selection fallback triggered");