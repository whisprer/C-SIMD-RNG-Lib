// universal_bench.cpp - remove the rotl function definition
#include "universal_rng.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// Original xoroshiro128+ for comparison
typedef struct {
    uint64_t s[2];
} xoroshiro128plus_state;

static inline uint64_t xoroshiro128plus_next(xoroshiro128plus_state *state) {
    const uint64_t s0 = state->s[0];
    uint64_t s1 = state->s[1];
    
    // Calculate output with + scrambler (just add)
    const uint64_t result = s0 + s1;
    
    // Update state
    s1 ^= s0;
    state->s[0] = rotl(s0, 24) ^ s1 ^ (s1 << 16);
    state->s[1] = rotl(s1, 37);
    
    return result;
}

static inline void xoroshiro128plus_seed(xoroshiro128plus_state *state, uint64_t seed) {
    // SplitMix64
    uint64_t z = (seed + 0x9e3779b97f4a7c15ULL);
    z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
    z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
    state->s[0] = z ^ (z >> 31);

    z = (state->s[0] + 0x9e3779b97f4a7c15ULL);
    z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
    z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
    state->s[1] = z ^ (z >> 31);
}

// Benchmark function for original algorithm
static double benchmark_original(uint64_t iters) {
    xoroshiro128plus_state st;
    xoroshiro128plus_seed(&st, 42);

    clock_t start = clock();
    uint64_t sum = 0;
    for (uint64_t i = 0; i < iters; i++) {
        sum ^= xoroshiro128plus_next(&st);
    }
    clock_t end = clock();
    double secs = (double)(end - start)/CLOCKS_PER_SEC;

    // Anti-optimization
    if (sum == 1) printf("Won't happen: %llu\n", (unsigned long long)sum);
    return secs;
}

// Benchmark function for universal implementation
static double benchmark_universal(uint64_t iters) {
    universal_rng_t* rng = universal_rng_new(42);

    clock_t start = clock();
    uint64_t sum = 0;
    for (uint64_t i = 0; i < iters; i++) {
        sum ^= universal_rng_next_u64(rng);
    }
    clock_t end = clock();
    double secs = (double)(end - start)/CLOCKS_PER_SEC;

    // Anti-optimization
    if (sum == 1) printf("Won't happen: %llu\n", (unsigned long long)sum);
    universal_rng_free(rng);
    return secs;
}

// Simple usage example
static void basic_usage_example() {
    printf("Basic Usage of Universal xoroshiro128++:\n");
    printf("--------------------------------------\n");

    universal_rng_t* rng = universal_rng_new(12345ULL);
    printf("Using implementation: %s\n\n", universal_rng_get_impl_name(rng));

    printf("First 5 random integers:\n");
    for (int i = 0; i < 5; i++) {
        printf("  %llu\n", (unsigned long long)universal_rng_next_u64(rng));
    }

    printf("\nFirst 5 random doubles [0,1):\n");
    for (int i = 0; i < 5; i++) {
        printf("  %f\n", universal_rng_next_double(rng));
    }

    universal_rng_free(rng);
    printf("\n");
}

// Performance comparison
static void performance_comparison() {
    const uint64_t iters = 100000000ULL; // 100 million
    printf("Performance Comparison:\n");
    printf("-----------------------\n");
    printf("Generating %llu numbers with each generator...\n", (unsigned long long)iters);

    double t1 = benchmark_original(iters);
    double t2 = benchmark_universal(iters);

    printf("xoroshiro128+ time:    %.4f s (%.2f M/s)\n", t1, (iters/t1)/1e6);
    printf("Universal RNG time:    %.4f s (%.2f M/s)\n", t2, (iters/t2)/1e6);
    printf("Speedup:               %.2fx\n", t1/t2);
}

static void benchmark_batch() {
    const uint64_t count = 10000000; // 10 million
    uint64_t* results = (uint64_t*)malloc(count * sizeof(uint64_t));
    
    universal_rng_t* rng = universal_rng_new(42);
    
    printf("\nBatch Generation Performance:\n");
    printf("---------------------------\n");
    printf("Generating %llu numbers in batch mode...\n", (unsigned long long)count);
    
    // Traditional one-at-a-time approach
    clock_t start1 = clock();
    for (uint64_t i = 0; i < count; i++) {
        results[i] = universal_rng_next_u64(rng);
    }
    clock_t end1 = clock();
    double time1 = (double)(end1 - start1)/CLOCKS_PER_SEC;
    
    // Batch generation
    clock_t start2 = clock();
    universal_rng_next_batch(rng, results, count);
    clock_t end2 = clock();
    double time2 = (double)(end2 - start2)/CLOCKS_PER_SEC;
    
    printf("One-at-a-time: %.4f s (%.2f M/s)\n", time1, (count/time1)/1e6);
    printf("Batch mode:     %.4f s (%.2f M/s)\n", time2, (count/time2)/1e6);
    printf("Speedup:        %.2fx\n", time1/time2);
    
    universal_rng_free(rng);
    free(results);
}

// Then add a call to this function in the main function:
int main() {
    printf("\n=== Universal xoroshiro128++ Benchmark ===\n\n");
    basic_usage_example();
    performance_comparison();
    benchmark_batch();  // Add this line
    return 0;
}
