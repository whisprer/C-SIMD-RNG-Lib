#ifndef XOROSHIRO128PP_SIMD_MAIN_H
#define XOROSHIRO128PP_SIMD_MAIN_H

// SIMD-Optimized xoroshiro128++ Implementation
//
// This code implements parallel versions of xoroshiro128++ using
// SIMD instructions for AVX2, AVX-512, and ARM Neon architectures.
//
// Based on the original xoroshiro128+ algorithm by David Blackman and Sebastiano Vigna
// Adapted to use the ++ scrambler for improved statistical properties

#include <stdint.h>
#include <string.h>
#include <memory>
#include <array>
#include <random>
#include <algorithm>
#include <immintrin.h>

#ifdef _MSC_VER
#include <intrin.h>
#else
#include <x86intrin.h>
#endif

#include "universal_rng.h"

// Forward declaration
static inline __m256i rotl_avx2(__m256i x, int k);

// Platform detection
#if defined(__AVX512F__) && defined(__AVX512DQ__)
  #define USE_AVX512
#elif defined(__AVX2__)
  #define USE_AVX2
#elif defined(__ARM_NEON)
  #define USE_NEON
  #include <arm_neon.h>
#endif

namespace xoroshiro {

// Base scalar implementation
class Xoroshiro128pp {
public:
    // Constructor with seed
    explicit Xoroshiro128pp(uint64_t seed) {
        seed_state(seed);
    }
    
    // Default constructor uses random device
    Xoroshiro128pp() {
        std::random_device rd;
        seed_state(rd());
    }
    
    // Generate next 64-bit value
    uint64_t next() {
        const uint64_t s0 = state_[0];
        uint64_t s1 = state_[1];
        const uint64_t result = rotl(s0 + s1, 17) + s0;

        s1 ^= s0;
        state_[0] = rotl(s0, 49) ^ s1 ^ (s1 << 21);
        state_[1] = rotl(s1, 28);

        return result;
    }
    
    // Generate a double in [0,1) range
    double next_double() {
        // Convert to double in [0,1) using the high 53 bits
        const uint64_t value = next();
        return (value >> 11) * (1.0 / (1ULL << 53));
    }
    
    // Jump ahead equivalent to 2^64 calls to next()
    void jump() {
        static const std::array<uint64_t, 2> JUMP = {{ 0xdf900294d8f554a5, 0x170865df4b3201fc }};
        
        uint64_t s0 = 0;
        uint64_t s1 = 0;
        
        for (auto jump_val : JUMP) {
            for (int b = 0; b < 64; b++) {
                if (jump_val & (1ULL << b)) {
                    s0 ^= state_[0];
                    s1 ^= state_[1];
                }
                next();
            }
        }
        
        state_[0] = s0;
        state_[1] = s1;
    }
    
    // Get a copy of the current state
    std::array<uint64_t, 2> get_state() const {
        return state_;
    }
    
    // Set the state directly
    void set_state(const std::array<uint64_t, 2>& new_state) {
        state_ = new_state;
    }

private:
    std::array<uint64_t, 2> state_;
    
    // Helper for bit rotation
    static inline uint64_t rotl(uint64_t x, int k) {
        return (x << k) | (x >> (64 - k));
    }
    
    // Initialize state from a 64-bit seed using SplitMix64
    void seed_state(uint64_t seed) {
        // SplitMix64 for state initialization
        uint64_t z = (seed + 0x9e3779b97f4a7c15ULL);
        z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
        z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
        state_[0] = z ^ (z >> 31);

        z = (state_[0] + 0x9e3779b97f4a7c15ULL);
        z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
        z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
        state_[1] = z ^ (z >> 31);
    }
};

/////////////////////////////////////////////////////////////////////////////
// AVX2 implementation (4 parallel streams)
/////////////////////////////////////////////////////////////////////////////
#ifdef USE_AVX2

class Xoroshiro128ppAVX2 {
public:
    // Constructor with seed
    explicit Xoroshiro128ppAVX2(uint64_t seed) {
        // Generate 4 different seeds from the master seed
        auto seeds = generate_seeds(seed, 4);
        init(seeds.data());
    }
    
    // Generate 4 random 64-bit values in parallel
    std::array<uint64_t, 4> next_batch() {
        std::array<uint64_t, 4> results;
        
        // Calculate output - scrambler is: rotl(s0 + s1, 17) + s0
        __m256i sum = _mm256_add_epi64(state0_, state1_);
        __m256i rotated_sum = rotl_avx2(sum, 17);
        __m256i result = _mm256_add_epi64(rotated_sum, state0_);
        
        // Store results
        _mm256_storeu_si256(reinterpret_cast<__m256i*>(results.data()), result);
        
        // Update state
        __m256i s1 = _mm256_xor_si256(state0_, state1_);
        
        state0_ = _mm256_xor_si256(
                      rotl_avx2(state0_, 49),
                      _mm256_xor_si256(
                          s1,
                          _mm256_slli_epi64(s1, 21)
                      )
                    );
                    
        state1_ = rotl_avx2(s1, 28);
        
        return results;
    }
    
    // Get a single random number (from the first stream)
    uint64_t next() {
        if (buffer_pos_ >= 4) {
            results_ = next_batch();
            buffer_pos_ = 0;
        }
        
        return results_[buffer_pos_++];
    }
    
    // Get a random double in [0,1) range
    double next_double() {
        const uint64_t value = next();
        return (value >> 11) * (1.0 / (1ULL << 53));
    }
    
private:
    __m256i state0_;  // 4 streams, first state component
    __m256i state1_;  // 4 streams, second state component
    std::array<uint64_t, 4> results_{};
    size_t buffer_pos_ = 4;  // Force buffer refill on first call
    
    // Initialize 4 parallel streams with different seeds
    void init(const uint64_t* seeds) {
        // We'll use the scalar implementation to initialize each state
        Xoroshiro128pp tmp(seeds[0]);
        
        alignas(32) std::array<uint64_t, 4> s0_vals;
        alignas(32) std::array<uint64_t, 4> s1_vals;
        
        for (int i = 0; i < 4; i++) {
            auto tmp_state = Xoroshiro128pp(seeds[i]).get_state();
            s0_vals[i] = tmp_state[0];
            s1_vals[i] = tmp_state[1];
        }
        
        state0_ = _mm256_load_si256(reinterpret_cast<const __m256i*>(s0_vals.data()));
        state1_ = _mm256_load_si256(reinterpret_cast<const __m256i*>(s1_vals.data()));
    }
    
    // Helper to generate multiple seeds from a master seed
    static std::array<uint64_t, 4> generate_seeds(uint64_t seed, int count) {
        std::array<uint64_t, 4> seeds;
        Xoroshiro128pp rng(seed);
        
        // Extract the state directly for the first two seeds
        auto initial_state = rng.get_state();
        seeds[0] = initial_state[0];
        seeds[1] = initial_state[1];
        
        // Generate more seeds if needed
        for (int i = 2; i < count; i++) {
            seeds[i] = rng.next();
        }
        
        return seeds;
    }
};

#endif // USE_AVX2

/////////////////////////////////////////////////////////////////////////////
// AVX-512 implementation (8 parallel streams)
/////////////////////////////////////////////////////////////////////////////
#ifdef USE_AVX512

class Xoroshiro128ppAVX512 {
public:
    // Constructor with seed
    explicit Xoroshiro128ppAVX512(uint64_t seed) {
        // Generate 8 different seeds from the master seed
        auto seeds = generate_seeds(seed, 8);
        init(seeds.data());
    }
    
    // Generate 8 random 64-bit values in parallel
    std::array<uint64_t, 8> next_batch() {
        std::array<uint64_t, 8> results;
        
        // Calculate output - scrambler is: rotl(s0 + s1, 17) + s0
        __m512i sum = _mm512_add_epi64(state0_, state1_);
        __m512i rotated_sum = rotl_avx512(sum, 17);
        __m512i result = _mm512_add_epi64(rotated_sum, state0_);
        
        // Store results
        _mm512_storeu_si512(reinterpret_cast<__m512i*>(results.data()), result);
        
        // Update state
        __m512i s1 = _mm512_xor_si512(state0_, state1_);
        
        state0_ = _mm512_xor_si512(
                      rotl_avx512(state0_, 49),
                      _mm512_xor_si512(
                          s1,
                          _mm512_slli_epi64(s1, 21)
                      )
                    );
                    
        state1_ = rotl_avx512(s1, 28);
        
        return results;
    }
    
    // Get a single random number (from the first stream)
    uint64_t next() {
        if (buffer_pos_ >= 8) {
            results_ = next_batch();
            buffer_pos_ = 0;
        }
        
        return results_[buffer_pos_++];
    }
    
    // Get a random double in [0,1) range
    double next_double() {
        const uint64_t value = next();
        return (value >> 11) * (1.0 / (1ULL << 53));
    }
    
private:
    __m512i state0_;  // 8 streams, first state component
    __m512i state1_;  // 8 streams, second state component
    std::array<uint64_t, 8> results_{};
    size_t buffer_pos_ = 8;  // Force buffer refill on first call
    
    // Helper for AVX-512 rotl
    static inline __m512i rotl_avx512(__m512i x, int k) {
        return _mm512_or_si512(_mm512_slli_epi64(x, k), _mm512_srli_epi64(x, 64 - k));
    }
    
    // Initialize 8 parallel streams with different seeds
    void init(const uint64_t* seeds) {
        // We'll use the scalar implementation to initialize each state
        alignas(64) std::array<uint64_t, 8> s0_vals;
        alignas(64) std::array<uint64_t, 8> s1_vals;
        
        for (int i = 0; i < 8; i++) {
            auto tmp_state = Xoroshiro128pp(seeds[i]).get_state();
            s0_vals[i] = tmp_state[0];
            s1_vals[i] = tmp_state[1];
        }
        
        state0_ = _mm512_load_si512(reinterpret_cast<const __m512i*>(s0_vals.data()));
        state1_ = _mm512_load_si512(reinterpret_cast<const __m512i*>(s1_vals.data()));
    }
    
    // Helper to generate multiple seeds from a master seed
    static std::array<uint64_t, 8> generate_seeds(uint64_t seed, int count) {
        std::array<uint64_t, 8> seeds;
        Xoroshiro128pp rng(seed);
        
        // Extract the state directly for the first two seeds
        auto initial_state = rng.get_state();
        seeds[0] = initial_state[0];
        seeds[1] = initial_state[1];
        
        // Generate more seeds if needed
        for (int i = 1; i < 4; i++) {
            rng.next(); // Just advance the generator
            seeds[i*2] = rng.get_state()[0];
            seeds[i*2+1] = rng.get_state()[1];
        }
        
        return seeds;
    }
};

#endif // USE_AVX512

/////////////////////////////////////////////////////////////////////////////
// ARM Neon implementation (2 parallel streams)
/////////////////////////////////////////////////////////////////////////////
#ifdef USE_NEON

class Xoroshiro128ppNeon {
public:
    // Constructor with seed
    explicit Xoroshiro128ppNeon(uint64_t seed) {
        // Generate 2 different seeds from the master seed
        auto seeds = generate_seeds(seed, 2);
        init(seeds.data());
    }
    
    // Generate 2 random 64-bit values in parallel
    std::array<uint64_t, 2> next_batch() {
        std::array<uint64_t, 2> results;
        
        // Calculate output - scrambler is: rotl(s0 + s1, 17) + s0
        uint64x2_t sum = vaddq_u64(state0_, state1_);
        uint64x2_t rotated_sum = rotl_neon(sum, 17);
        uint64x2_t result = vaddq_u64(rotated_sum, state0_);
        
        // Store results
        vst1q_u64(results.data(), result);
        
        // Update state
        uint64x2_t s1 = veorq_u64(state0_, state1_);
        
        state0_ = veorq_u64(
                    rotl_neon(state0_, 49),
                    veorq_u64(
                        s1,
                        vshlq_n_u64(s1, 21)
                    )
                  );
                  
        state1_ = rotl_neon(s1, 28);
        
        return results;
    }
    
    // Get a single random number (from the first stream)
    uint64_t next() {
        if (buffer_pos_ >= 2) {
            results_ = next_batch();
            buffer_pos_ = 0;
        }
        
        return results_[buffer_pos_++];
    }
    
    // Get a random double in [0,1) range
    double next_double() {
        const uint64_t value = next();
        return (value >> 11) * (1.0 / (1ULL << 53));
    }
    
private:
    uint64x2_t state0_;  // 2 streams, first state component
    uint64x2_t state1_;  // 2 streams, second state component
    std::array<uint64_t, 2> results_{};
    size_t buffer_pos_ = 2;  // Force buffer refill on first call
    
    // Helper for NEON rotl
    static inline uint64x2_t rotl_neon(uint64x2_t x, int k) {
        return vsriq_n_u64(vshlq_n_u64(x, k), x, 64 - k);
    }
    
    // Initialize 2 parallel streams with different seeds
    void init(const uint64_t* seeds) {
        // We'll use the scalar implementation to initialize each state
        alignas(16) std::array<uint64_t, 2> s0_vals;
        alignas(16) std::array<uint64_t, 2> s1_vals;
        
        for (int i = 0; i < 2; i++) {
            auto tmp_state = Xoroshiro128pp(seeds[i]).get_state();
            s0_vals[i] = tmp_state[0];
            s1_vals[i] = tmp_state[1];
        }
        
        state0_ = vld1q_u64(s0_vals.data());
        state1_ = vld1q_u64(s1_vals.data());
    }
    
    // Helper to generate multiple seeds from a master seed
    static std::array<uint64_t, 2> generate_seeds(uint64_t seed, int count) {
        std::array<uint64_t, 2> seeds;
        Xoroshiro128pp rng(seed);
        
        // Extract the state directly
        auto initial_state = rng.get_state();
        seeds[0] = initial_state[0];
        seeds[1] = initial_state[1];
        
        return seeds;
    }
};

#endif // USE_NEON

/////////////////////////////////////////////////////////////////////////////
// Universal wrapper API with smart pointers
/////////////////////////////////////////////////////////////////////////////

#if defined(USE_AVX512)
    #define XORO_PARALLEL_STREAMS 8
#elif defined(USE_AVX2)
    #define XORO_PARALLEL_STREAMS 4
#elif defined(USE_NEON)
    #define XORO_PARALLEL_STREAMS 2
#else
    #define XORO_PARALLEL_STREAMS 1
#endif

// The modern RNG interface using polymorphism and smart pointers
class XoroshiroSimdRng {
public:
    // Create a new RNG with the best available SIMD implementation
    explicit XoroshiroSimdRng(uint64_t seed) : buffer_pos_(XORO_PARALLEL_STREAMS) {
        #if defined(USE_AVX512)
            impl_type_ = ImplType::AVX512;
            avx512_impl_ = std::make_unique<Xoroshiro128ppAVX512>(seed);
        #elif defined(USE_AVX2)
            impl_type_ = ImplType::AVX2;
            avx2_impl_ = std::make_unique<Xoroshiro128ppAVX2>(seed);
        #elif defined(USE_NEON)
            impl_type_ = ImplType::NEON;
            neon_impl_ = std::make_unique<Xoroshiro128ppNeon>(seed);
        #else
            impl_type_ = ImplType::Scalar;
            scalar_impl_ = std::make_unique<Xoroshiro128pp>(seed);
        #endif
    }
    
    // Default constructor uses a random device for seeding
    XoroshiroSimdRng() : XoroshiroSimdRng(std::random_device()()) {}
    
    // Rule of five (with default implementations)
    ~XoroshiroSimdRng() = default;
    XoroshiroSimdRng(const XoroshiroSimdRng&) = delete;
    XoroshiroSimdRng& operator=(const XoroshiroSimdRng&) = delete;
    XoroshiroSimdRng(XoroshiroSimdRng&&) = default;
    XoroshiroSimdRng& operator=(XoroshiroSimdRng&&) = default;
    
    // Get next 64-bit random value
    uint64_t next_u64() {
        // If we've used all values in the buffer, generate a new batch
        if (buffer_pos_ >= XORO_PARALLEL_STREAMS) {
            refill_buffer();
            buffer_pos_ = 0;
        }
        
        // Return the next value from the buffer
        return buffer_[buffer_pos_++];
    }
    
    // Get random double in [0, 1) range
    double next_double() {
        // Convert to double in [0,1) using the high 53 bits
        const uint64_t value = next_u64();
        return (value >> 11) * (1.0 / (1ULL << 53));
    }
    
    // Jump ahead equivalent to 2^64 calls to next()
    void jump() {
        // We can only jump the scalar version currently
        if (impl_type_ == ImplType::Scalar) {
            scalar_impl_->jump();
        }
        // For SIMD versions, jumping is more complex, so we'll skip implementation
    }
    
    // Get the implementation type as a string (useful for debugging)
    std::string get_impl_type_name() const {
        switch (impl_type_) {
            case ImplType::Scalar: return "Scalar";
            case ImplType::AVX2:   return "AVX2";
            case ImplType::AVX512: return "AVX512";
            case ImplType::NEON:   return "NEON";
            default:               return "Unknown";
        }
    }
    
private:
    enum class ImplType {
        Scalar,
        AVX2,
        AVX512,
        NEON
    };
    
    ImplType impl_type_;
    size_t buffer_pos_;
    std::array<uint64_t, XORO_PARALLEL_STREAMS> buffer_{};
    
    // Implementation-specific members using polymorphism via unique_ptr
    #if defined(USE_AVX512)
        std::unique_ptr<Xoroshiro128ppAVX512> avx512_impl_;
    #endif
    
    #if defined(USE_AVX2)
        std::unique_ptr<Xoroshiro128ppAVX2> avx2_impl_;
    #endif
    
    #if defined(USE_NEON)
        std::unique_ptr<Xoroshiro128ppNeon> neon_impl_;
    #endif
    
    std::unique_ptr<Xoroshiro128pp> scalar_impl_;
    
    // Refill the buffer with new random values
    void refill_buffer() {
        #if defined(USE_AVX512)
            if (impl_type_ == ImplType::AVX512) {
                auto batch = avx512_impl_->next_batch();
                std::copy(batch.begin(), batch.end(), buffer_.begin());
                return;
            }
        #endif
        
        #if defined(USE_AVX2)
            if (impl_type_ == ImplType::AVX2) {
                auto batch = avx2_impl_->next_batch();
                std::copy(batch.begin(), batch.end(), buffer_.begin());
                return;
            }
        #endif
        
        #if defined(USE_NEON)
            if (impl_type_ == ImplType::NEON) {
                auto batch = neon_impl_->next_batch();
                std::copy(batch.begin(), batch.end(), buffer_.begin());
                return;
            }
        #endif
        
        if (impl_type_ == ImplType::Scalar) {
            buffer_[0] = scalar_impl_->next();
            return;
        }
    }
};

} // namespace xoroshiro

// C-style API wrappers for backward compatibility
extern "C" {

// Create a new RNG state with the best available SIMD implementation
xoroshiro_simd_rng* xoroshiro_simd_new(uint64_t seed) {
    auto* rng = new xoroshiro_simd_rng();
    rng->impl = std::make_shared<xoroshiro::XoroshiroSimdRng>(seed);
    return rng;
}

// Free RNG state
void xoroshiro_simd_free(xoroshiro_simd_rng* rng) {
    if (rng) {
        delete rng;
    }
}

// Get next 64-bit random value
uint64_t xoroshiro_simd_next_u64(xoroshiro_simd_rng* rng) {
    return rng->impl->next_u64();
}

// Get random double in [0, 1) range
double xoroshiro_simd_next_double(xoroshiro_simd_rng* rng) {
    return rng->impl->next_double();
}

// Jump ahead equivalent to 2^64 calls to next()
void xoroshiro_simd_jump(xoroshiro_simd_rng* rng) {
    rng->impl->jump();
}

} // extern "C"

// Helper for AVX2 rotl (stays outside the namespace for backward compatibility)
static inline __m256i rotl_avx2(__m256i x, int k) {
    return _mm256_or_si256(_mm256_slli_epi64(x, k), _mm256_srli_epi64(x, 64 - k));
}

#endif // XOROSHIRO128PP_SIMD_MAIN_H
