#ifndef RUNTIME_DETECT_H
#define RUNTIME_DETECT_H

#include <stdint.h>
#include <string.h>
#include <stdlib.h>

// CPU feature detection
typedef struct {
    // Basic SIMD support
    int has_sse2;
    int has_avx;
    int has_avx2;
    int has_neon;
    
    // AVX-512 feature flags
    int has_avx512f;       // Foundation
    int has_avx512cd;      // Conflict Detection
    int has_avx512bw;      // Byte and Word
    int has_avx512dq;      // Doubleword and Quadword
    int has_avx512vl;      // Vector Length
    int has_avx512ifma;    // Integer Fused Multiply-Add
    int has_avx512vbmi;    // Vector Byte Manipulation Instructions
    int has_avx512vbmi2;   // Vector Byte Manipulation Instructions 2
    int has_avx512vnni;    // Vector Neural Network Instructions
    int has_avx512bitalg;  // Bit Algorithms
    int has_avx512vpopcntdq; // Population Count
} cpu_features_t;

// Function declaration only - not implementation
void detect_cpu_features(cpu_features_t* features);

#endif // RUNTIME_DETECT_H
