#ifndef WYRAND_RNG_BENCH_OPTIMIZED_H
#define WYRAND_RNG_BENCH_OPTIMIZED_H

#include <iostream>
#include <iomanip>
#include <string>
#include <chrono>
#include <memory>
#include <array>
#include <cstdint>
#include <functional>
#include <limits>
#include <random>

#include "xoroshiro128pp_simd_main_optimized.h"
#include "verbose_mode.h"

namespace rng {
namespace wyrand {

// Modern C++ implementation of WyRand RNG
class WyRand {
public:
    explicit WyRand(uint64_t seed = 0) : state_(seed ? seed : std::random_device{}()) {}
    
    // Rule of 5 implementation
    ~WyRand() = default;
    WyRand(const WyRand&) = default;
    WyRand& operator=(const WyRand&) = default;
    WyRand(WyRand&&) noexcept = default;
    WyRand& operator=(WyRand&&) noexcept = default;
    
    // Generate next random 64-bit value
    uint64_t next_u64() {
        state_ += 0x9e3779b97f4a7c15ULL;
        uint64_t result = state_;
        result ^= result >> 28;
        result *= 0xbf58476d1ce4e5b9ULL;
        result ^= result >> 29;
        result *= 0x94d049bb133111ebULL;
        result ^= result >> 32;
        return result;
    }
    
    // Generate random double in [0,1)
    double next_double() {
        return static_cast<double>(next_u64() >> 11) * (1.0 / (1ull << 53));
    }
    
    // Generate random float in [0,1)
    float next_float() {
        return static_cast<float>(next_u64() >> 40) * (1.0f / (1ull << 24));
    }
    
    // Fill an array with random values
    template<typename T, size_t N>
    void fill_array(std::array<T, N>& arr) {
        for (auto& val : arr) {
            if constexpr (std::is_same_v<T, uint64_t>) {
                val = next_u64();
            } else if constexpr (std::is_same_v<T, double>) {
                val = next_double();
            } else if constexpr (std::is_same_v<T, float>) {
                val = next_float();
            } else {
                static_assert(std::is_convertible_v<uint64_t, T>, "Unsupported type for fill_array");
                val = static_cast<T>(next_u64());
            }
        }
    }
    
private:
    uint64_t state_;
};

// SIMD-accelerated implementation of WyRand 
// Note: This is a placeholder - in a real implementation we would use SIMD instructions
class WyRandSimd {
public:
    explicit WyRandSimd(uint64_t seed = 0) : base_rng_(seed) {}
    
    // Use the scalar implementation for now
    uint64_t next_u64() {
        return base_rng_.next_u64();
    }
    
    double next_double() {
        return base_rng_.next_double();
    }
    
    float next_float() {
        return base_rng_.next_float();
    }
    
    template<typename T, size_t N>
    void fill_array(std::array<T, N>& arr) {
        base_rng_.fill_array(arr);
    }
    
private:
    WyRand base_rng_;
};

} // namespace wyrand

namespace benchmark {

// Template function for benchmarking
template<typename Func>
auto measure_execution_time(Func&& func) {
    auto start = std::chrono::high_resolution_clock::now();
    auto result = std::forward<Func>(func)();
    auto end = std::chrono::high_resolution_clock::now();
    
    std::chrono::duration<double> duration = end - start;
    return std::make_pair(duration.count(), result);
}

// Benchmark scalar wyrand
double benchmark_wyrand_scalar(uint64_t iters) {
    wyrand::WyRand rng(42ULL);
    
    auto [time, sum] = measure_execution_time([&rng, iters]() {
        uint64_t sum = 0;
        for (uint64_t i = 0; i < iters; i++) {
            sum ^= rng.next_u64();
        }
        return sum;
    });
    
    // Prevent optimization
    if (sum == 1) {
        std::cout << "No-opt: " << sum << std::endl;
    }
    
    return time;
}

// Benchmark SIMD wyrand
double benchmark_wyrand_simd(uint64_t iters) {
    wyrand::WyRandSimd rng(42ULL);
    
    auto [time, sum] = measure_execution_time([&rng, iters]() {
        uint64_t sum = 0;
        for (uint64_t i = 0; i < iters; i++) {
            sum ^= rng.next_u64();
        }
        return sum;
    });
    
    // Prevent optimization
    if (sum == 1) {
        std::cout << "No-opt: " << sum << std::endl;
    }
    
    return time;
}

// Basic usage example for WyRand
void wyrand_basic_usage_example() {
    std::cout << "Basic Usage of WyRand Example:" << std::endl;
    std::cout << "-------------------------------" << std::endl;

    wyrand::WyRand rng(12345ULL);

    std::cout << "First 5 random integers:" << std::endl;
    for (int i = 0; i < 5; i++) {
        std::cout << "  " << rng.next_u64() << std::endl;
    }

    std::cout << "\nFirst 5 random doubles in [0,1):" << std::endl;
    for (int i = 0; i < 5; i++) {
        std::cout << "  " << std::fixed << std::setprecision(6) 
                  << rng.next_double() << std::endl;
    }

    std::cout << std::endl;
}

// Performance comparison for WyRand
void wyrand_performance_comparison() {
    const uint64_t iters = 100000000ULL; // 100 million

    std::cout << "WyRand Performance Comparison:" << std::endl;
    std::cout << "-----------------------------" << std::endl;

    std::cout << "Generating " << iters << " random numbers in each generator..." << std::endl;

    double t1 = benchmark_wyrand_scalar(iters);
    double t2 = benchmark_wyrand_simd(iters);

    std::cout << "WyRand (scalar)  : " << std::fixed << std::setprecision(4) 
              << t1 << " s (" << std::setprecision(2) << (iters/t1)/1e6 << " M/s)" << std::endl;
    std::cout << "WyRand (optimized): " << std::fixed << std::setprecision(4) 
              << t2 << " s (" << std::setprecision(2) << (iters/t2)/1e6 << " M/s)" << std::endl;
    
    if (t1 > t2) {
        std::cout << "Speedup: " << std::fixed << std::setprecision(2) << t1/t2 << "x" << std::endl;
    } else {
        std::cout << "No speedup observed." << std::endl;
    }
}

} // namespace benchmark
} // namespace rng

// C-compatible API
extern "C" {

// Define the C-compatible struct
struct wyrand_rng {
    std::unique_ptr<rng::wyrand::WyRand> rng;
};

// Create a new WyRand RNG instance
wyrand_rng* wyrand_new(uint64_t seed) {
    auto* rng_wrapper = new wyrand_rng();
    rng_wrapper->rng = std::make_unique<rng::wyrand::WyRand>(seed);
    return rng_wrapper;
}

// Free the RNG instance
void wyrand_free(wyrand_rng* rng) {
    if (rng) {
        delete rng;
    }
}

// Get the next 64-bit random number
uint64_t wyrand_next_u64(wyrand_rng* rng) {
    return rng->rng->next_u64();
}

// Get the next double in [0,1)
double wyrand_next_double(wyrand_rng* rng) {
    return rng->rng->next_double();
}

// Get the next float in [0,1)
float wyrand_next_float(wyrand_rng* rng) {
    return rng->rng->next_float();
}

//