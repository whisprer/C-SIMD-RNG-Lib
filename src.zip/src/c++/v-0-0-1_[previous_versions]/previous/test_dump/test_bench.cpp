#include <stdio.h>

int main() {
    printf("=== Testing RNG Benchmark ===\n\n");
    
    // Try to call a simple function from each benchmark
    printf("Calling wyrand_bench...\n");
    run_wyrand_bench();
    
    printf("\nBenchmark completed!\n");
    return 0;
}