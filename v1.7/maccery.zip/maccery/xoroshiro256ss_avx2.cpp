// D:/code/Universal-Architecture-RNG-Lib/v1.7/src/xoshiro256ss_avx2.cpp
#include "ua/ua_xoshiro256ss_avx2.h"
