#ifndef UNIVERSAL_RNG_H
#define UNIVERSAL_RNG_H

#include <stdint.h>
#include <stddef.h>
#include "runtime_detect.h"

// Function signature for bit rotation (used in multiple files)
// Make it inline to avoid multiple definition errors
static inline uint64_t rotl(const uint64_t x, int k) {
    return (x << k) | (x >> (64 - k));
}

// Define the xoroshiro128pp_state structure
typedef struct {
    uint64_t s[2];
} xoroshiro128pp_state;

// Universal RNG structure
typedef struct {
    void* state;
    const char* impl_name;
    uint64_t (*next_u64)(void* state);
    double (*next_double)(void* state);
    void (*next_batch)(void* state, uint64_t* results, size_t count);
} universal_rng_t;

// Function declarations for the universal RNG
universal_rng_t* universal_rng_new(uint64_t seed);
void universal_rng_free(universal_rng_t* rng);
uint64_t universal_rng_next_u64(universal_rng_t* rng);
double universal_rng_next_double(universal_rng_t* rng);
const char* universal_rng_get_impl_name(universal_rng_t* rng);
void universal_rng_next_batch(universal_rng_t* rng, uint64_t* results, size_t count);

// Scalar implementation function declarations
uint64_t scalar_next_u64(void* state);
double scalar_next_double(void* state);
void* scalar_new(uint64_t seed);
void scalar_free(void* state);
void scalar_next_batch(void* state, uint64_t* results, size_t count);

// AVX-512 implementation declarations (conditionally included)
#ifdef USE_AVX512
uint64_t avx512_next_u64(void* state);
double avx512_next_double(void* state);
void* avx512_new(uint64_t seed);
void avx512_free(void* state);
void avx512_next_batch(void* state, uint64_t* results, size_t count);

// Advanced AVX-512 implementation (with additional extensions)
uint64_t avx512_advanced_next_u64(void* state);
double avx512_advanced_next_double(void* state);
void* avx512_advanced_new(uint64_t seed);
void avx512_advanced_free(void* state);
void avx512_advanced_next_batch(void* state, uint64_t* results, size_t count);
#endif

#endif // UNIVERSAL_RNG_H