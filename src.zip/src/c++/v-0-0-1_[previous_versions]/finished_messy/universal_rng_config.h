#ifndef UNIVERSAL_RNG_CONFIG_H
#define UNIVERSAL_RNG_CONFIG_H

#include <type_traits>
#include <stdexcept>
#include <string>
#include <optional>

// Forward declaration of RNG Algorithm from universal_rng.h
namespace rng {
    enum class Algorithm;
}

// Compile-time RNG Configuration Template
template<typename Implementation>
class RNGConfig {
public:
    // Enum for implementation selection
    enum class Implementation {
        ORIGINAL,
        OPTIMIZED
    };

    // Compile-time configuration selection
    static constexpr bool is_valid_config() {
        return std::is_same_v<Implementation, WyRandOriginal> ||
               std::is_same_v<Implementation, WyRandOptimized> ||
               std::is_same_v<Implementation, XoroshiroOriginal> ||
               std::is_same_v<Implementation, XoroshiroOptimized>;
    }

    // Get the appropriate header path based on configuration
    static constexpr const char* get_header_path() {
        if constexpr (std::is_same_v<Implementation, WyRandOriginal>) {
            return "wyrand_simd_main.h";
        } else if constexpr (std::is_same_v<Implementation, WyRandOptimized>) {
            return "wyrand_simd_main_optimized.h";
        } else if constexpr (std::is_same_v<Implementation, XoroshiroOriginal>) {
            return "xoroshiro128pp_simd_main.h";
        } else if constexpr (std::is_same_v<Implementation, XoroshiroOptimized>) {
            return "xoroshiro128pp_simd_main_optimized.h";
        } else {
            throw std::runtime_error("Invalid RNG configuration");
        }
    }

    // Map config implementation to universal_rng.h Algorithm enum
    static rng::Algorithm get_algorithm();
};

// Type aliases for easier configuration
using WyRandOriginal = RNGConfig<struct WyRandOriginalTag>;
using WyRandOptimized = RNGConfig<struct WyRandOptimizedTag>;
using XoroshiroOriginal = RNGConfig<struct XoroshiroOriginalTag>;
using XoroshiroOptimized = RNGConfig<struct XoroshiroOptimizedTag>;

// Configuration Analyzer
class RNGConfigAnalyzer {
public:
    // Analyze and provide detailed configuration information
    template<typename ConfigType>
    static std::optional<std::string> analyze() {
        if constexpr (ConfigType::is_valid_config()) {
            return std::optional<std::string>(
                "RNG Configuration Details:\n" +
                "  Header Path:     " + ConfigType::get_header_path() + "\n"
            );
        }
        return std::nullopt;
    }
};

#endif // UNIVERSAL_RNG_CONFIG_H