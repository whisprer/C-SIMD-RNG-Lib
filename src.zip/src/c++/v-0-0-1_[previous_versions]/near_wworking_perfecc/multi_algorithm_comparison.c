// multi_algorithm_comparison.c
#include "universal_rng.h"
#include "advanced_benchmarking.h"

#define NUM_ITERATIONS 100000000
#define NUM_RUNS 5

int main() {
    // Algorithms to compare
    int algorithms[] = {
        RNG_ALGORITHM_XOROSHIRO,
        RNG_ALGORITHM_WYRAND
    };
    int precision_modes[] = {
        RNG_PRECISION_DOUBLE,
        RNG_PRECISION_SINGLE
    };
    
    // Tracking overall results
    BenchmarkResult* previous_result = NULL;
    
    // Iterate through algorithms and precision modes
    for (size_t algo_idx = 0; 
         algo_idx < sizeof(algorithms) / sizeof(algorithms[0]); 
         algo_idx++) {
        for (size_t prec_idx = 0; 
             prec_idx < sizeof(precision_modes) / sizeof(precision_modes[0]); 
             prec_idx++) {
            
            printf("\n=== Benchmarking Algorithm %d, Precision %d ===\n", 
                   algorithms[algo_idx], precision_modes[prec_idx]);
            
            // Multiple runs for statistical significance
            for (int run = 0; run < NUM_RUNS; run++) {
                printf("Run %d: ", run + 1);
                
                // Run benchmark
                BenchmarkResult* current_result = run_precise_benchmark(
                    NUM_ITERATIONS,
                    algorithms[algo_idx],
                    precision_modes[prec_idx],
                    previous_result
                );
                
                if (!current_result) {
                    fprintf(stderr, "Benchmark failed\n");
                    continue;
                }
                
                // Print results
                printf("Total Time: %llu ns, Rate: %.2f numbers/sec, "
                       "Performance Delta: %.2f%%\n",
                       current_result->total_time_ns,
                       current_result->generation_rate,
                       current_result->performance_delta);
                
                // Export to CSV
                char filename[256];
                snprintf(filename, sizeof(filename), 
                    "benchmark_algo%d_prec%d_run%d.csv", 
                    algorithms[algo_idx], 
                    precision_modes[prec_idx], 
                    run + 1);
                export_benchmark_to_csv(current_result, filename);
                
                // Update previous result for next comparison
                if (previous_result) {
                    free_benchmark_result(previous_result);
                }
                previous_result = current_result;
            }
        }
    }
    
    // Final cleanup
    if (previous_result) {
        free_benchmark_result(previous_result);
    }
    
    return 0;
}