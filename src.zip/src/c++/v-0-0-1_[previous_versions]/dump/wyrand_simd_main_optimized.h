#endif

#if defined(__AVX512F__) && defined(__AVX512DQ__)
  #ifndef USE_AVX512
    #define USE_AVX512
  #endif
#elif defined(__AVX2__)
  #ifndef USE_AVX2
    #define USE_AVX2
  #endif
#elif defined(__AVX__)
  #ifndef USE_AVX
    #define USE_AVX
  #endif
#elif defined(__ARM_NEON) || defined(__ARM_NEON__)
  #ifndef USE_NEON
    #define USE_NEON
  #endif
  #include <arm_neon.h>
#elif defined(__SSE2__)
  #ifndef USE_SSE2
    #define USE_SSE2
  #endif
#endif

static inline uint64_t wyrand_core_scalar(uint64_t *seed) {
    *seed += 0xa0761d6478bd642FULL;
    __uint128_t t = ( __uint128_t ) (*seed) * ( (*seed) ^ 0xe7037ed1a0b428dbULL );
    return (uint64_t)(t >> 64) ^ (uint64_t)t;
}

static inline __m128i mul64_128(__m128i x, __m128i y) {
    __m128i x_lo = _mm_and_si128(x, _mm_set1_epi64x(0xffffffffULL));
    __m128i x_hi = _mm_srli_epi64(x, 32);
    __m128i y_lo = _mm_and_si128(y, _mm_set1_epi64x(0xffffffffULL));
    __m128i y_hi = _mm_srli_epi64(y, 32);

    __m128i lo_lo = _mm_mul_epu32(x, y);         
    __m128i hi_hi = _mm_mul_epu32(x_hi, y_hi);   
    
    __m128i cross_1 = _mm_mul_epu32(x_lo, y_hi);
    __m128i cross_2 = _mm_mul_epu32(x_hi, y_lo);

    __m128i sum_cross = _mm_add_epi64(cross_1, cross_2);

    __m128i sum_cross_shl32 = _mm_slli_epi64(sum_cross, 32);

    __m128i low = _mm_add_epi64(lo_lo, sum_cross_shl32);

    __m128i sum_cross_shr32 = _mm_srli_epi64(sum_cross, 32);

    __m128i high = _mm_add_epi64(hi_hi, sum_cross_shr32);

    return _mm_xor_si128(high, low);
}

static inline __m128i wyrand_sse_step(__m128i seed) {
    __m128i add_const = _mm_set1_epi64x(0xa0761d6478bd642FULL);
    seed = _mm_add_epi64(seed, add_const);

    __m128i magic = _mm_set1_epi64x(0xe7037ed1a0b428dbULL);
    __m128i xored = _mm_xor_si128(seed, magic);

    __m128i product = mul64_128(seed, xored);
    return product;
}

#if defined(USE_SSE2) || defined(USE_AVX) || defined(USE_AVX2) || defined(USE_AVX512) || defined(USE_NEON)
static inline uint64_t wyrand_core_scalar_fast(uint64_t s) {
    return wyrand_core_scalar(&s);
}
#endif

#ifdef USE_NEON
#include <arm_neon.h>
typedef struct {
    uint64x2_t seed; 
} wyrand_neon_t;

static inline void wyrand_neon_init(wyrand_neon_t *st, const uint64_t s[2]) {
    st->seed = vld1q_u64(s);
}
static inline void wyrand_neon_gen(wyrand_neon_t *st, uint64_t out[2]) {
    uint64_t tmp[2];
    vst1q_u64(tmp, st->seed);
    out[0] = wyrand_core_scalar_fast(tmp[0]);
    out[1] = wyrand_core_scalar_fast(tmp[1]);
    tmp[0] += 0xa0761d6478bd642FULL;
    tmp[1] += 0xa0761d6478bd642FULL;
    st->seed = vld1q_u64(tmp);
}
#endif

#ifdef USE_SSE2
#include <emmintrin.h>
typedef struct {
    __m128i seed;
} wyrand_sse2_t;

static inline void wyrand_sse2_init(wyrand_sse2_t* st, const uint64_t* s) {
    st->seed = _mm_set_epi64x(s[1], s[0]);
}

static inline void wyrand_sse2_gen(wyrand_sse2_t *st, uint64_t out[2]) {
    __m128i result = wyrand_sse_step(st->seed);
    _mm_storeu_si128((__m128i*)out, result);

    __m128i addc = _mm_set1_epi64x(0xa0761d6478bd642FULL);
    st->seed = _mm_add_epi64(st->seed, addc);
}
#endif

#ifdef USE_AVX2
typedef struct {
    __m256i seed; 
} wyrand_avx2_t;

static inline void wyrand_avx2_init(wyrand_avx2_t *st, const uint64_t s[4]) {
    st->seed = _mm256_setr_epi64x(s[0], s[1], s[2], s[3]);
}

static inline void wyrand_avx2_gen(wyrand_avx2_t *st, uint64_t out[4]) {
    __m128i lo = _mm256_castsi256_si128(st->seed);       
    __m128i hi = _mm256_extracti128_si256(st->seed, 1);  

    __m128i r_lo = wyrand_sse_step(lo);
    __m128i r_hi = wyrand_sse_step(hi);

    _mm_storeu_si128((__m128i*)&out[0], r_lo);
    _mm_storeu_si128((__m128i*)&out[2], r_hi);

    __m128i addc = _mm_set1_epi64x(0xa0761d6478bd642FULL);
    lo = _mm_add_epi64(lo, addc);
    hi = _mm_add_epi64(hi, addc);

    st->seed = _mm256_set_m128i(hi, lo);
}
#endif

#ifdef USE_AVX
typedef struct {
    __m256i seed; 
} wyrand_avx_t;

static inline void wyrand_avx_init(wyrand_avx_t *st, const uint64_t s[4]) {
    st->seed = _mm256_loadu_si256((const __m256i*)s);
}

static inline void wyrand_avx_gen(wyrand_avx_t *st, uint64_t out[4]) {
    __m128i lo = _mm256_castsi256_si128(st->seed);
    __m128i hi = _mm256_extractf128_si256(st->seed, 1);

    __m128i r_lo = wyrand_sse_step(lo);
    __m128i r_hi = wyrand_sse_step(hi);

    _mm_storeu_si128((__m128i*)&out[0], r_lo);
    _mm_storeu_si128((__m128i*)&out[2], r_hi);

    __m128i addc = _mm_set1_epi64x(0xa0761d6478bd642FULL);
    lo = _mm_add_epi64(lo, addc);
    hi = _mm_add_epi64(hi, addc);

    st->seed = _mm256_insertf128_si256(_mm256_castsi128_si256(lo), hi, 1);
}
#endif

#ifdef USE_AVX512
#include <immintrin.h>
typedef struct {
    __m512i seed;
} wyrand_avx512_t;

static inline void wyrand_avx512_init(wyrand_avx512_t *st, const uint64_t s[8]) {
    st->seed = _mm512_setr_epi64(s[0], s[1], s[2], s[3], s[4], s[5], s[6], s[7]);
}

static inline void wyrand_avx512_gen(wyrand_avx512_t *st, uint64_t out[8]) {
    __m128i chunk[4];
    _mm512_storeu_si512((void*)chunk, st->seed);

    for (int i=0; i<4; i++) {
        __m128i r = wyrand_sse_step(chunk[i]);
        _mm_storeu_si128((__m128i*)&out[i*2], r);
        __m128i addc = _mm_set1_epi64x(0xa0761d6478bd642FULL);
        chunk[i] = _mm_add_epi64(chunk[i], addc);
    }
    st->seed = _mm512_loadu_si512((void*)chunk);
}
#endif

#ifdef USE_OPENCL
#ifdef _WIN32
#include <CL/cl.h>
#else
#include <OpenCL/opencl.h>
#endif

static const char* wyrand_opencl_src = R"(
inline ulong wyrand_core_scalar(ulong *seed) {
    *seed += 0xa0761d6478bd642FUL;
    ulong s = *seed;
    ulong x = s ^ 0xe7037ed1a0b428dbUL;
    __uint128_t m = ( (__uint128_t)s ) * ( (__uint128_t)x );
    return (ulong)(m >> 64) ^ (ulong)m;
}

__kernel void wyrand_generate(__global ulong* seeds, __global ulong* results, uint n) {
    uint id = get_global_id(0);
    if (id < n) {
        ulong s = seeds[id];
        ulong r = wyrand_core_scalar(&s);
        results[id] = r;
        seeds[id] = s; 
    }
}

__kernel void wyrand_init(__global ulong* seeds, ulong seedval, uint n) {
    uint id = get_global_id(0);
    if (id < n) {
        ulong s = seedval + ((ulong)id*0x9e3779b97f4a7c15UL);
        if (s==0UL) s=0x1234567890ABCDEFUL;
        seeds[id] = s;
    }
}
)";

typedef struct {
    cl_context       ctx;
    cl_command_queue cq;
    cl_program       prog;
    cl_kernel        kgen;
    cl_kernel        kinit;
    cl_mem           seedsbuf;
    cl_mem           resbuf;
    size_t           wgsize;
    size_t           batch;
    std::unique_ptr<uint64_t[]> hostres;
    size_t           pos;
    int              ok;
} wyrand_opencl_state;

static std::unique_ptr<wyrand_opencl_state> wyrand_opencl_new(uint64_t seedval) {
    auto st = std::make_unique<wyrand_opencl_state>();
    cl_int err;
    cl_platform_id plat;
    cl_device_id dev;

    err = clGetPlatformIDs(1, &plat, NULL);
    if (err!=CL_SUCCESS) { return nullptr; }
    err = clGetDeviceIDs(plat, CL_DEVICE_TYPE_GPU, 1, &dev, NULL);
    if (err!=CL_SUCCESS) {
        err=clGetDeviceIDs(plat, CL_DEVICE_TYPE_CPU, 1, &dev, NULL);
        if (err!=CL_SUCCESS) { return nullptr; }
    }
    st->ctx = clCreateContext(NULL,1,&dev,NULL,NULL,&err);
    if(err!=CL_SUCCESS){ return nullptr; }

    #ifdef CL_VERSION_2_0
    st->cq = clCreateCommandQueueWithProperties(st->ctx, dev, 0, &err);
    #else
    st->cq = clCreateCommandQueue(st->ctx, dev, 0, &err);
    #endif
    if(err!=CL_SUCCESS){ return nullptr; }

    st->prog = clCreateProgramWithSource(st->ctx,1,&wyrand_opencl_src,NULL,&err);
    if(err!=CL_SUCCESS){ return nullptr; }
    err=clBuildProgram(st->prog,1,&dev,NULL,NULL,NULL);
    if(err!=CL_SUCCESS){
        size_t logsize; clGetProgramBuildInfo(st->prog, dev, CL_PROGRAM_BUILD_LOG, 0,NULL,&logsize);
        std::unique_ptr<char[]> log = std::make_unique<char[]>(logsize);
        clGetProgramBuildInfo(st->prog, dev, CL_PROGRAM_BUILD_LOG, logsize, log.get(), NULL);
        fprintf(stderr,"OpenCL build error:\n%s\n", log.get());
        return nullptr;
    }

    st->kgen = clCreateKernel(st->prog,"wyrand_generate",&err);
    if(err!=CL_SUCCESS){ return nullptr;}
    st->kinit= clCreateKernel(st->prog,"wyrand_init",&err);
    if(err!=CL_SUCCESS){ return nullptr;}
    err= clGetKernelWorkGroupInfo(st->kgen, dev, CL_KERNEL_WORK_GROUP_SIZE, sizeof(size_t), &st->wgsize,NULL);
    if(err!=CL_SUCCESS){ st->wgsize=64; }

    st->batch= st->wgsize*64;
    st->seedsbuf= clCreateBuffer(st->ctx, CL_MEM_READ_WRITE, st->batch*sizeof(cl_ulong), NULL,&err);
    if(err!=CL_SUCCESS){ return nullptr;}

    st->prog = clCreateProgramWithSource(st->ctx,1,&wyrand_opencl_src,NULL,&err);
    if(err!=CL_SUCCESS){ return nullptr; }
    err=clBuildProgram(st->prog,1,&dev,NULL,NULL,NULL);
    if(err!=CL_SUCCESS){
        size_t logsize; clGetProgramBuildInfo(st->prog, dev, CL_PROGRAM_BUILD_LOG, 0,NULL,&logsize);
        std::unique_ptr<char[]> log = std::make_unique<char[]>(logsize);
        clGetProgramBuildInfo(st->prog, dev, CL_PROGRAM_BUILD_LOG, logsize, log.get(), NULL);
        fprintf(stderr,"OpenCL build error:\n%s\n", log.get());
        return nullptr;
    }

    st->kgen = clCreateKernel(st->prog,"wyrand_generate",&err);
    if(err!=CL_SUCCESS){ return nullptr;}
    st->kinit= clCreateKernel(st->prog,"wyrand_init",&err);
    if(err!=CL_SUCCESS){ return nullptr;}
    err= clGetKernelWorkGroupInfo(st->kgen, dev, CL_KERNEL_WORK_GROUP_SIZE, sizeof(size_t), &st->wgsize,NULL);
    if(err!=CL_SUCCESS){ st->wgsize=64; }

    st->batch= st->wgsize*64;
    st->seedsbuf= clCreateBuffer(st->ctx, CL_MEM_READ_WRITE, st->batch*sizeof(cl_ulong), NULL,&err);
    if(err!=CL_SUCCESS){ return nullptr;}
    st->resbuf= clCreateBuffer(st->ctx, CL_MEM_READ_WRITE, st->batch*sizeof(cl_ulong), NULL,&err);
    if(err!=CL_SUCCESS){ return nullptr;}

    st->hostres= std::make_unique<uint64_t[]>(st->batch);

    size_t gs= ((st->batch+st->wgsize-1)/st->wgsize)*st->wgsize;
    err= clEnqueueNDRangeKernel(st->cq, st->kinit,1,NULL,&gs,&st->wgsize,0,NULL,NULL);

    // set gen kernel args
    err= clSetKernelArg(st->kgen,0,sizeof(cl_mem),&st->seedsbuf);
    err|=clSetKernelArg(st->kgen,1,sizeof(cl_mem), &st->resbuf);
    err|=clSetKernelArg(st->kgen,2,sizeof(cl_uint), &st->batch);
    // gen once
    err= clEnqueueNDRangeKernel(st->cq, st->kgen,1,NULL,&gs,&st->wgsize,0,NULL,NULL);
    err= clEnqueueReadBuffer(st->cq, st->resbuf, CL_TRUE,0, st->batch*sizeof(cl_ulong), st->hostres.get(),0,NULL,NULL);

    st->pos=0; st->ok=1;
    return st;
}

static inline void wyrand_opencl_refill(wyrand_opencl_state* st){
    size_t gs= ((st->batch+st->wgsize-1)/st->wgsize)*st->wgsize;
    clEnqueueNDRangeKernel(st->cq, st->kgen,1,NULL,&gs,&st->wgsize,0,NULL,NULL);
    clEnqueueReadBuffer(st->cq, st->resbuf, CL_TRUE,0, st->batch*sizeof(cl_ulong), st->hostres.get(),0,NULL,NULL);
    st->pos=0;
}

static inline uint64_t wyrand_opencl_next(wyrand_opencl_state* st){
    if(st->pos>=st->batch) wyrand_opencl_refill(st);
    return st->hostres[st->pos++];
}

static inline void wyrand_opencl_free(std::unique_ptr<wyrand_opencl_state>& st){
    // No manual cleanup needed, unique_ptr will handle it
}
#endif // USE_OPENCL

#if defined(USE_OPENCL)
  #define WYRAND_PARALLEL_STREAMS 1024
#elif defined(USE_AVX512)
  #define WYRAND_PARALLEL_STREAMS 8
#elif defined(USE_AVX2)
  #define WYRAND_PARALLEL_STREAMS 4
#elif defined(USE_AVX)
  #define WYRAND_PARALLEL_STREAMS 4
#elif defined(USE_NEON)
  #define WYRAND_PARALLEL_STREAMS 2
#elif defined(USE_SSE2)
  #define WYRAND_PARALLEL_STREAMS 2
#else
  #define WYRAND_PARALLEL_STREAMS 1
#endif

typedef struct {
    std::shared_ptr<void> state;  
    int      type;   
    int      bufpos;
    uint64_t buffer[WYRAND_PARALLEL_STREAMS];
} wyrand_simd_rng;

static inline std::unique_ptr<wyrand_simd_rng> wyrand_simd_new(uint64_t seed) {
    auto rng = std::make_unique<wyrand_simd_rng>();
    rng->bufpos= WYRAND_PARALLEL_STREAMS; 

#ifdef USE_OPENCL
    {
        auto st = wyrand_opencl_new(seed);
        if(st){
            rng->state= std::shared_ptr<void>(st.release());
            rng->type= 6;
            return rng;
        }
        fprintf(stderr,"OpenCL init failed, falling back to CPU.\n");
    }
#endif

#ifdef USE_AVX512
    {
        auto st = std::make_unique<wyrand_avx512_t>();
        uint64_t s[8];
        s[0]= seed? seed:0x1234567890ABCDEFULL;
        for(int i=1;i<8;i++){ s[i]= s[i-1]+0x9e3779b97f4a7c15ULL; }
        wyrand_avx512_init(st.get(),s);
        rng->state= std::shared_ptr<void>(st.release()); rng->type=2;
        return rng;
    }
#elif defined(USE_AVX2)
    {
        auto st = std::make_unique<wyrand_avx2_t>();
        uint64_t s[4];
        s[0]= seed? seed:0x1234567890ABCDEFULL;
        for(int i=1;i<4;i++){ s[i]= s[i-1]+0x9e3779b97f4a7c15ULL;}
        wyrand_avx2_init(st.get(),s);
        rng->state= std::shared_ptr<void>(st.release()); rng->type=1;
        return rng;
    }
#elif defined(USE_AVX)
    {
        auto st= std::make_unique<wyrand_avx_t>();
        uint64_t s[4];
        s[0]= seed? seed:0x1234567890ABCDEFULL;
        for(int i=1;i<4;i++){ s[i]= s[i-1]+0x9e3779b97f4a7c15ULL;}
        wyrand_avx_init(st.get(),s);
        rng->state= std::shared_ptr<void>(st.release()); rng->type=5;
        return rng;
    }
#elif defined(USE_NEON)
    {
        auto st= std::make_unique<wyrand_neon_t>();
        uint64_t s[2];
        s[0]= seed? seed:0x1234567890ABCDEFULL;
        s[1]= s[0]+0x9e3779b97f4a7c15ULL;
        wyrand_neon_init(st.get(),s);
        rng->state= std::shared_ptr<void>(st.release()); rng->type=3;
        return rng;
    }
#elif defined(USE_SSE2)
    {
        auto st= std::make_unique<wyrand_sse2_t>();
        uint64_t s[2];
        s[0]= seed? seed:0x1234567890ABCDEFULL;
        s[1]= s[0]+0x9e3779b97f4a7c15ULL;
        wyrand_sse2_init(st.get(),s);
        rng->state= std::shared_ptr<void>(st.release()); rng->type=4;
        return rng;
    }
#else
    // scalar fallback
    {
        auto st= std::make_unique<uint64_t>();
        *st= seed? seed:0x1234567890ABCDEFULL;
        rng->state= std::shared_ptr<uint64_t>(st.release());
        rng->type=0;
        return rng;
    }
#endif
}

static inline void wyrand_simd_free(std::unique_ptr<wyrand_simd_rng>& rng) {
    // No manual cleanup needed, unique_ptr will handle it
}

static inline uint64_t wyrand_simd_next_u64(wyrand_simd_rng* rng){
    #ifdef USE_OPENCL
        if(rng->type==6){
            return wyrand_opencl_next((wyrand_opencl_state*)rng->state.get());
        }
    #endif
        if(rng->bufpos>=WYRAND_PARALLEL_STREAMS){
            // refill
            switch(rng->type){
                case 0: {
                    // scalar
                    uint64_t* st = (uint64_t*)rng->state.get();
                    rng->buffer[0] = wyrand_core_scalar(st);
                }break;
    #ifdef USE_AVX512
                case 2: {
                    auto* st=(wyrand_avx512_t*)rng->state.get();
                    wyrand_avx512_gen(st, rng->buffer);
                }break;
    #endif
    #ifdef USE_AVX2
                case 1: {
                    auto* st=(wyrand_avx2_t*)rng->state.get();
                    wyrand_avx2_gen(st, rng->buffer);
                }break;
    #endif
    #ifdef USE_AVX
                case 5: {
                    auto* st=(wyrand_avx_t*)rng->state.get();
                    wyrand_avx_gen(st, rng->buffer);
                }break;
    #endif
    #ifdef USE_NEON
                case 3: {
                    auto* st=(wyrand_neon_t*)rng->state.get();
                    wyrand_neon_gen(st, rng->buffer);
                }break;
    #endif
    #ifdef USE_SSE2
                case 4: {
                    auto* st=(wyrand_sse2_t*)rng->state.get();
                    wyrand_sse2_gen(st, rng->buffer);
                }break;
    #endif
                default: break;
            }
            rng->bufpos=0;
        }
        return rng->buffer[rng->bufpos++];
    }
    
    static inline double wyrand_simd_next_double(wyrand_simd_rng* rng){
        uint64_t v = wyrand_simd_next_u64(rng);
        return (v>>11)*(1.0/(1ULL<<53));
    }
    
    static inline void wyrand_simd_jump(wyrand_simd_rng* rng){
        (void)rng; 
    }
    
    #endif // WYRAND_SIMD_MAIN_OPTIMIZED_H
    