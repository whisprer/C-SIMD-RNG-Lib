#ifndef RNG_BENCHMARK_H
#define RNG_BENCHMARK_H

#include "universal_rng.h"
#include <memory>
#include <vector>
#include <string>
#include <chrono>
#include <fstream>
#include <iomanip>
#include <type_traits>

// Modern C++ RNG Benchmark Configuration
class RNGBenchmarkConfig {
public:
    // Type-safe template for result storage
    template<typename T>
    using ResultStorage = std::vector<T>;

    // Constructors
    RNGBenchmarkConfig(
        size_t num_iterations, 
        int algorithm_type, 
        int precision_mode
    ) : 
        num_iterations_(num_iterations),
        algorithm_type_(algorithm_type),
        precision_mode_(precision_mode) {
        
        // Allocate results based on precision mode
        if (precision_mode == RNG_PRECISION_SINGLE) {
            results_single_ = std::make_unique<ResultStorage<float>>(num_iterations);
        } else {
            results_double_ = std::make_unique<ResultStorage<double>>(num_iterations);
        }
    }

    // Static factory method
    static std::unique_ptr<RNGBenchmarkConfig> create(
        size_t num_iterations, 
        int algorithm_type, 
        int precision_mode
    ) {
        return std::make_unique<RNGBenchmarkConfig>(
            num_iterations, 
            algorithm_type, 
            precision_mode
        );
    }

    // Run benchmark
    bool run() {
        // Create RNG with smart pointer
        auto rng = universal_rng_new(
            std::chrono::system_clock::now().time_since_epoch().count(),
            static_cast<RNGAlgorithmType>(algorithm_type_),
            static_cast<RNGPrecisionMode>(precision_mode_)
        );

        if (!rng) {
            std::cerr << "Failed to create RNG for benchmarking\n";
            return false;
        }

        // Timing setup
        auto start = std::chrono::high_resolution_clock::now();

        // Batch generation based on precision
        if (precision_mode_ == RNG_PRECISION_SINGLE) {
            universal_rng_next_batch(
                rng.get(), 
                reinterpret_cast<uint64_t*>(results_single_->data()), 
                num_iterations_
            );
        } else {
            universal_rng_next_batch(
                rng.get(), 
                reinterpret_cast<uint64_t*>(results_double_->data()), 
                num_iterations_
            );
        }

        // Calculate timing
        auto end = std::chrono::high_resolution_clock::now();
        total_generation_time_ = std::chrono::duration<double>(end - start).count();
        numbers_per_second_ = num_iterations_ / total_generation_time_;

        // Store implementation type
        implementation_type_ = rng->impl_type;

        return true;
    }

    // Export benchmark results to CSV
    bool export_to_csv(const std::string& path = "") const {
        // Use timestamped filename if not provided
        std::string filename = path.empty() 
            ? generate_timestamped_filename() 
            : path;

        std::ofstream csv_file(filename);
        if (!csv_file) {
            std::cerr << "Failed to open CSV file: " << filename << std::endl;
            return false;
        }

        // Write CSV header
        csv_file << "Iterations,Algorithm,Precision,Implementation,"
                 << "Total Time (s),Numbers/Second\n";

        // Write benchmark results
        csv_file << num_iterations_ << ","
                 << algorithm_type_ << ","
                 << precision_mode_ << ","
                 << implementation_type_ << ","
                 << total_generation_time_ << ","
                 << numbers_per_second_ << "\n";

        return true;
    }

    // Getters
    [[nodiscard]] double getTotalGenerationTime() const { return total_generation_time_; }
    [[nodiscard]] double getNumbersPerSecond() const { return numbers_per_second_; }
    [[nodiscard]] int getImplementationType() const { return implementation_type_; }

    // Retrieve results with type safety
    template<typename T>
    [[nodiscard]] const ResultStorage<T>& getResults() const {
        if constexpr (std::is_same_v<T, float>) {
            if (precision_mode_ != RNG_PRECISION_SINGLE) {
                throw std::runtime_error("Requested single precision results for double precision benchmark");
            }
            return *results_single_;
        } else if constexpr (std::is_same_v<T, double>) {
            if (precision_mode_ != RNG_PRECISION_DOUBLE) {
                throw std::runtime_error("Requested double precision results for single precision benchmark");
            }
            return *results_double_;
        }
    }

private:
    // Generate timestamped filename
    [[nodiscard]] std::string generate_timestamped_filename() const {
        auto now = std::chrono::system_clock::now();
        auto timestamp = std::chrono::system_clock::to_time_t(now);
        std::stringstream ss;
        ss << "rng_benchmark_" 
           << std::put_time(std::localtime(&timestamp), "%Y%m%d_%H%M%S") 
           << ".csv";
        return ss.str();
    }

    // Benchmark configuration
    size_t num_iterations_ = 0;
    int algorithm_type_ = 0;
    int precision_mode_ = 0;
    int implementation_type_ = 0;

    // Performance metrics
    double total_generation_time_ = 0.0;
    double numbers_per_second_ = 0.0;

    // Result storage with smart pointers
    std::unique_ptr<ResultStorage<float>> results_single_;
    std::unique_ptr<ResultStorage<double>> results_double_;
};

#endif // RNG_BENCHMARK_H
