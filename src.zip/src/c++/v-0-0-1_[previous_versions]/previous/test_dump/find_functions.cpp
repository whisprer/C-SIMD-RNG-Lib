// find_functions.cpp
#include <stdio.h>

// Include each header and see what functions are actually defined
#include "wyrand_rng_bench.h"
#include "wyrand_rng_bench_optimized.h"
#include "xoroshiro128pp_rng_bench.h"
#include "xoroshiro128pp_rng_bench_optimized.h"

int main() {
    // The below are just attempts - we're basically trying different function names
    // to see which ones exist

    printf("Attempting to call WyRand benchmark functions...\n");
    // Try different combinations:
    run_wyrand_non_bench();
    // run_wyrand_bench();
    // run_wyrand_bench_non_optimized();

    printf("\nAttempting to call WyRand optimized benchmark functions...\n");
    run_wyrand_bench_optimized();

    printf("\nAttempting to call Xoroshiro benchmark functions...\n");
    // run_xoroshiro_non_bench();
    // run_xoroshiro_bench();
    // run_xoroshiro_bench_non_optimized();

    printf("\nAttempting to call Xoroshiro optimized benchmark functions...\n");
    // run_xoroshiro_bench_optimized();

    return 0;
}