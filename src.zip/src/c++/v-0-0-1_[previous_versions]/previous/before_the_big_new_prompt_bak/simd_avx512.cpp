#include "universal_rng.h"

#ifdef USE_AVX512
#include <immintrin.h>
#include <cstring>
#include <stdexcept>

// AVX-512 implementation of xoroshiro128++ for 8 parallel streams
class AVX512RNGState {
public:
    __m512i s0;  // First 512-bit register (8 uint64_t values)
    __m512i s1;  // Second 512-bit register (8 uint64_t values)
    uint64_t results[8]; // To store extracted results
    int next_idx;        // Index for the next value to return

    AVX512RNGState() : next_idx(8) {}
};

// Helper function for AVX-512 bit rotation
static inline __m512i rotl_avx512(__m512i x, int k) {
    return _mm512_or_si512(
        _mm512_slli_epi64(x, k),
        _mm512_srli_epi64(x, 64 - k)
    );
}

// Create a new AVX-512 RNG state
void* avx512_new(uint64_t seed) {
    AVX512RNGState* state = new AVX512RNGState();
    
    // Initialize 8 parallel generators with different seeds
    uint64_t seeds[8];
    seeds[0] = seed;
    
    // Generate a sequence of seeds using the first seed
    for (int i = 1; i < 8; i++) {
        // Use a simple increment-based seed generation
        seeds[i] = seed + i;
    }
    
    uint64_t s0_vals[8];
    uint64_t s1_vals[8];
    
    for (int i = 0; i < 8; i++) {
        // Use SplitMix64 seeding for each stream
        uint64_t z = (seeds[i] + 0x9e3779b97f4a7c15ULL);
        z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
        z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
        s0_vals[i] = z ^ (z >> 31);
        
        z = (s0_vals[i] + 0x9e3779b97f4a7c15ULL);
        z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
        z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
        s1_vals[i] = z ^ (z >> 31);
    }
    
    // Load initial states into AVX-512 registers
    state->s0 = _mm512_loadu_si512((__m512i*)s0_vals);
    state->s1 = _mm512_loadu_si512((__m512i*)s1_vals);
    
    // Pre-generate first batch of random numbers
    _mm512_storeu_si512((__m512i*)state->results, 
        _mm512_add_epi64(
            rotl_avx512(_mm512_add_epi64(state->s0, state->s1), 17), 
            state->s0
        )
    );
    
    return state;
}

// Free AVX-512 RNG state
void avx512_free(void* state_ptr) {
    if (state_ptr) {
        delete static_cast<AVX512RNGState*>(state_ptr);
    }
}

// Generate next 64-bit random number
uint64_t avx512_next_u64(void* state_ptr) {
    AVX512RNGState* state = static_cast<AVX512RNGState*>(state_ptr);
    
    // If we've used all pre-generated numbers, generate a new batch
    if (state->next_idx >= 8) {
        // Calculate new state and results
        __m512i s0 = state->s0;
        __m512i s1 = state->s1;
        
        // Calculate result: rotl(s0 + s1, 17) + s0
        __m512i sum = _mm512_add_epi64(s0, s1);
        __m512i rotated_sum = rotl_avx512(sum, 17);
        __m512i result_vec = _mm512_add_epi64(rotated_sum, s0);
        
        // Store results
        _mm512_storeu_si512((__m512i*)state->results, result_vec);
        
        // Update state
        s1 = _mm512_xor_si512(s1, s0);
        state->s0 = _mm512_xor_si512(
                        rotl_avx512(s0, 49),
                        _mm512_xor_si512(
                            s1,
                            _mm512_slli_epi64(s1, 21)
                        )
                    );
        state->s1 = rotl_avx512(s1, 28);
        
        // Reset index
        state->next_idx = 0;
    }
    
    // Return next pre-generated number
    return state->results[state->next_idx++];
}

// Generate next random double in [0,1) range
double avx512_next_double(void* state) {
    // Convert to double using high 53 bits
    return (avx512_next_u64(state) >> 11) * (1.0 / (1ULL << 53));
}

// Generate a batch of random numbers
void avx512_next_batch(void* state_ptr, uint64_t* results, size_t count) {
    AVX512RNGState* state = static_cast<AVX512RNGState*>(state_ptr);
    size_t generated = 0;
    
    while (generated < count) {
        // How many values can we get from current batch
        size_t available = 8 - state->next_idx;
        size_t to_copy = (available < (count - generated)) ? available : (count - generated);
        
        // Copy values from current batch
        memcpy(results + generated, state->results + state->next_idx, 
               to_copy * sizeof(uint64_t));
               
        generated += to_copy;
        state->next_idx += to_copy;
        
        // If we need more values, generate a new batch
        if (state->next_idx >= 8 && generated < count) {
            // Update SIMD state and generate new batch
            __m512i s0 = state->s0;
            __m512i s1 = state->s1;
            
            // Calculate result: rotl(s0 + s1, 17) + s0
            __m512i sum = _mm512_add_epi64(s0, s1);
            __m512i rotated_sum = rotl_avx512(sum, 17);
            __m512i result_vec = _mm512_add_epi64(rotated_sum, s0);
            
            // Store results
            _mm512_storeu_si512((__m512i*)state->results, result_vec);
            
            // Update state
            s1 = _mm512_xor_si512(s1, s0);
            state->s0 = _mm512_xor_si512(
                        rotl_avx512(s0, 49),
                        _mm512_xor_si512(
                            s1,
                            _mm512_slli_epi64(s1, 21)
                        )
                    );
            state->s1 = rotl_avx512(s1, 28);
            
            state->next_idx = 0;
        }
    }
}

#endif // USE_AVX512
