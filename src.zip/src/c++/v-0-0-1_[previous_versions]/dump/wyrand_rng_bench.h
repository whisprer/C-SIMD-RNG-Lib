#ifndef WYRAND_RNG_BENCH_MODERN_H
#define WYRAND_RNG_BENCH_MODERN_H

#include "universal_rng.h"
#include <iostream>
#include <iomanip>
#include <chrono>
#include <vector>
#include <memory>
#include <cstdint>
#include <string>
#include <functional>
#include <random>
#include <algorithm>

// Include the modernized SIMD-optimized WyRand implementation
#include "wyrand_simd_main_modern.h"

namespace bench {

// Modern C++ implementation of xoroshiro128+ for comparison
class Xoroshiro128Plus {
public:
    explicit Xoroshiro128Plus(uint64_t seed) {
        seed_state(seed);
    }
    
    uint64_t next() {
        const uint64_t s0 = state_[0];
        uint64_t s1 = state_[1];
        
        // Calculate output with + scrambler (just add)
        const uint64_t result = s0 + s1;
        
        // Update state
        s1 ^= s0;
        state_[0] = rotl(s0, 24) ^ s1 ^ (s1 << 16);
        state_[1] = rotl(s1, 37);
        
        return result;
    }
    
private:
    std::array<uint64_t, 2> state_;
    
    static inline uint64_t rotl(uint64_t x, int k) {
        return (x << k) | (x >> (64 - k));
    }
    
    void seed_state(uint64_t seed) {
        // SplitMix64 for state initialization
        uint64_t z = (seed + 0x9e3779b97f4a7c15ULL);
        z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
        z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
        state_[0] = z ^ (z >> 31);

        z = (state_[0] + 0x9e3779b97f4a7c15ULL);
        z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
        z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
        state_[1] = z ^ (z >> 31);
    }
};

// Benchmark utilities
class Benchmark {
public:
    // Function to measure performance of original xoroshiro128+
    static double benchmark_original(uint64_t iterations) {
        Xoroshiro128Plus generator(42);
        
        auto start = std::chrono::high_resolution_clock::now();
        
        uint64_t sum = 0;
        for (uint64_t i = 0; i < iterations; i++) {
            sum ^= generator.next();
        }
        
        auto end = std::chrono::high_resolution_clock::now();
        std::chrono::duration<double> elapsed = end - start;
        
        // Prevent compiler from optimizing away the loop
        if (sum == 1) std::cout << "This will never print: " << sum << std::endl;
        
        return elapsed.count();
    }

    // Function to measure performance of SIMD WyRand
    static double benchmark_simd(uint64_t iterations) {
        auto rng = std::make_unique<wyrand::WyRandSimdRng>(42);
        
        auto start = std::chrono::high_resolution_clock::now();
        
        uint64_t sum = 0;
        for (uint64_t i = 0; i < iterations; i++) {
            sum ^= rng->next_u64();
        }
        
        auto end = std::chrono::high_resolution_clock::now();
        std::chrono::duration<double> elapsed = end - start;
        
        // Prevent compiler from optimizing away the loop
        if (sum == 1) std::cout << "This will never print: " << sum << std::endl;
        
        return elapsed.count();
    }
    
    // Generic benchmark function for any generator
    template<typename Generator, typename Func>
    static double benchmark_generator(Generator& gen, Func next_func, uint64_t iterations) {
        auto start = std::chrono::high_resolution_clock::now();
        
        uint64_t sum = 0;
        for (uint64_t i = 0; i < iterations; i++) {
            sum ^= next_func(gen);
        }
        
        auto end = std::chrono::high_resolution_clock::now();
        std::chrono::duration<double> elapsed = end - start;
        
        // Prevent compiler from optimizing away the loop
        if (sum == 1) std::cout << "This will never print: " << sum << std::endl;
        
        return elapsed.count();
    }
};

// Simple example showing how to use the SIMD implementation
class UsageExamples {
public:
    static void basic_usage_example() {
        std::cout << "Basic Usage Example:\n";
        std::cout << "--------------------\n";
        
        // Create a new RNG with auto-selected SIMD implementation
        auto rng = std::make_unique<wyrand::WyRandSimdRng>(12345);
        
        // Generate some integer values
        std::cout << "First 5 random integers:\n";
        for (int i = 0; i < 5; i++) {
            std::cout << "  " << rng->next_u64() << "\n";
        }
        
        // Generate some double values
        std::cout << "\nFirst 5 random doubles [0,1):\n";
        for (int i = 0; i < 5; i++) {
            std::cout << "  " << std::fixed << std::setprecision(6) << rng->next_double() << "\n";
        }
        
        std::cout << "\n";
    }
};

// Performance comparison
class PerformanceComparison {
public:
    static void run() {
        const uint64_t iterations = 100'000'000; // 100 million iterations
        
        std::cout << "Performance Comparison:\n";
        std::cout << "----------------------\n";
        
        // Detect available SIMD extensions
        std::cout << "Available acceleration: ";
        #ifdef USE_OPENCL
            std::cout << "GPU (OpenCL)\n";
        #elif defined(USE_AVX512)
            std::cout << "AVX-512 (8-way parallelism)\n";
        #elif defined(USE_AVX2)
            std::cout << "AVX2 (4-way parallelism)\n";
        #elif defined(USE_AVX)
            std::cout << "AVX (4-way parallelism)\n";
        #elif defined(USE_NEON)
            std::cout << "NEON (2-way parallelism)\n";
        #elif defined(USE_SSE2)
            std::cout << "SSE2 (2-way parallelism)\n";
        #else
            std::cout << "None (scalar fallback)\n";
        #endif
        
        std::cout << "Generating " << iterations << " random numbers with each implementation...\n";
        
        // Benchmark original implementation
        double time_original = Benchmark::benchmark_original(iterations);
        std::cout << "Original xoroshiro128+:   " << std::fixed << std::setprecision(4) 
                  << time_original << " seconds (" 
                  << std::setprecision(2) << (iterations / time_original / 1'000'000.0) 
                  << " M numbers/sec)\n";
        
        // Benchmark SIMD/GPU implementation
        double time_simd = Benchmark::benchmark_simd(iterations);
        std::cout << "WyRand-based generator:   " << std::fixed << std::setprecision(4) 
                  << time_simd << " seconds (" 
                  << std::setprecision(2) << (iterations / time_simd / 1'000'000.0) 
                  << " M numbers/sec)\n";
        
        // Calculate and show speedup
        double speedup = time_original / time_simd;
        std::cout << "Speedup:                  " << std::fixed << std::setprecision(2) 
                  << speedup << "x\n";
    }
};

// Class to run the complete benchmark suite
class WyRandBenchSuite {
public:
    static void run() {
        std::cout << "\n=== WYRAND (MODERN) BENCH ===\n\n";
        UsageExamples::basic_usage_example();
        PerformanceComparison::run();
    }
};

} // namespace bench

// C-style API for backward compatibility
extern "C" {
    void run_wyrand_bench_modern() {
        bench::WyRandBenchSuite::run();
    }
}

#endif // WYRAND_RNG_BENCH_MODERN_H
