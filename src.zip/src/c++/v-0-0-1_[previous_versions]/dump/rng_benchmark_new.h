#ifndef RNG_BENCHMARK_H
#define RNG_BENCHMARK_H

#include "rng_core.h"
#include "wyrand_impl.h"
#include "xoroshiro_impl.h"

#include <chrono>
#include <iostream>
#include <iomanip>
#include <string>
#include <vector>
#include <functional>
#include <memory>
#include <fstream>

namespace rng {
namespace benchmark {

// Benchmark configuration
struct BenchmarkConfig {
    uint64_t iterations = 100'000'000; // 100 million
    uint64_t seed = 42;
    bool display_usage_examples = true;
    bool display_summary = true;
    bool export_csv = false;
    std::string csv_file = "rng_benchmark_results.csv";
};

// Result of a single benchmark run
struct BenchmarkResult {
    std::string name;
    std::string implementation;
    double time_seconds;
    double millions_per_second;
    double speedup; // Relative to baseline
};

// Benchmark a single RNG
template<typename Factory>
BenchmarkResult benchmark_rng(const std::string& name, Factory& factory, const BenchmarkConfig& config) {
    BenchmarkResult result;
    result.name = name;
    
    // Create the RNG
    auto rng = factory.create(config.seed);
    result.implementation = rng->get_implementation_name();
    
    // Simple display if requested
    if (config.display_usage_examples) {
        std::cout << "First 5 random numbers from " << name << " (" << result.implementation << "):\n";
        for (int i = 0; i < 5; i++) {
            std::cout << "  " << rng->next_u64() << "\n";
        }
        std::cout << "\n";
    }
    
    // Benchmark the RNG
    uint64_t sum = 0; // To prevent optimization
    
    auto start = std::chrono::high_resolution_clock::now();
    
    // Generate a batch of random numbers
    for (uint64_t i = 0; i < config.iterations; i++) {
        sum ^= rng->next_u64();
    }
    
    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed = end - start;
    
    // Prevent optimization
    if (sum == 1) {
        std::cout << "This should never happen: " << sum << std::endl;
    }
    
    // Record results
    result.time_seconds = elapsed.count();
    result.millions_per_second = config.iterations / (result.time_seconds * 1'000'000);
    result.speedup = 1.0; // Will be adjusted relative to baseline later
    
    return result;
}

// Run all benchmarks
std::vector<BenchmarkResult> run_all_benchmarks(const BenchmarkConfig& config = BenchmarkConfig()) {
    std::vector<BenchmarkResult> results;
    
    // Create factories for different RNG algorithms
    xoroshiro::Xoroshiro128ppFactory xoroshiro_factory;
    wyrand::WyRandFactory wyrand_factory;
    
    // Get the baseline (original xoroshiro128++)
    std::cout << "=== BASELINE BENCHMARK ===\n\n";
    auto baseline = benchmark_rng("xoroshiro128++ (baseline)", xoroshiro_factory, config);
    results.push_back(baseline);
    
    // Run all benchmarks in sequence
    
    // xoroshiro128++ optimized
    std::cout << "\n=== XOROSHIRO128++ (OPTIMIZED) BENCH ===\n\n";
    auto xoroshiro_optimized = benchmark_rng("xoroshiro128++ (optimized)", xoroshiro_factory, config);
    // Adjust speedup relative to baseline
    xoroshiro_optimized.speedup = baseline.time_seconds / xoroshiro_optimized.time_seconds;
    results.push_back(xoroshiro_optimized);
    
    // WyRand standard
    std::cout << "\n=== WYRAND (STANDARD) BENCH ===\n\n";
    auto wyrand_standard = benchmark_rng("WyRand (standard)", wyrand_factory, config);
    // Adjust speedup relative to baseline
    wyrand_standard.speedup = baseline.time_seconds / wyrand_standard.time_seconds;
    results.push_back(wyrand_standard);
    
    // WyRand optimized
    std::cout << "\n=== WYRAND (OPTIMIZED) BENCH ===\n\n";
    auto wyrand_optimized = benchmark_rng("WyRand (optimized)", wyrand_factory, config);
    // Adjust speedup relative to baseline
    wyrand_optimized.speedup = baseline.time_seconds / wyrand_optimized.time_seconds;
    results.push_back(wyrand_optimized);
    
    // Display summary if requested
    if (config.display_summary) {
        std::cout << "\n=== BENCHMARK SUMMARY ===\n\n";
        std::cout << std::left << std::setw(30) << "Algorithm" 
                  << std::setw(25) << "Implementation" 
                  << std::setw(15) << "Time (s)" 
                  << std::setw(15) << "M/sec" 
                  << std::setw(10) << "Speedup" << "\n";
        std::cout << std::string(95, '-') << "\n";
        
        for (const auto& result : results) {
            std::cout << std::left << std::setw(30) << result.name 
                      << std::setw(25) << result.implementation 
                      << std::fixed << std::setprecision(4) << std::setw(15) << result.time_seconds 
                      << std::fixed << std::setprecision(2) << std::setw(15) << result.millions_per_second 
                      << std::fixed << std::setprecision(2) << std::setw(10) << result.speedup << "\n";
        }
    }
    
    // Export to CSV if requested
    if (config.export_csv) {
        std::ofstream csv(config.csv_file);
        csv << "Algorithm,Implementation,Time(s),M/sec,Speedup\n";
        
        for (const auto& result : results) {
            csv << result.name << "," 
                << result.implementation << "," 
                << std::fixed << std::setprecision(6) << result.time_seconds << "," 
                << std::fixed << std::setprecision(2) << result.millions_per_second << "," 
                << std::fixed << std::setprecision(2) << result.speedup << "\n";
        }
    }
    
    return results;
}

} // namespace benchmark
} // namespace rng

#endif // RNG_BENCHMARK_H