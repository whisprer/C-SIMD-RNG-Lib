#ifndef BENCHMARK_HEADERS_H
#define BENCHMARK_HEADERS_H

#include <algorithm>
#include <cmath>
#include <numeric>
#include <vector>
#include <memory>
#include <iostream>
#include <cstdint>

// Forward declarations and type aliases
class BenchmarkStats;
using BenchmarkStatsPtr = std::shared_ptr<BenchmarkStats>;
using BenchmarkStatsConstPtr = std::shared_ptr<const BenchmarkStats>;

// Factory function for creating shared benchmark stats
inline BenchmarkStatsPtr make_benchmark_stats(const std::vector<double>& times) {
    return std::make_shared<BenchmarkStats>(BenchmarkStats::compute(times));
}

#endif // BENCHMARK_HEADERS_H