#ifndef WYRAND_SIMD_MAIN_OPTIMIZED_H
#define WYRAND_SIMD_MAIN_OPTIMIZED_H

// This file is intentionally left as a backward compatibility wrapper
// All its functionality has been moved to the modern C++ implementation in wyrand.h
#include "wyrand.h"

// The functionality is provided through the C API defined in wyrand.h

#endif // WYRAND_SIMD_MAIN_OPTIMIZED_H